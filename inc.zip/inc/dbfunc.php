<?php

$i__dbquery_count = 0;
$s__dbquery_last = null;
$b__dbquery_txn_active = 0;

class dbquery_manager {
    static $SERVERS = array(
		array(
			'host' => 'localhost', // Development
	        'username' => 'chasepims',
	        'password' => 'Chasenedrow1@',
	        'database' => 'chase30inventory2')
		/*array(
			'host' => 'localhost', // Development
	        'username' => 'cudnohu1_dev',
	        'password' => '',
	        'database' => 'equipment_dev'),
		array(
			'host' => '208.79.208.184', // Yan
	        'username' => 'cudnohu1',
	        'password' => 'dCud21591',
	        'database' => 'chase30_inventory2'),
	    array(
			'host' => '192.232.251.48', // Host Gator
	        'username' => 'devincde_dev',
	        'password' => 'dCud21591',
	        'database' => 'devincde_client'),
		array(
	        'host' => '69.89.31.216', // Bluehost
	        'username' => 'devincde_dev',
	        'password' => 'dCud21591',
	        'database' => 'devincde_client')*/
    );
    static $server_idx = 0;
    static $connection = null;

    public static function create() {
        if (self::$connection == null or mysql_select_db(self::$SERVERS[self::$server_idx]['database'],self::$connection) == false) {
            global $b__dbquery_txn_active;
            $b__dbquery_txn_active = 0;
            for ($i = 0, $n = count(self::$SERVERS); $i < $n; $i++) {
                $server = self::$SERVERS[$i];

                $con = @mysql_pconnect($server['host'], $server['username'], $server['password']);

                if (!($con === false)) {
                    if (mysql_select_db($server['database'], $con) === false) {
                        continue;
                    }
                    self::$server_idx = $i;
                    self::$connection = $con;
                    return self::$connection;
                }
            }
            trigger_error("no database servers available");
        }
		
		//mysql_query("SET NAMES 'UTF8'", self::$connection);
		
        return self::$connection;
    }

    public static function getHost() {
        return self::$SERVERS[self::$server_idx]['host'];
    }
}


function dbquery_getconn($alt_db="") {
  // connect to the database
  $dbc = dbquery_manager::create();

  if ($alt_db != "" and mysql_select_db($alt_db,$dbc) == false) {
        trigger_error("alternate database not found");
  }

  return $dbc;
}

/* quote variable to make safe */
function quote_smart($value, $dbc) {
    # if inserting NULL, then it might as well be NULL
    if (is_null($value)) {
        return 'NULL';
    }
    # strip slashes
    if (get_magic_quotes_gpc()) {
        $value = stripslashes($value);
    }
    # quote if not a number
    if (is_string($value)) {
        $value = "'" . mysql_real_escape_string($value, $dbc) . "'";
    }
    return $value;
}

/* create a mysql connection */
function dbquery( $query, $values=array(), $alt_db="" ) {
    /* USE:
     *  $query => query string where ? or sprintf type specifiers (e.g. %s) are to be substituted for (pre-quoted) values
     *  $values => array containing values to be escaped/quoted for substitution into $query
     */

    global $i__dbquery_count, $b__dbquery_txn_active, $s__dbquery_last;
    $i__dbquery_count++;

    // the array where the rows are to be stored
    $rows = array();

    $dbc = dbquery_getconn($alt_db);

    # escape values
    for ($i=0;$i<count($values);$i++) {
        if ( is_array($values[$i]) ) {
            $escaped = array();
            foreach ($values[$i] as $unescaped) {
                $escaped[] = quote_smart($unescaped, $dbc);
            }
            $values[$i] = implode(',',$escaped);
        }
        else $values[$i] = quote_smart($values[$i], $dbc);
    }

    # question marks are placeholders for variables
    $query = str_replace("?","%s",$query);

    # merge values into query
    $query = vsprintf($query,$values);
    if ($b__dbquery_txn_active == 1) $s__dbquery_last .= "\n\n" . $query;
    else $s__dbquery_last = $query;

    # perform the query
	//mysql_query("SET NAMES 'UTF8'", $dbc);
    $result = mysql_query($query,$dbc);

    if (mysql_errno() != 0) {
      trigger_error(mysql_errno() . ": " . mysql_error() . " ~ " . $query);
	  
    }

    # pull AUTO_INCREMENT id if previous query was INSERT
    if ( preg_match('/^\s*INSERT/i',$query) ) {
        $insertId = mysql_insert_id($dbc);

        # if insert id was pulled, return it
        if ( is_int($insertId) and $insertId > 0) {
            return $insertId;
        }
        else {
            return null;
        }
    }

    # pull rows affected count if query was UPDATE
    if ( preg_match('/^\s*(UPDATE|REPLACE|DELETE)/i',$query) ) {
        $chgCount = mysql_affected_rows($dbc);

        # if count was pulled, return it
        if ( is_int($chgCount) and $chgCount >= 0) {
            return $chgCount;
        }
        else {
            return null;
        }
    }

    # pull the rows from the query results if not an UPDATE or DELETE
    if ($result !== true) {
      while ($row = @mysql_fetch_array($result, MYSQL_ASSOC)) $rows[] = $row; // will return mysql null values as php nulls
    }

    # close mysql connection
    #mysql_close($dbc);

    return $rows;
}

/* returns only the first row from the query; throw error if none returned */
function dbquery_row($query, $values=array(), $alt_db="") {
  $aArray = dbquery($query,$values,$alt_db);
  if ( is_array($aArray) and count($aArray) > 0 ) {
    $aRow = array_shift($aArray);
  }
  else {
    trigger_error("MySQL returned no rows from query where one row is required");
  }
  return $aRow;
}

function dbquery_return( $query,$values=array() ) {
    $dbc = dbquery_getconn();
    # escape values
    for ($i=0;$i<count($values);$i++) {
        if ( is_array($values[$i]) ) {
            $escaped = array();
            foreach ($values[$i] as $unescaped) {
                $escaped[] = quote_smart($unescaped, $dbc);
            }
            $values[$i] = implode(',',$escaped);
        }
        else $values[$i] = quote_smart($values[$i], $dbc);
    }
    $query = str_replace("?","%s",$query);
    return vsprintf($query,$values);
}

function dbquery_dump( $query,$values=array() ) {
    $dbc = dbquery_getconn();
    # escape values
    for ($i=0;$i<count($values);$i++) {
        if ( is_array($values[$i]) ) {
            $escaped = array();
            foreach ($values[$i] as $unescaped) {
                $escaped[] = quote_smart($unescaped, $dbc);
            }
            $values[$i] = implode(',',$escaped);
        }
        else $values[$i] = quote_smart($values[$i], $dbc);
    }
    $query = str_replace("?","%s",$query);
    echo "<br />\n" . vsprintf($query,$values) . "\n<br />";
    return null;
}

// return all possible enum values from a column in index order
function dbquery_enum_values($table, $field,$db='') {
    $enum_array = array();
    $query = 'SHOW COLUMNS FROM `' . $table . '` LIKE "' . $field . '"';
    $row = dbquery_row($query);
    preg_match_all('/\'(.*?)\'/', $row[1], $enum_array);
    if(!empty($enum_array[1])) {
        // organize values based on their mysql order
        foreach($enum_array[1] as $mkey => $mval) $enum_fields[$mkey+1] = $mval;
        return $enum_fields;
    }
    else return array();
}

function dbquery_txn_start()
{
  global $b__dbquery_txn_active;
  if ($b__dbquery_txn_active == 0) {
    dbquery("START TRANSACTION");
    $b__dbquery_txn_active = 1;
  }
}

function dbquery_txn_commit()
{
  global $b__dbquery_txn_active;
  if ($b__dbquery_txn_active == 1) {
    dbquery("COMMIT");
    $b__dbquery_txn_active = 0;
  }
}

function dbquery_txn_rollback()
{
  global $b__dbquery_txn_active;
  if ($b__dbquery_txn_active == 1) {
    dbquery("ROLLBACK");
    $b__dbquery_txn_active = 0;
    return 1;
  }
  return 0;
}


function dbquery_getquerycount() {
    global $i__dbquery_count;
    return $i__dbquery_count;
}

function dbquery_getlastquery() {
    global $s__dbquery_last;
    return $s__dbquery_last;
}

?>
