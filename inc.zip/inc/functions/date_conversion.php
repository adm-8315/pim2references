<?php

	/**
	 * Function
	 */

	function date_to_mysql( $date )
	{
		
		if ( ! empty( $date ) )
		{
			
			$date = date("Y-m-d", strtotime( str_replace( "-", "/", $date ) ) );
			$currentDate = date("Y-m-d");

			if ( $currentDate == $date )
			{
				return date("Y-m-d H:i:s" );
			}
			else
			{
				return $date . " 00:00:00";
			}
		
		}
		else
		{
			return NULL;
		}
		
	}
	
	
	function mysql_to_date( $mysql )
	{
		
		if ( ! empty( $mysql ) && $mysql != '0000-00-00' )
		{
			return date("m-d-Y", strtotime( $mysql ) );
		}
		else
		{
			return NULL;
		}
		
	}

?>