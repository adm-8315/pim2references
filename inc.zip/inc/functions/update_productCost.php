<?php

	function update_productCost( $productID )
	{
		
		$query = "
			UPDATE 
				product m
			LEFT JOIN
				(
				SELECT
					temp.product,
					temp.avgCost
				FROM
					(
						SELECT
							*
						FROM
							(
								SELECT
									CASE
										WHEN @prev_id != temp.product
										THEN @totalStock := 0
										ELSE null
									END as 'resetTotalStock',
									CASE
										WHEN @prev_id != temp.product
										THEN @averageCost := 0
										ELSE null
									END as 'resetAverageCost',

									IF(
										temp.cost is not null AND @totalStock >= 0,
										@averageCost := ( ( @totalStock * @averageCost ) + ( temp.value * temp.cost ) ) / ( @totalStock + temp.value ),
										@averageCost
									) as 'avgCost',
									CASE
										WHEN temp.transactionType <= 2
										THEN @totalStock := @totalStock + temp.value
										WHEN temp.transactionType > 2 && temp.transactionType != 7
										THEN @totalStock := @totalStock - temp.value
										ELSE @totalStock := temp.value
									END as 'stock',
									temp.productTransactionID,
									temp.productInventory,
									temp.timestamp,
									@prev_id := temp.product as 'product'
								FROM
									(
										SELECT
											@prev_id := 0,
											@row := 0,
											@total_stock := 0,
											@average_cost := 0.0
									) vars
								JOIN
									(
										(
											SELECT
												t.productTransactionID,
												i.product,
												t.productInventory,
												t.transactionType,
												t.value,
												t.cost,
												t.timestamp
											FROM
												productInventory i
											LEFT JOIN
												productTransaction t
												ON i.productInventoryID = t.productInventory
											LEFT JOIN
												companyLocationLink cll
												ON i.companyLocationLink = cll.companyLocationLinkID
											ORDER BY
												i.product,
												t.timestamp,
												t.productTransactionID
										)
									UNION
										(
											SELECT
												t.productTransactionID,
												i.product,
												i2.productInventoryID as productInventory,
												t.transactionType,
												t.value * -1 as value,
												t.cost,
												t.timestamp
											FROM
												productTransaction t
											LEFT JOIN
												productInventory i
												ON t.productInventory = i.productInventoryID
											LEFT JOIN
												productInventory i2
												ON i2.product = i.product
												AND i2.companyLocationLink = t.companyLocationLink
											LEFT JOIN
												companyLocationLink cll
												ON cll.companyLocationLinkID = t.companyLocationLink
											WHERE
												t.transactionType = 3
											AND
												t.companyLocationLink is not null
										)
									) temp
								ORDER BY
									temp.productInventory ASC,
									temp.timestamp ASC,
									temp.productTransactionID ASC
							) temp
						ORDER BY
							temp.timestamp DESC,
							temp.productTransactionID DESC
					) temp
				GROUP BY
					temp.product
				) temp
				ON temp.product = m.productID
			SET
				m.cost = temp.avgCost
			WHERE
				m.productID = ?
		";

		$values = array(
			$productID
		);

		$result = dbquery( $query, $values );
		
	}

?>