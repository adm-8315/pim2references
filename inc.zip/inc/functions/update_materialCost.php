<?php

	function update_materialCost( $materialID )
	{
		
		$query = "
			UPDATE 
				material m
			LEFT JOIN
				(
				SELECT
					temp.material,
					temp.avgCost
				FROM
					(
						SELECT
							*
						FROM
							(
								SELECT
									CASE
										WHEN @prev_id != temp.material
										THEN @totalStock := 0
										ELSE null
									END as 'resetTotalStock',
									CASE
										WHEN @prev_id != temp.material
										THEN @averageCost := 0
										ELSE null
									END as 'resetAverageCost',

									IF(
										temp.cost is not null AND @totalStock >= 0,
										@averageCost := ( ( @totalStock * @averageCost ) + ( temp.value * temp.cost ) ) / ( @totalStock + temp.value ),
										@averageCost
									) as 'avgCost',
									CASE
										WHEN temp.transactionType <= 2
										THEN @totalStock := @totalStock + temp.value
										WHEN temp.transactionType > 2 && temp.transactionType != 7
										THEN @totalStock := @totalStock - temp.value
										ELSE @totalStock := temp.value
									END as 'stock',
									temp.materialTransactionID,
									temp.materialInventory,
									temp.timestamp,
									@prev_id := temp.material as 'material'
								FROM
									(
										SELECT
											@prev_id := 0,
											@row := 0,
											@total_stock := 0,
											@average_cost := 0.0
									) vars
								JOIN
									(
										(
											SELECT
												t.materialTransactionID,
												i.material,
												t.materialInventory,
												t.transactionType,
												t.value,
												t.cost,
												t.timestamp
											FROM
												materialInventory i
											LEFT JOIN
												materialTransaction t
												ON i.materialInventoryID = t.materialInventory
											LEFT JOIN
												companyLocationLink cll
												ON i.companyLocationLink = cll.companyLocationLinkID
											ORDER BY
												i.material,
												t.timestamp,
												t.materialTransactionID
										)
									UNION
										(
											SELECT
												t.materialTransactionID,
												i.material,
												i2.materialInventoryID as materialInventory,
												t.transactionType,
												t.value * -1 as value,
												t.cost,
												t.timestamp
											FROM
												materialTransaction t
											LEFT JOIN
												materialInventory i
												ON t.materialInventory = i.materialInventoryID
											LEFT JOIN
												materialInventory i2
												ON i2.material = i.material
												AND i2.companyLocationLink = t.companyLocationLink
											LEFT JOIN
												companyLocationLink cll
												ON cll.companyLocationLinkID = t.companyLocationLink
											WHERE
												t.transactionType = 3
											AND
												t.companyLocationLink is not null
										)
									) temp
								ORDER BY
									temp.materialInventory ASC,
									temp.timestamp ASC,
									temp.materialTransactionID ASC
							) temp
						ORDER BY
							temp.timestamp DESC,
							temp.materialTransactionID DESC
					) temp
				GROUP BY
					temp.material
				) temp
				ON temp.material = m.materialID
			SET
				m.cost = temp.avgCost
			WHERE
				m.materialID = ?
		";

		$values = array(
			$materialID
		);

		$result = dbquery( $query, $values );
		
	}

?>