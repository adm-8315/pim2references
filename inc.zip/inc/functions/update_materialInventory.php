<?php

	function update_materialInventory()
	{

		$query = "
			UPDATE materialInventory i
				LEFT JOIN
					(
						SELECT
							temp.materialInventory,
							temp.stock
								FROM
								(
									SELECT
										*
									FROM
										(
											SELECT
												CASE
													WHEN @prev_id != temp.materialInventory
													THEN @totalStock := 0
													ELSE null
												END as 'resetTotalStock',

												CASE
													WHEN temp.transactionType <= 2
													THEN @totalStock := @totalStock + temp.value
													WHEN temp.transactionType > 2 && temp.transactionType != 7
													THEN @totalStock := @totalStock - temp.value
													ELSE @totalStock := temp.value
												END as 'stock',
												temp.materialTransactionID,
												temp.timestamp,
												@prev_id := temp.materialInventory as 'materialInventory'
											FROM
												(
													SELECT
														@prev_id := 0,
														@row := 0,
														@total_stock := 0
												) vars
											JOIN
												(
													(
														SELECT
															t.materialTransactionID,
															i.material,
															i.materialInventoryID as 'materialInventory',
															t.transactionType,
															t.value,
															t.cost,
															t.timestamp
														FROM
															materialInventory i
														LEFT JOIN
															materialTransaction t
															ON i.materialInventoryID = t.materialInventory
														LEFT JOIN
															companyLocationLink cll
															ON i.companyLocationLink = cll.companyLocationLinkID
														WHERE
															t.materialTransactionID is not null
														ORDER BY
															i.material,
															t.timestamp,
															t.materialTransactionID
													)
												UNION
													(
														SELECT
															t.materialTransactionID,
															i.material,
															i2.materialInventoryID as materialInventory,
															t.transactionType,
															t.value * -1 as value,
															t.cost,
															t.timestamp
														FROM
															materialTransaction t
														LEFT JOIN
															materialInventory i
															ON t.materialInventory = i.materialInventoryID
														LEFT JOIN
															materialInventory i2
															ON i2.material = i.material
															AND i2.companyLocationLink = t.companyLocationLink
														LEFT JOIN
															companyLocationLink cll
															ON cll.companyLocationLinkID = t.companyLocationLink
														WHERE
															t.materialTransactionID is not null
														AND
															t.transactionType = 3
														AND
															t.companyLocationLink is not null
													)
												) temp
											ORDER BY
												temp.materialInventory ASC,
												temp.timestamp ASC,
												temp.materialTransactionID ASC
										) temp
									ORDER BY
										temp.materialInventory ASC,
										temp.timestamp DESC,
										temp.materialTransactionID DESC
								) temp
							GROUP BY
								temp.materialInventory
					) temp
					ON temp.materialInventory = i.materialInventoryID
				SET
					i.stock = CASE
						WHEN temp.stock IS NULL THEN 0
						WHEN temp.stock < 0 THEN 0
						ELSE temp.stock
					END
		";

		$values = array();

		$result = dbquery( $query, $values );
	
	}

?>