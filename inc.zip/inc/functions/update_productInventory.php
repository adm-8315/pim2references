<?php

	function update_productInventory()
	{

		$query = "
			UPDATE productInventory i
				LEFT JOIN
					(
						SELECT
							temp.productInventory,
							temp.stock
								FROM
								(
									SELECT
										*
									FROM
										(
											SELECT
												CASE
													WHEN @prev_id != temp.productInventory
													THEN @totalStock := 0
													ELSE null
												END as 'resetTotalStock',

												CASE
													WHEN temp.transactionType <= 2
													THEN @totalStock := @totalStock + temp.value
													WHEN temp.transactionType > 2 && temp.transactionType != 7
													THEN @totalStock := @totalStock - temp.value
													ELSE @totalStock := temp.value
												END as 'stock',
												temp.productTransactionID,
												temp.timestamp,
												@prev_id := temp.productInventory as 'productInventory'
											FROM
												(
													SELECT
														@prev_id := 0,
														@row := 0,
														@total_stock := 0
												) vars
											JOIN
												(
													(
														SELECT
															t.productTransactionID,
															i.product,
															i.productInventoryID as 'productInventory',
															t.transactionType,
															t.value,
															t.cost,
															t.timestamp
														FROM
															productInventory i
														LEFT JOIN
															productTransaction t
															ON i.productInventoryID = t.productInventory
														LEFT JOIN
															companyLocationLink cll
															ON i.companyLocationLink = cll.companyLocationLinkID
														WHERE
															t.productTransactionID is not null
														ORDER BY
															i.product,
															t.timestamp,
															t.productTransactionID
													)
												UNION
													(
														SELECT
															t.productTransactionID,
															i.product,
															i2.productInventoryID as productInventory,
															t.transactionType,
															t.value * -1 as value,
															t.cost,
															t.timestamp
														FROM
															productTransaction t
														LEFT JOIN
															productInventory i
															ON t.productInventory = i.productInventoryID
														LEFT JOIN
															productInventory i2
															ON i2.product = i.product
															AND i2.companyLocationLink = t.companyLocationLink
														LEFT JOIN
															companyLocationLink cll
															ON cll.companyLocationLinkID = t.companyLocationLink
														WHERE
															t.productTransactionID is not null
														AND
															t.transactionType = 3
														AND
															t.companyLocationLink is not null
													)
												) temp
											ORDER BY
												temp.productInventory ASC,
												temp.timestamp ASC,
												temp.productTransactionID ASC
										) temp
									ORDER BY
										temp.productInventory ASC,
										temp.timestamp DESC,
										temp.productTransactionID DESC
								) temp
							GROUP BY
								temp.productInventory
					) temp
					ON temp.productInventory = i.productInventoryID
				SET
					i.stock = CASE
						WHEN temp.stock IS NULL THEN 0
						WHEN temp.stock < 0 THEN 0
						ELSE temp.stock
					END
		";

		$values = array();

		$result = dbquery( $query, $values );
	
	}

?>