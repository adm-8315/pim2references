<?php

	function normalizeItemInventory( $json )
	{

		// Item Inventory Insert Ignore ( Make sure all Inventory IDs Exist )
	
		$values = array();
	
		$query = "
			INSERT IGNORE
				INTO itemInventory
					( item, location, stock)
				VALUES	
		";
	
		foreach ( $json as $row )
		{
		
			if ( $row['type'] == 'item' )
			{
			
				$query .= "( ?, " . $row['location'] . ", 0 ),";
				$values[] = $row['id'];
			
			}
		
		}
	
		if ( ! empty( $json ) )
		{
		
			$query = substr( $query, 0, -1 );
			$result['itemInventoryInsertIgnore'] = dbquery( $query, $values );
	
		}
		
	}

?>