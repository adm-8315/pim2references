<?php

	/**
	 * Includes
	 */
	
	require_once( "inc/permissions_vars.php" );
	require_once("inc/dev_tools/print_dev.php");
	
	
	
	/**
	 * Variables
	 */

	$load_login = true;
	$load_home = false;
	
	//print_dev( $permissions );


	/**
	 * Process
	 */


	if ( isset( $_GET['nav'] ) )
	{

		if ( isset ( $_SESSION['user_id'] ) )
		{
	
			if ( 
				file_exists( $_GET['nav'] . '.php' ) &&
				(
					(
						(
							(
								$_GET['nav'] == 'customer' ||
								$_GET['nav'] == 'equipment' ||
								$_GET['nav'] == 'grouping' ||
								$_GET['nav'] == 'item' ||
								$_GET['nav'] == 'job' ||
								$_GET['nav'] == 'material' ||
								$_GET['nav'] == 'product' ||
								$_GET['nav'] == 'editor'
							
							) &&
							isset( $_GET['id'] )
						) || (
							$_GET['nav'] == 'report' &&
							isset( $_GET['report'] )
						)
					) || (
						$_GET['nav'] != 'customer' &&
						$_GET['nav'] != 'equipment' &&
						$_GET['nav'] != 'grouping' &&
						$_GET['nav'] != 'item' &&
						$_GET['nav'] != 'job' &&
						$_GET['nav'] != 'material' &&
						$_GET['nav'] != 'product' &&
						$_GET['nav'] != 'report'
					)
				)
			) {
			
				if (
					isset( $permissions[1][1] ) ||
					(
						(
							(
								$_GET['nav'] == 'equipment' &&
								(
									isset( $permissions[3][31] )
								)
							) || (
								$_GET['nav'] == 'grouping' &&
								(
									isset( $permissions[3][32] )
								)
							) || (
								$_GET['nav'] == 'item' &&
								(
									isset( $permissions[3][33] )
								)
							) || (
								$_GET['nav'] == 'job' &&
								(
									isset( $permissions[3][41] )
								)
							) || (
								$_GET['nav'] == 'material' &&
								(
									isset( $permissions[3][2] )
								)
							) || (
								$_GET['nav'] == 'product' &&
								(
									isset( $permissions[3][3] )
								)
							) || (
								$_GET['nav'] == 'report' &&
								(
									isset( $permissions[3][$permissionsVars[ $_GET['report'] ] ] )
								)
							) || (
								$_GET['nav'] == 'report' &&
								$_GET['report'] == 'openOrder'  &&
								(
									isset( $permissions[4][42] )
								)
							)
						) || (
							$_GET['nav'] != 'equipment' &&
							$_GET['nav'] != 'grouping' &&
							$_GET['nav'] != 'item' &&
							$_GET['nav'] != 'job' &&
							$_GET['nav'] != 'material' &&
							$_GET['nav'] != 'product' &&
							$_GET['nav'] != 'report'
						)
					)
				) {
					$load_login = false;
				}
				else
				{
					$load_home = true;
					$message = "Insufficient Permissions";
				}
			
			}
			else
			{
				$load_home = true;
				$message = "404: That page does not exist.";
				//print_dev( $_SESSION );
			}

		}
		else
		{
			$message = "You must login.";
		}

	}
	
	if ( $load_login && isset( $_POST['submit'] ) )
	{
		require_once( "inc/login_process.php" );
	}
