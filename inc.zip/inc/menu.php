<?php

	/**
	 * Variables
	 */
	
	$menu = array(
		"Reports" => array(
			2 	=> array( "name" => 'Material Stock', 				"arguments" => array( "nav" => "report", "report" => "raw_material_stock" 		) ),
			7 	=> array( "name" => 'Material Usage', 				"arguments" => array( "nav" => "report", "report" => "material_usage" 			) ),
			8 	=> array( "name" => 'Production', 					"arguments" => array( "nav" => "report", "report" => "production" 				) ),
			3	=> array( "name" => 'Product Stock', 				"arguments" => array( "nav" => "report", "report" => "finished_product_stock" 	) ),
			9 	=> array( "name" => 'Product Sales', 				"arguments" => array( "nav" => "report", "report" => "finished_product_sales" 	) ),
			4 	=> array( "name" => 'Tools & Accessories Stock', 	"arguments" => array( "nav" => "report", "report" => "tools_accessories_stock" 	) ),
			6 	=> array( "name" => 'Tools & Accessories Value', 	"arguments" => array( "nav" => "report", "report" => "tools_accessories_value" 	) ),
			10 	=> array( "name" => 'Scrap', 						"arguments" => array( "nav" => "report", "report" => "scrap" 					) ),
			5 	=> array( "name" => 'Stock Value', 					"arguments" => array( "nav" => "report", "report" => "stock_value" 				) ),
			11 	=> array( "name" => 'Inventory Adjustment', 		"arguments" => array( "nav" => "report", "report" => "inventory_adjustment" 	) )
		),
		"Production" => array(	
			42	=> array( "name" => 'Open Orders',					"arguments" => array( "nav" => "report", "report" => "openOrder"				) ),
			40 	=> array( "name" => 'Scheduling', 					"arguments" => array( "nav" => "schedule"										) )
		),
		"Construction" => array(
			41 	=> array( "name" => 'Job', 							"arguments" => array( "nav" => "report", "report" => "job" 						) ),
			31 	=> array( "name" => 'Equipment', 					"arguments" => array( "nav" => "report", "report" => "equipment" 				) ),
			32 	=> array( "name" => 'Grouping', 					"arguments" => array( "nav" => "report", "report" => "grouping" 				) ),
			33 	=> array( "name" => 'Item', 						"arguments" => array( "nav" => "report", "report" => "item" 					) )
		),
		"Quality" => array(
			43 	=> array( "name" => 'Exothermal Test',				"arguments" => array( "nav" => "exotherm"										) )
		)	
	);
	
	
	
	/**
	 * Menu Display
	 */

?>

<div id="menu">
	
	<?php
	
	if ( 
		! empty( $permissions[1][1] ) || 
		! empty( $permissions[2] ) 
	) {
	
		echo "<div class='button no_select transaction' data-nav='transaction'>Transaction</div>";
	
	}
	
	foreach ( $menu as $name => $submenu )
	{
		
		$outstring = "";
		$empty = true;
		
		foreach( $submenu as $block => $row )
		{
			
			if ( 
				isset( $permissions[1][1] ) ||
				isset( $permissions[3][$block] ) ||
				isset( $permissions[4][$block] )
			) {
				
				$selected = true;
				$empty = false;
				
				foreach ( $row['arguments'] as $key => $value )
				{
					
					if ( 
						! isset( $_GET[$key] ) ||
						$_GET[$key] != $value
					) {
						$selected = false;	
					}
					
				}
				
				$outstring .= "<div class='option no_select clickable ";
				
				if ( $selected )
				{
					$outstring .= "current_page";
				}
				
				$outstring .= "' data-block='{$block}' ";
				
				foreach ( $row['arguments'] as $key => $value )
				{
					$outstring .= " data-{$key}='{$value}' ";
				}
				
				$outstring .= " >{$row['name']}</div>";
				
			}
			
		}
		
		if ( ! $empty )
		{
			
			echo "<h4 class='no_select'>{$name}</h4>";
			echo $outstring;
			
		}
		
	}
	
	
	?>
	
</div>