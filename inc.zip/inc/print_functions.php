<?php
	
	function productionOrder ()
	{
		// Variables
		global $result;
		global $pour;
		$output = array();
		$productionOrders = array();
		$batchMaterials = array(
			11,
			12,
			13,
			14,
			20,
			32,
			34
		);
		
		
		foreach ( $pour as $priority => $data )
		{
			
			if ( ! empty( $data['productionOrder'] ) )
			{
				
				$mixTime = "";
				$taps = "";
				$lowerSpec = "";
				$upperSpec = "";
			
				$productionOrders[$priority] = array();
				$productionOrders[$priority]['waterPercentage'] = $result['productionOrder'][ key( $data['productionOrder'] ) ][0]['water'];
				$productionOrders[$priority]['totalMaterial'] = $data['materialSum'];
				$productionOrders[$priority]['productionOrder'] = array(); 
				
				foreach ( $data['productionOrder'] as $productionOrderID => $totalMaterial )
				{
					$productionOrders[$priority]['productionOrder'][$productionOrderID] = array();
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['product'] = $result['productionOrder'][$productionOrderID][0]['product'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['quantity'] = $result['productionOrder'][$productionOrderID][0]['scheduleQuantity'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['form'] = $result['productionOrder'][$productionOrderID][0]['formTag'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['formLocation'] = $result['productionOrder'][$productionOrderID][0]['formLocation'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['vibType'] = $result['productionOrder'][$productionOrderID][0]['vibrationType'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['vibTime'] = $result['productionOrder'][$productionOrderID][0]['vibrationTime'];
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['notes'] = $result['productionOrder'][$productionOrderID][0]['notes'];
					
					$productionOrders[$priority]['productionOrder'][$productionOrderID]['material'] = array();
					foreach( $result['productionOrder'][ key( $productionOrders[$priority]['productionOrder'] ) ] as $row )
					{
						
						if ( ! in_array( $row['materialType'], $batchMaterials ) )
						{
							$productionOrders[$priority]['productionOrder'][$productionOrderID]['material'][$row['materialID']] = array(
								"quantity" => round( $row['quantity'] * $row['scheduleQuantity'] ),
								"material" => $row['material'],
								"measureSingular" => $row['measureSingular'],
								"measurePlural" => 	$row['measurePlural']
							);
						}
						
					}
					
					$mixTime = $result['productionOrder'][$productionOrderID][0]['mixTime'];
					$taps = $result['productionOrder'][$productionOrderID][0]['taps'];
					$lowerSpec = $result['productionOrder'][$productionOrderID][0]['lowerSpec'];
					$upperSpec = $result['productionOrder'][$productionOrderID][0]['upperSpec'];
				}
				
				$productionOrders[$priority]['batching'] = array();
				
				
				
				
				
				
				if ( isset( $data['batching'] ) )
				{
				
					foreach ( $data['batching'] as $batchID => $batch )
					{
					
						$productionOrders[$priority]['batching'][$batchID] = array();
						
						foreach ( $result['mixers'] as $row )
						{
							if ( $row['mixerID'] == $batch['mixer'] )
							{
								$productionOrders[$priority]['batching'][$batchID]['mixer'] = $row['mixer'];
							}
						}
						
						$productionOrders[$priority]['batching'][$batchID]['mixTime'] = $mixTime;
						$productionOrders[$priority]['batching'][$batchID]['taps'] = $taps;
						$productionOrders[$priority]['batching'][$batchID]['lowerSpec'] = $lowerSpec;
						$productionOrders[$priority]['batching'][$batchID]['upperSpec'] = $upperSpec;
						$productionOrders[$priority]['batching'][$batchID]['totalMaterial'] = 0;
						$productionOrders[$priority]['batching'][$batchID]['material'] = array();
						
						foreach( $result['productionOrder'][ key( $productionOrders[$priority]['productionOrder'] ) ] as $row )
						{
							
							if ( in_array( $row['materialType'], $batchMaterials ) )
							{
								
								$productionOrders[$priority]['batching'][$batchID]['totalMaterial'] += $batch['material'][$row['materialID']];

								$productionOrders[$priority]['batching'][$batchID]['material'][$row['materialID']] = array(
									"quantity" => $batch['material'][$row['materialID']],
									"material" => $row['material'],
									"measureSingular" => $row['measureSingular'],
									"measurePlural" => 	$row['measurePlural'],
									"materialType" => $row['materialType']
								);
							}
							
						}
					
					}
				
				}
				else
				{
				
					$productionOrders[$priority]['batching'][1] = array();
					$productionOrders[$priority]['batching'][1]['mixer'] = "";
						
					foreach ( $result['mixers'] as $row )
					{
						if ( $row['mixerID'] == $data['mixer'] )
						{
							$productionOrders[$priority]['batching'][1]['mixer'] = $row['mixer'];
						}
					}
					
					$productionOrders[$priority]['batching'][1]['mixTime'] = $mixTime;
					$productionOrders[$priority]['batching'][1]['taps'] = $taps;
					$productionOrders[$priority]['batching'][1]['lowerSpec'] = $lowerSpec;
					$productionOrders[$priority]['batching'][1]['upperSpec'] = $upperSpec;
					$productionOrders[$priority]['batching'][1]['totalMaterial'] = 0;
					$productionOrders[$priority]['batching'][1]['material'] = array();
				
					foreach( $data['productionOrder'] as $productionOrderID => $totalMaterial )
					{
					
						foreach( $result['productionOrder'][$productionOrderID] as $row )
						{
						
							if ( in_array( $row['materialType'], $batchMaterials ) )
							{
							
								if ( ! isset( $productionOrders[$priority]['batching'][1]['material'][$row['materialID']] ) )
								{
									$productionOrders[$priority]['batching'][1]['material'][$row['materialID']] = array();
									$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['quantity'] = 0;
									$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['material'] = $row['material'];
									$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['measureSingular'] = $row['measureSingular'];
									$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['measurePlural'] = $row['measurePlural'];
								}
								
								$productionOrders[$priority]['batching'][1]['totalMaterial'] += ( $row['quantity'] * $row['scheduleQuantity'] );
								$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['quantity'] += ( $row['quantity'] * $row['scheduleQuantity'] );
								$productionOrders[$priority]['batching'][1]['material'][$row['materialID']]['materialType']  = $row['materialType'];
									
							}
						
						}
					
					}
				
				}
				
			}
			
		}
		
		return $productionOrders;
		
	}

?>
