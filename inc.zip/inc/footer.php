<div id="footer">
	<div id="footer_text">&copy; 2015 Chase Nedrow Manufacturing. All Rights Reserved.</div>
</div>