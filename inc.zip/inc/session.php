<?php
	
	if( session_id() == '' ) 
	{
		
		session_name( 'pims' );
	    session_start();
		
	}
	