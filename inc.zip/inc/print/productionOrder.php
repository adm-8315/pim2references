

<div class="book">
    <div class="page">
        <div class="subpage productionOrder">
			
        	<div class='title label'>
				<div class='left'></div>
				<div class='right'>
					<div>PRODUCTION ORDER</div>
					<div><?php echo $date; ?></div>
				</div>
				<div class='clearMe'></div>
			</div>
			
			
			
			
			<?php
						
			$first = true;
				
			foreach ( $productionOrder['productionOrder'] as $id => $data )
			{
				
				if ( $first )
				{
					echo "<div class='shape first'>";
					$first = false;
				}
				else
				{
					echo "<div class='shape'>";
				}
			?>
				
				<div class='header'><?php echo $data['product']; ?></div>
		
				<div class='form'>
		
					<div class='quantity'>
						<div class='header'>Qty.</div
						><div><?php echo $data['quantity']; ?></div>
					</div
					><div class='formID'>
						<div class='header'>Form ID</div
						><div><?php echo $data['form']; ?></div>
					</div
					><div class='formLocation'>
						<div class='header'>Form Loc.</div
						><div><?php echo $data['formLocation']; ?></div>
					</div>
		
				</div>
		
				<div class='form'>
			
					<div class='quantity'>
						<div class='header'>Job ID</div
						><div>&nbsp;</div>
					</div
					><div class='formID'>
						<div class='header'>Vib. Type</div
						><div><?php
							if ( ! empty( $data['vibType'] ) )
							{
								echo $data['vibType'];
							}
							else
							{
								echo "&nbsp;";
							}
						?></div>
					</div
					><div class='formLocation'>
						<div class='header'>Vib. Time</div
						><div><?php
							if ( ! empty( $data['vibTime'] ) )
							{
								echo $data['vibTime'] . " min.";
							}
							else
							{
								echo "&nbsp;";
							}
						?></div>
					</div>
			
				</div>
		
				<div class='materialInfo'>
	
					<div>
						<div class='amount header'>Amount</div
						><div class='material header'>Material</div
						><div class='verify header'>Verify</div>
					</div>
					
					<?php
					
					if ( count( $data['material'] ) > 0 )
					{
						
						foreach ( $data['material'] as $id => $material )
						{
						
							if ( floatval( $material['quantity'] ) > 1 )
							{
								$measure = $material['measurePlural'];
							}
							else
							{
								$measure = $material['measureSingular'];
							}
							
							$amount = floatval( $material['quantity'] );
							
							if ( ( $amount / $data['quantity'] ) != 1 )
							{
								if ( $amount <= 30 )
								{
									$amount = round( $amount, 1 );
								}
								else if ( $amount > 30 && $amount <= 100)
								{
									$amount = round( $amount, 0 );
								}
								else if ( $amount > 100 )
								{
									$amount = round( $amount, -1 );
								}
							}
						
							echo "<div>
								<div class='amount'>{$amount} {$measure}.</div
								><div class='material'>{$material['material']}</div
								><div class='verify'>&nbsp;</div>
							</div>";
						
						}
						
					}
					else
					{
						
						echo "<div>
							<div class='amount'>&nbsp;</div
							><div class='material'>&nbsp;</div
							><div class='verify'>&nbsp;</div>
						</div>";
						
					}
					
					if ( ! empty( $data['notes'] ) )
					{
						
						echo "
							<div><div class='notes header'>Notes</div></div>
							<div><div class='notes'>{$data['notes']}</div></div>
						";
						
					}
						
					?>
					
					
					
				</div>
		
			</div>
			
			<?php
				
			}
				
			foreach ( $productionOrder['batching'] as $batchID => $batch )
			{
				
			?>
			
        	<div class='batch'>
				
				<div class='mixInfo'>
					
					<div class='header'>Batch <?php echo $batchID; ?></div
					><div class='mixer'>
						<div class='header'>Mixer</div
						><div><?php echo $batch['mixer']; ?></div>
					</div
					><div class='mixTime'>
						<div class='header'>Mix Time</div
						><div><?php
						
							if ( ! empty( $batch['mixTime'] ) )
							{
								echo $batch['mixTime'] . " min";
							}
						?></div>
					</div>
					
				</div>
				
				<div class='materialInfo'>
				
					<div>
						<div class='amount header'>Amount</div
						><div class='material header'>Material</div
						><div class='verify header'>Verify</div>
					</div>
					
					<?php
					
						$waterMaterial = 0;
					
						foreach ( $batch['material'] as $id => $material )
						{
							
							if ( floatval( $material['quantity'] ) > 1 )
							{
								$measure = $material['measurePlural'];
							}
							else
							{
								$measure = $material['measureSingular'];
							}
							
							$amount = floatval( $material['quantity'] );
							
							if ( $amount <= 30 )
							{
								$amount = round( $amount, 1 );
							}
							else if ( $amount > 30 && $amount <= 100)
							{
								$amount = round( $amount, 0 );
							}
							else if ( $amount > 100 )
							{
								$amount = ( round($amount) % 5 === 0) ? round($amount) : round( ($amount + 5 / 2 ) / 5 ) * 5;
							}
							
							if (
								isset( $material['materialType'] ) &&
								(
									$material['materialType'] == 11 || // Castable - Dense
									$material['materialType'] == 12 || // Castable - Gun Mix
									$material['materialType'] == 13 || // Castable - Light Weight
									$material['materialType'] == 18 || // Mortar
									$material['materialType'] == 34    // Cement
								)
							) {
								$waterMaterial += $amount;
							}
							
							echo "
							<div>
								<div class='amount'>{$amount} {$measure}.</div
								><div class='material'>{$material['material']}</div
								><div class='verify'>&nbsp;</div>
							</div>";
						
						}
						
						$roundTo = 100;
						$iterationLimit = 10;

						$actualWater = floatval( $productionOrder['waterPercentage'] / 100 ) * floatval( $waterMaterial );
						$roundedWater = round( floatval( $productionOrder['waterPercentage'] / 100 ) * floatval( $waterMaterial ) / $roundTo ) * $roundTo;
						$marginError = abs( ($actualWater / $waterMaterial) - ($roundedWater / $waterMaterial) );

						while ( $marginError > .001 && $iterationLimit > 1 )
						{
							$iterationLimit--;
							$roundTo =  $roundTo / 10;
	
							$roundedWater = round( floatval( $productionOrder['waterPercentage'] / 100 ) * floatval( $waterMaterial ) / $roundTo ) * $roundTo;
							$marginError = abs( ($actualWater / $waterMaterial) - ($roundedWater / $waterMaterial) );
	
						}
						
						$waterAmount = $roundedWater;
						
						if ( $waterAmount > 0 )
						{
							
							if ( $waterAmount > 1 )
							{
								$measure = "Lbs";
							}
							else
							{
								$measure = "Lb";
							}
							
							echo "
							<div>
								<div class='amount'>" . $waterAmount . " " . $measure . " (" . $productionOrder['waterPercentage'] . "%)</div
								><div class='material'>Water</div
								><div class='verify'>&nbsp;</div>
							</div>";
						}
						
					?>
					
				</div>
				
			</div>
			
			<?php
				
			}	
			
			?>
			
			
			
        </div>    
    </div>
    <div class="page">
        <div class="subpage">
			
        	<div class='title label'>
				<div class='left'></div>
				<div class='right'>
					<div>PRODUCTION ORDER</div>
					<div><?php echo $date; ?></div>
				</div>
				<div class='clearMe'></div>
			</div>
			
			<div class='pourRecord'>
				
				<div class='header'>Pour</div>
				
				<div class='personnel'>
					<div class='header'>Personnel</div
					><div></div>
				</div>
				
				<div>
					<div class='startTime'>
						<div class='header'>Start Time</div
						><div></div>
					</div
					><div class='endTime'>
						<div class='header'>End Time</div
						><div></div>
					</div
					><div class='waterTemp'>
						<div class='header'>Water Temp</div
						><div></div>
					</div>
				</div>
			</div>
			
			<?php
				
			foreach ( $productionOrder['batching'] as $batchID => $batch )
			{
				
			?>
			
			
        	<div class='batchRecord'>
				
				<div class='batchHeader'>
					<div class='header'>&nbsp;</div
					><div class='header'>Batch <?php echo $batchID; ?> Record</div
					><div class='waterPercent'>
						<div class='header'>0.25%</div
						><div><?php 
							if ( floatval( $productionOrder['waterPercentage'] ) > 1 )
							{
								$measure = "Lbs";
							}
							else
							{
								$measure = "Lb";
							}
							
							echo round(floatval($batch['totalMaterial']) * .0025, 2) . " " . $measure . "."; 
						?></div>
					</div>
				</div>
				
				<div class='headers'> 
					<div class='header quantity'>Qty.</div
					><div class='header material'>Material</div
					><div class='header materialTemp'>Temp.</div
					><div class='header lotCode'>Lot</div
					><div class='header flowability'>Flowability</div>
				</div>
				
				<?php
				
				$flowabilityHeaders = array(
					"1",
					"2",
					"3",
					"Avg.",
					"Taps",
					"Low",
					"High",
				);
					
				for ( $i = 0; $i < 7; $i++ )
				{
					
					echo "<div>";
						echo "<div class='quantity'>&nbsp;</div>";
						echo "<div class='material'>";
							echo "&nbsp;";
						echo "</div>";
						echo "<div class='materialTemp'>&nbsp;</div>";
						echo "<div class='lotCode'>&nbsp;</div>";
						echo "<div class='flowability'>";
							echo "<div class='header'>{$flowabilityHeaders[$i]}</div>";
							echo "<div>";
							switch ( $i )
							{
								
								case 4:
									if ( isset( $batch['taps'] ) )
									{
										echo $batch['taps'];
									}
									break;
									
								case 5:
									if ( isset( $batch['lowerSpec'] ) )
									{
										echo $batch['lowerSpec'];
									}
									break;
									
								case 6:
									if ( isset( $batch['upperSpec'] ) )
									{
										echo $batch['upperSpec'];
									}
									break;
							}
							echo "</div>";
						echo "</div>";
					echo "</div>";
					
				}
					
				?>
				
			</div>
			
			<?php
				
			}	
			
			?>
			
			<div class='totals'>
				
				<div class='header'>Totals</div>
				
				<div class='headers'>
					<div>
						<div class='header quantity'>Qty.</div
						><div class='header material'>Material</div>
					</div
					><div>
						<div class='header quantity'>Qty.</div
						><div class='header material last'>Material</div>
					</div>
				</div>
				
				<?php
				
				// Process
					
				$materials = array();
				
				foreach ( $batch['material'] as $id => $material )
				{
					$materials[$id] = $material['material'];
				}
				
				foreach ( $productionOrder['productionOrder'] as $id => $tempOrder )
				{
					
					foreach ( $tempOrder['material'] as $id => $material )
					{
						$materials[$id] = $material['material'];
					}
					
				}
				
				//print_dev( $materials );
				$rows = ceil( count( $materials ) / 2 );
					
				
				// Display
					
				for ( $i = 0; $i < $rows; $i++ )
				{
					
					echo "
						<div class='totalRow'>
							<div>
								<div class='quantity'>&nbsp;</div
								><div class='material'>";
								
								if ( ! empty( $materials ) )
								{
									echo array_shift( $materials );
								}
								
					echo "</div>
							</div
							><div>
								<div class='quantity'>&nbsp;</div
								><div class='material last'>";
								
								if ( ! empty( $materials ) )
								{
									echo array_shift( $materials );
								}
								
					echo"</div>
							</div>
						</div>";
					
				}
					
				?>
				
				<div class='header'>Notes</div>
				<div class='note'></div>
				
			</div>
			
        </div>    
    </div>
</div>
