
<div class="book">
    <div class="page">
        <div class="subpage">
			
        	<div class='title label'>
				<div class='left'></div>
				<div class='right'>
					<div>PRODUCTION SCHEDULE</div>
					<div><?php echo $date; ?></div>
				</div>
				<div class='clearMe'></div>
			</div>
			
			<div class='day'>
				
				<div class='hour header'>
					<div class='time'></div>
					<div class='strip'>Strip</div>
					<div class='pour'>Pour</div>
				</div>
				
				<?php
				
				
				
				for ( $key = 0; $key < ( count( $productionOrders ) > count( $strip ) ? count( $productionOrders ) : count( $strip ) ); $key++ )
				{
					
					echo "<div class='hour'>";
					
						echo "<div class='time'>" . ( $key + 1 ) . "</div>";
						
						if ( isset( $strip[$key] ) )
						{
							echo "<div class='strip'>{$strip[$key]}</div>";
						}	
						else
						{
							echo "<div class='strip'></div>";
						}
						
						if ( isset( $productionOrders[$key] ) )
						{
							
							echo "<div class='pour'>";
							
							foreach ( $productionOrders[$key]['productionOrder'] as $po => $temp )
							{
									echo $temp['product'] . "<br/>";
							}
							
							echo "</div>";
							
						}	
						else
						{
							echo "<div class='pour'></div>";
						}
					
					echo "</div>";
					
				}
					
				?>
				
			</div>
			
			<div class='footer'>
				<div class='notes'><div class='header'>Notes</div><?php if ( isset( $_POST['overlay_schedule_print_notes'] ) ) { echo $_POST['overlay_schedule_print_notes']; } ?></div
				><div class='maintenance'><div class='header'>Maintenance</div><?php if ( isset( $_POST['overlay_schedule_print_maintenance'] ) ) { echo $_POST['overlay_schedule_print_maintenance']; } ?></div>
			</div>
			
        </div>    
    </div>
	
    <div class="page">
        <div class="subpage">
		</div>
	</div>
	
</div>