<?php

	/**
	 * Variables
	 */
	
	
	
	
	/**
	 * Permissions
	 */
	
	
	
	
	/**
	 * Menu Display
	 */

?>

<div id="menu">
	
	<div class='button no_select order' data-nav='order'>Production Order</div>
	
	<?php
	
		// Precast Product
	
		if ( isset( $_GET['report'] ) && $_GET['report'] == "precastProduct" )
		{
			echo "<div class='option no_select clickable current_page' data-block='' data-nav='report' data-report='precastProduct'>Precast Products</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='' data-nav='report' data-report='precastProduct'>Precast Products</div>";
		}
		
		// Schedule
	
		if ( isset( $_GET['report'] ) && $_GET['report'] == "schedule" )
		{
			echo "<div class='option no_select clickable current_page' data-block='' data-nav='report' data-report='schedule'>Schedule</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='' data-nav='report' data-report='schedule'>Schedule</div>";
		}
		
	?>
	
</div>