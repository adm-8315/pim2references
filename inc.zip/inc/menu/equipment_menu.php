<?php

	/**
	 * Variables
	 */
	
	
	
	
	/**
	 * Permissions
	 */
	
	
	
	
	/**
	 * Menu Display
	 */

?>

<div id="menu">
	
	<div class='button no_select job' data-nav='job'>New Job</div>
	
	<h4 class="no_select">Reports</h4>
	
	<?php
	
		// Job
	
		if ( isset( $_GET['report'] ) && $_GET['report'] == "job" )
		{
			echo "<div class='option no_select clickable current_page' data-block='' data-nav='report' data-report='job'>Job</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='' data-nav='report' data-report='job'>Job</div>";
		}
		
	
		// Equipment
	
		if ( isset( $_GET['report'] ) && $_GET['report'] == "equipment" )
		{
			echo "<div class='option no_select clickable current_page' data-block='26' data-nav='report' data-report='equipment'>Equipment</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='26' data-nav='report' data-report='equipment'>Equipment</div>";
		}
		
		
		// Grouping
		
		if ( isset( $_GET['report'] ) && $_GET['report'] == "grouping" )
		{
			echo "<div class='option no_select clickable current_page' data-block='27' data-nav='report' data-report='grouping'>Grouping</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='27' data-nav='report' data-report='grouping'>Grouping</div>";
		}
		
		
		// Item
		
		if ( isset( $_GET['report'] ) && $_GET['report'] == "item" )
		{
			echo "<div class='option no_select clickable current_page' data-block='28' data-nav='report' data-report='item'>Item</div>";
		}
		else
		{
			echo "<div class='option no_select clickable' data-block='28' data-nav='report' data-report='item'>Item</div>";
		}
	
	?>
	
</div>