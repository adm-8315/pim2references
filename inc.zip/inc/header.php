<div id="header">
	<a href="index.php?nav=home">
		<div id="logo"></div>
		<div id="header_text">Chase Nedrow</div>
	</a>
	
	<form action="" method="POST" onkeypress="return event.keyCode != 13;">
		<input type="text" id="header_search" name="jssearch_search" class="jssearch_search_input" autocomplete="off" style="z-index: 1" />
		<div class='jssearch_result_container'></div>
		<button id="header_search_button" style="z-index: 1"><span id="header_search_button_search">&nbsp;</span></button>
	</form>
</div>
