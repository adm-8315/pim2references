<?php
	
	$permissionsVars = array(
		'equipment' => 31,
		'finished_product_sales' => 9,
		'finished_product_stock' => 3,
		'grouping' => 32,
		'inventory_adjustment' => 11,
		'item' => 33,
		'job' => 41,
		'material_usage' => 7,
		'production' => 8,
		'raw_material_stock' => 2,
		'openOrder' => 42,
		'scrap' => 10,
		'stock_value' => 5,
		'tools_accessories_stock' => 4,
		'tools_accessories_value' => 6
	);