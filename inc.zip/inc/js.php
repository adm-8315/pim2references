<?php
	
	/**
	 * Javascript
	 */

	echo "
		<script src='js/jquery-1.9.1.js'></script>
		<script src='js/jquery-ui-1.10.3.custom.min.js'></script>
		<script src='js/overlay.js'></script>
		<script src='js/url_generator.js'></script>
	";
	
	if ( ! $load_login )
	{

		echo "<script src='js/jquery.mask.min.js'></script>";
		echo "<script src='js/menu.js'></script>";
		echo "<script src='js/toolbar.js'></script>";
		echo "<script src='js/search.js'></script>";
		echo "<script src='overlay/inventory_transaction/overlay_transaction.js'></script>";
		
		if ( ! empty( $permissions[1][1] ) )
		{
			echo "<script src='overlay/company_add/overlay_company_add.js'></script>";
			
			echo "<script src='overlay/user_add/overlay_user_add.js'></script>";
			echo "<script src='overlay/admin_ghosting/overlay_admin_ghosting.js'></script>";
		}
		
		if ( isset( $_SESSION['ghosting'] ) )
		{
			echo "<script src='overlay/admin_ghosting/overlay_admin_ghosting.js'></script>";
		}
		
		if ( 
			! empty( $permissions[1][1] ) ||
			! empty( $permissions[5][22] ) 
		) {
			echo "<script src='overlay/job_add/overlay_job_add.js'></script>";
		}
		
		if ( 
			! empty( $permissions[1][1] ) ||
			! empty( $permissions[5][23] ) 
		) {
			echo "<script src='overlay/equipment_add/overlay_equipment_add.js'></script>";
		}
		
		if ( 
			! empty( $permissions[1][1] ) ||
			! empty( $permissions[5][24] ) 
		) {
			echo "<script src='overlay/grouping_add/overlay_grouping_add.js'></script>";
		}
		
		if ( 
			! empty( $permissions[1][1] ) ||
			! empty( $permissions[5][25] ) 
		) {
			echo "<script src='overlay/item_add/overlay_item_add.js'></script>";
		}
		
		if ( 
			! empty( $permissions[1][1] ) ||
			! empty( $permissions[5][44] ) 
		) {
			echo "<script src='overlay/productionOrder_new/overlay_productionOrder_new.js'></script>";
		}
		
		switch( $_GET['nav'] )
		{
			
			case 'customer':
				echo "<script src='overlay/company_edit/overlay_company_edit.js'></script>";
				break;
				
			case 'equipment':
				echo "<script src='overlay/equipment_edit/overlay_equipment_edit.js'></script>";
				echo '<script src="overlay/equipment_equipment_log/overlay_equipment_log.js"></script>';
				echo '<script src="overlay/equipment_preventative_maintenance/overlay_preventative_maintenance.js"></script>';
				echo '<script src="overlay/equipment_preventative_maintenance_complete/overlay_preventative_maintenance_complete.js"></script>';
				break;
				
			case 'grouping':
				echo "<script src='overlay/grouping_edit/overlay_grouping_edit.js'></script>";
				echo "<script src='overlay/grouping_edit_equipment/overlay_grouping_edit_equipment.js'></script>";
				echo "<script src='overlay/grouping_edit_item/overlay_grouping_edit_item.js'></script>";
				break;
				
			case 'item':
				echo "<script src='overlay/item_edit/overlay_item_edit.js'></script>";
				echo "<script src='overlay/item_edit_inventory/overlay_item_edit_inventory.js'></script>";
				break;
				
			case 'job':
				echo "<script src='overlay/job_edit/overlay_job_edit.js'></script>";
				break;
			
			case 'material':
				echo "<script src='overlay/inventory_transaction/overlay_transaction_short.js'></script>";
				echo "<script src='overlay/material_edit/overlay_material_edit.js'></script>";
				echo "<script src='overlay/material_edit_inventory/overlay_material_edit_inventory.js'></script>";
				echo "<script src='overlay/material_edit_qc/overlay_material_edit_qc.js'></script>";
				break;
				
			case 'product':
				echo "<script src='overlay/inventory_transaction/overlay_transaction_short.js'></script>";
				echo "<script src='overlay/product_edit/overlay_product_edit.js'></script>";
				echo "<script src='overlay/material_edit_inventory/overlay_material_edit_inventory.js'></script>";
				echo "<script src='overlay/queue_add_product/overlay_queue_add_product.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_new/overlay_productionOrderTemplate_new.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_edit_material/overlay_productionOrderTemplate_edit_material.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_edit_curing/overlay_productionOrderTemplate_edit_curing.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_edit_drying/overlay_productionOrderTemplate_edit_drying.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_edit_packaging/overlay_productionOrderTemplate_edit_packaging.js'></script>";
				echo "<script src='overlay/productionOrderTemplate_edit_qc/overlay_productionOrderTemplate_edit_qc.js'></script>";
				break;
				
			case 'schedule':
				echo "<script src='js/resizeSchedule.js'></script>";
				echo "<script src='overlay/schedule_pour/overlay_schedule_pour.js'></script>";
				echo "<script src='overlay/schedule_batching/overlay_schedule_batching.js'></script>";
				echo "<script src='overlay/schedule_strip/overlay_schedule_strip.js'></script>";
				echo "<script src='overlay/schedule_fire/overlay_schedule_fire.js'></script>";
				echo "<script src='overlay/schedule_print_production/overlay_schedule_print_production.js'></script>";
				break;
				
			case 'warning':
			case 'report':
				echo "<script src='js/resize.js'></script>";
				
				if ( isset( $_GET['report'] ) )
				{
					
					switch ( $_GET['report'] )
					{
					
						case 'openOrder':
							echo "<script src='overlay/productionOrder_new/overlay_productionOrder_new.js'></script>";
							break;
					
					}
					
				}
				
				break;
				
			case 'exotherm':
				echo "<script src='js/resize.js'></script>";
				echo "<script src='overlay/exotherm_start/overlay_exotherm_start.js'></script>";
				break;
			
		}
		
	}
?>