<?php

	/**
	 * CSS
	 */
	
	echo "
		<link rel='stylesheet' href='css/bootstrap.min.css'>
		<link rel='stylesheet' href='css/sticky-footer.css'>
		<link rel='stylesheet' href='css/smoothness/jquery-ui-1.10.3.custom.css'>
		<link rel='stylesheet' href='css/screen-styles.css'>
		<link rel='stylesheet' media='screen only and (max-width: 667px)' href='css/mobile.css' />
	";
	
	if ( ! $load_login && $_GET['nav'] != "print" )
	{
		
		echo "
			<link rel='stylesheet' href='css/overlay.css'>
			<link rel='stylesheet' href='css/search.css'>
			<link rel='stylesheet' href='css/menu.css'>
			<link rel='stylesheet' href='css/toolbar.css'>
			<link rel='stylesheet' href='css/transaction.css'>
		";
		
		
		switch ( $_GET['nav'] )
		{
			
			case 'exotherm':
				echo "<link rel='stylesheet' href='css/exotherm.css'>";
				break;

			case 'user_profile':
				echo "<link rel='stylesheet' href='css/user_profile.css'>";
				break;

			case 'permissions':
				echo "<link rel='stylesheet' href='css/permissions.css'>";
				break;
				
			case 'warning':
			case 'report':
				echo "<link rel='stylesheet' href='css/report.css'>";
				echo "<link rel='stylesheet' media='screen only and (max-width: 667px)' href='css/mobile_report.css'>";
				echo "<link rel='stylesheet' media='print' href='css/print.css'>";
				break;
		
			case 'customer':
				echo "<link rel='stylesheet' href='css/report.css'>";
				echo "<link rel='stylesheet' href='css/customer.css'>";
				break;
		
			case 'material':
			case 'product':
				echo "<link rel='stylesheet' href='css/transaction.css'>";
				echo "<link rel='stylesheet' href='css/material.css'>";
				echo "<link rel='stylesheet' media='screen only and (max-width: 667px)' href='css/mobile_material.css' />";
				break;
				
			case 'job':
				echo "<link rel='stylesheet' href='css/job.css'>";
				echo "<link rel='stylesheet' href='css/newJob.css'>";
				break;
				
			case 'item':
			case 'equipment':
			case 'grouping':
				echo "<link rel='stylesheet' href='css/individual.css'>";
				break;
				
			case 'add_equipment':
			case 'add_grouping':
			case 'add_item':
				echo "<link rel='stylesheet' href='css/add.css'>";
				break;
				
			case 'schedule':
				echo "<link rel='stylesheet' href='css/schedule.css'>";
				break;
				
			case 'productionOrder':
				echo "<link rel='stylesheet' href='css/productionOrder.css'>";
				break;
				
		}
		
		
	}
	else if ( ! $load_login && $_GET['nav'] == "print" )
	{
		
		echo "
			<link rel='stylesheet' media='print' href='css/print.css' />
		";
		
	}
	else
	{
		
		echo "
			<link rel='stylesheet' href='css/login.css'>
			<link rel='stylesheet' href='css/bootstrap-responsive.min.css'>
		";
		
	}
		
?>