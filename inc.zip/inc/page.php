<?php

	/**
	 * Variables
	 */
	
	$page = array();



	/**
	 * Process
	 */
	
	$explode = explode("?", $_SERVER["REQUEST_URI"]);
	$uri = $explode[0];

	$url = 'http';

	if ( isset( $_SERVER["HTTPS"] ) && $_SERVER["HTTPS"] == "on" )
	{
		$url .= "s";
	}

	$url .= "://";

	if ( $_SERVER["SERVER_PORT"] != "80" )
	{
	    $page['url'] = $url . $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $uri;
	}
	else
	{
	    $page['url'] = $url . $_SERVER["SERVER_NAME"] . $uri;
	}
	
	
	$server_name = explode( ".", $_SERVER["SERVER_NAME"] );
	
	$subdomain = "";
	if ( count($server_name) > 2 )
	{
		
		$page['subdomain'] = strtolower( $server_name[ count($server_name) - 3 ] );	
		$page['domain'] = strtolower( $server_name[ count($server_name) - 2 ] );
		$page['tld'] = strtolower( $server_name[ count($server_name) - 1 ] );
		
	}
	else if ( count( $server_name ) == 2 )
	{
		
		$page['subdomain'] = "";
		$page['domain'] = strtolower( $server_name[ count($server_name) - 2 ] );
		$page['tld'] = strtolower( $server_name[ count($server_name) - 1 ] );
		
	}
	else if ( count( $server_name ) == 1 )
	{
		
		$page['subdomain'] = "";
		$page['domain'] = strtolower( $server_name[ count($server_name) - 1 ] );
		$page['tld'] = "";
		
	}

