# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.38)
# Database: livemerge
# Generation Time: 2015-10-01 20:26:59 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table permissionBlock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissionBlock`;

CREATE TABLE `permissionBlock` (
  `permissionBlockID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permissionGroup` int(11) unsigned NOT NULL,
  `permissionBlock` varchar(255) NOT NULL DEFAULT '',
  `permissionBlockDescription` varchar(255) DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`permissionBlockID`),
  KEY `permissionBlock_permissionGroup_fk` (`permissionGroup`),
  CONSTRAINT `permissionBlock_permissionGroup_fk` FOREIGN KEY (`permissionGroup`) REFERENCES `permissionGroup` (`permissionGroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `permissionBlock` WRITE;
/*!40000 ALTER TABLE `permissionBlock` DISABLE KEYS */;

INSERT INTO `permissionBlock` (`permissionBlockID`, `permissionGroup`, `permissionBlock`, `permissionBlockDescription`, `active`)
VALUES
	(1,1,'Permissions','Who has the access to change permissions',1),
	(2,3,'Raw Material Stock','Report for Raw Material Stock',1),
	(3,3,'Finished Product Stock','Report for Finished Product Stock',1),
	(4,3,'Tools and Accessories Stock','Report for Tools and Accessories Stock',1),
	(5,3,'Stock Value','Report for Stock Value',1),
	(6,3,'Tools and Accessories Value','Report for Tools and Accessories Value',1),
	(7,3,'Material Usage','Report for Material Usage',1),
	(8,3,'Production','Report for Production',1),
	(9,3,'Finished Product Sales','Report for Finished Product Sales',1),
	(10,3,'Scrap','Report for Scrapped Materials',1),
	(11,3,'Inventory Adjustment','Report for Adjusted Inventory',1),
	(12,2,'Receive','Ability to perform Receive Transaction',1),
	(13,2,'Produce','Ability to perform Produce Transaction',1),
	(14,2,'Transfer','Ability to perform Transfer Transaction',1),
	(15,2,'Ship','Ability to perform Ship Transaction',1),
	(16,2,'Scrap','Ability to perform Scrap Transaction',1),
	(17,2,'Use','Ability to perform Use Transaction',1),
	(18,2,'Adjust','Ability to perform Adjust Transaction',1),
	(20,6,'Stock Level Warning Edit','Who can edit stock level warning amounts',1),
	(21,3,'Stock Level Warning','Report for Stock Level Warnings',1),
	(22,5,'New Job','Ability to create a new job',1),
	(23,5,'Add Equipment','Ability to create a new piece of equipment',1),
	(24,5,'Add Grouping','Ability to generate a new grouping',1),
	(25,5,'Add Item','Ability to create a new item',1),
	(26,6,'Edit Equipment','Ability to Edit Equpiment ',1),
	(27,6,'Edit Grouping','Ability to Edit Groupings',1),
	(28,6,'Edit Item','Ability to Edit Items',1),
	(29,6,'Edit Job','Ability to Edit Jobs',1),
	(30,3,'Shortage','Report for Shortage of Items',1),
	(31,3,'Equipment','Report for Equipment',1),
	(32,3,'Grouping','Report for Grouping',1),
	(33,3,'Item','Report for Item',1),
	(36,7,'Company Standards','Who can edit quality control standards',1),
	(37,7,'Manufacturer Standards','Who can edit manufacturer recomendations',1),
	(38,3,'Quality Control Display','Who can view quality control information',0),
	(40,3,'Schedule','Schedule',1),
	(41,3,'Job','Report for Jobs',1);

/*!40000 ALTER TABLE `permissionBlock` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table permissionGroup
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissionGroup`;

CREATE TABLE `permissionGroup` (
  `permissionGroupID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permissionGroup` varchar(255) NOT NULL DEFAULT '',
  `locationBased` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`permissionGroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `permissionGroup` WRITE;
/*!40000 ALTER TABLE `permissionGroup` DISABLE KEYS */;

INSERT INTO `permissionGroup` (`permissionGroupID`, `permissionGroup`, `locationBased`)
VALUES
	(1,'Permission',0),
	(2,'Transaction',1),
	(3,'Report',1),
	(5,'Add',1),
	(6,'Edit',1),
	(7,'Quality Control',1);

/*!40000 ALTER TABLE `permissionGroup` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table permissionLink
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissionLink`;

CREATE TABLE `permissionLink` (
  `user` int(11) unsigned NOT NULL,
  `permissionBlock` int(11) unsigned NOT NULL,
  `allLocation` tinyint(1) NOT NULL DEFAULT '0',
  `location` int(11) unsigned DEFAULT NULL,
  KEY `permissionLink_permissionBlock_fk` (`permissionBlock`),
  KEY `location` (`location`,`user`,`permissionBlock`),
  CONSTRAINT `permissionLink_location_fk` FOREIGN KEY (`location`) REFERENCES `location` (`locationID`),
  CONSTRAINT `permissionLink_permissionBlock_fk` FOREIGN KEY (`permissionBlock`) REFERENCES `permissionBlock` (`permissionBlockID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `permissionLink` WRITE;
/*!40000 ALTER TABLE `permissionLink` DISABLE KEYS */;

INSERT INTO `permissionLink` (`user`, `permissionBlock`, `allLocation`, `location`)
VALUES
	(1,1,0,NULL),
	(2,1,0,NULL),
	(3,1,0,NULL),
	(4,1,0,NULL),
	(5,2,1,NULL),
	(5,3,1,NULL),
	(5,4,1,NULL),
	(5,5,1,NULL),
	(5,6,1,NULL),
	(5,7,1,NULL),
	(5,8,1,NULL),
	(5,9,1,NULL),
	(5,10,1,NULL),
	(5,11,1,NULL),
	(5,21,1,NULL),
	(5,30,1,NULL),
	(5,40,1,NULL),
	(6,1,0,NULL),
	(13,1,0,NULL),
	(12,2,1,NULL),
	(12,3,1,NULL),
	(12,4,1,NULL),
	(12,5,0,1),
	(12,7,1,NULL),
	(12,8,1,NULL),
	(12,10,0,1),
	(12,11,0,1),
	(12,12,0,1),
	(12,17,0,1),
	(12,18,0,1),
	(12,20,1,NULL),
	(12,21,1,NULL),
	(12,22,1,NULL),
	(12,23,1,NULL),
	(12,24,1,NULL),
	(12,25,1,NULL),
	(12,26,1,NULL),
	(12,27,1,NULL),
	(12,28,1,NULL),
	(12,29,1,NULL),
	(12,31,1,NULL),
	(12,32,1,NULL),
	(12,33,1,NULL),
	(12,41,1,NULL),
	(8,2,0,1),
	(8,3,0,1),
	(7,2,0,1),
	(7,2,0,2),
	(7,3,0,1),
	(7,3,0,2),
	(7,12,0,2),
	(7,13,0,2),
	(7,14,0,1),
	(7,14,0,2),
	(7,16,0,2),
	(7,17,0,1),
	(7,17,0,2),
	(7,18,0,2),
	(7,20,0,2),
	(7,21,0,2),
	(11,2,1,NULL),
	(11,3,1,NULL),
	(11,4,1,NULL),
	(11,5,0,1),
	(11,5,0,2),
	(11,7,1,NULL),
	(11,8,1,NULL),
	(11,10,0,1),
	(11,10,0,2),
	(11,11,0,1),
	(11,11,0,2),
	(11,20,1,NULL),
	(11,21,1,NULL),
	(11,40,1,NULL),
	(14,2,0,1),
	(14,3,0,1),
	(14,3,0,2),
	(14,7,0,1),
	(14,8,0,1),
	(14,10,0,1),
	(14,11,0,1),
	(14,21,0,1),
	(14,21,0,2),
	(14,40,1,NULL);

/*!40000 ALTER TABLE `permissionLink` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
