<?php
	
	function print_dev ( $variable, $indent = 0 )
	{
		
		$i = 0;
		$numItems = count( $variable );
		
		if ( $indent == 0 )
		{
			echo "<pre>";
		}
		
		if ( gettype( $variable ) == "array" )
		{
			
			echo "<table>";
			
			foreach ( $variable as $key => $subVariable )
			{
				
				if ( gettype( $subVariable ) == "array" )
				{
					
					echo "<tr>";
					
						echo "<td>";
							if ( $indent != 0 )
							{
								echo "&nbsp;";
							}
							echo "[" . print_byType( $key ) . "]";
						echo "</td>";
						
						echo "<td>";
							echo "&nbsp;= {";
						echo "</td>";
						
					echo "</tr>";
					
					echo "<tr>";
					
						echo "<td>";
						echo "</td>";
						
						echo "<td>";
							print_dev( $subVariable, $indent + 1 );
						echo "</td>";
						
					echo "</tr>";
					
					echo "<tr>";
					
						echo "<td>";
							if ( ++$i === $numItems )
							{
								echo "}";
							}
							else
							{
								echo "},";
							}
						echo "</td>";
				
						echo "<td>";
						echo "</td>";
						
					echo "</tr>";
					
				}
				else
				{
					
					echo "<tr>";
					
						echo "<td>";
							if ( $indent != 0 )
							{
								echo "&nbsp;";
							}
							echo "[" . print_byType( $key ) . "]";
						echo "</td>";
						
						echo "<td>";
							if ( ++$i === $numItems )
							{
								 echo "&nbsp;= " . print_byType( $subVariable );
							}
							else
							{
								echo "&nbsp;= " . print_byType( $subVariable ) . ",";
							}
						echo "</td>";
						
					echo "</tr>";
					
				}
				
			}
			
			echo "</table>";
			
		}
		else
		{
			echo print_byType( $variable );
		}
		
		if ( $indent == 0 )
		{
			echo "</pre>";
		}
	
	}
	
	function print_byType ( $variable )
	{
		
		if ( gettype( $variable ) == "string" )
		{
			return "\"" . $variable . "\"";
		}
		else if ( $variable === null )
		{
			return "null";
		}
		else
		{
			return $variable;
		}
		
	}

?>