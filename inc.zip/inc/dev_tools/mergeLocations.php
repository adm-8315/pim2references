<?php

	/**
	 * Includes
	 */
	
	require_once( "../dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	// Keep, Remove
	
	$combine = array(
		array( 2, 82 ),
		array( 29, 75 ),
		array( 28, 41 ),
		array( 84, 51 ),
		array( 22, 85 ),
		array( 78, 89 ),
		array( 53, 54 )
	);
	
	$cllTables = array(
		"job",
		"companyLocationLinkPersonLink",
		"materialTransaction",
		"productTransaction",
		"materialInventory",
		"productInventory",
		"productConsumerLink",
		"companyLocationLinkNumberLink"
	);
	
	$locationTables = array(
		"userLocationLink",
		"locationRequirementLink",
		"equipment",
		"grouping",
		"itemInventory"
	);
	
	
	/**
	 * MySQL
	 */
	
	foreach ( $combine as $combination )
	{
		
		$query = "
			SELECT
				*,
				FLOOR( .5 * (? + cll.company) * (? + cll.company + 1) + cll.company ) as 'cantor'
			FROM
				companyLocationLink cll
			WHERE
				location = ?
		";
		
		$values = array(
			$combination[0],
			$combination[0],
			$combination[1]
		);
		
		$result['scout'] = dbquery( $query, $values );
		
		foreach ( $result['scout'] as $row )
		{
			
			$query = "
				INSERT IGNORE INTO
					companyLocationLink
					( companyLocationLinkID, company, location )
					VALUES
					( ?, ?, ? )
			";
			
			$values = array(
				$row['cantor'],
				$row['company'],
				$combination[0]
			);
			
			$result['temp'] = dbquery( $query, $values );
			
		}
		
		$query = "
			SELECT
				cll.companyLocationLinkID as 'keep',
				cll2.companyLocationLinkID as 'remove'
			FROM
				companyLocationLink cll
			LEFT JOIN
				companyLocationLink cll2
				ON cll.company = cll2.company
			WHERE
				cll.location = ?
			AND
				cll2.location = ?
			ORDER BY
				cll.company ASC
	
		";
		
		$values = array(
			$combination[0],
			$combination[1]
		);
		
		$result['companyLocationLinkIDs'] = dbquery( $query, $values );
		
		echo "CLL IDs: ";
		
		print_r( $result['companyLocationLinkIDs'] );
		
		echo "<br />";
		
		foreach ( $result['companyLocationLinkIDs'] as $row )
		{
			
			foreach ( $cllTables as $table )
			{
				
				$query = "
					UPDATE IGNORE
						{$table}
					SET
						companyLocationLink = ?
					WHERE
						companyLocationLink = ?
				";
				
				$values = array(
					$row['keep'],
					$row['remove']
				);
				
				$result['update'] = dbquery( $query, $values );
				
				$query = "
					DELETE
						FROM
							?
						WHERE
							companyLocationLink = ?
				";
	
				$values = array(
					$table,
					$row['remove']
				);
	
				$result['delete'] = dbquery( $query, $values );
				
			}
	
			// remove old companyLocationLink
	
			$query = "
				DELETE
					FROM
						companyLocationLink
					WHERE
						companyLocationLinkID = ? 
				";
	
			$values = array(
				$row['remove']
			);
	
			$result['delete'] = dbquery( $query, $values );
		
		}
		
		foreach ( $locationTables as $table )
		{
		
			$query = "
				UPDATE IGNORE
					{$table}
				SET
					location = ?
				WHERE
					location = ?
			";
		
			$values = array(
				$combination[0],
				$combination[1]
			);
		
			$result['update'] = dbquery( $query, $values );
		
		}
		
		// Update user
		
		$query = "
			UPDATE IGNORE
				user
			SET
				defaultLocation = ?
			WHERE
				defaultLocation = ?
		";
		
		$values = array(
			$combination[0],
			$combination[1]
		);
		
		$result['update'] = dbquery( $query, $values );
		
		// Delete Location
		
		$query = "
			DELETE
				FROM
					location
				WHERE
					locationID = ?
			";
			
		$values = array(
			$combination[1]
		);
		
		$result['delete'] = dbquery( $query, $values );
		
		echo "Delete location: ";
		
		print_r( $result['delete'] );
		
		echo "<br />";
		
	}
	
	echo "Complete";
	
?>