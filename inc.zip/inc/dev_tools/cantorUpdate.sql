SET FOREIGN_KEY_CHECKS=0;

UPDATE
	productTransaction t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	productInventory t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	productConsumerLink t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	materialTransaction t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	materialInventory t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	job t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	companyLocationLinkPersonLink t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
UPDATE
	companyLocationLinkNumberLink t
LEFT JOIN
	companyLocationLink cll
	ON t.companyLocationLink = cll.companyLocationLinkID
SET
	t.companyLocationLink = FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company )
WHERE
	FLOOR( .5 * (cll.location + cll.company) * (cll.location + cll.company + 1) + cll.company ) != cll.companyLocationLinkID;
	
SET FOREIGN_KEY_CHECKS=1;
	