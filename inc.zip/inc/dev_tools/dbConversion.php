<?php

	/**
	 * Includes
	 */
	
	require_once( "../dbfunc.php" );
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	$conversion = array(
		"A C Foundry" => 428,
		"Ajax" => 3547,
		"AK" => 12,
		"B & R" => 545,
		"Bremen" => 686,
		"Bulldog Boiler" => 3468,
		"C & D Welding"  => 1252,
		"Continental" => 1154,
		"Dalton Foundry" => 431,
		"Detroit Boiler" => 757,
		"DTE Trenton" => 2050,
		"Foundry Products" => 1734,
		"Gerdau" => 4965,
		"GLW" => 1912,
		"Hitachi" => 18258,
		"I & A"  => 2562,
		"IST" => 5734,
		"JF Harrison Scot" => 8840,
		"JF Harrison" => 5840,
		"Johnston" => 5307,
		"Metro Alloys" => 6272,
		"Mich Sugar" => 7480,
		"Midwest" => 2209,
		"NARCO Gerdau" => 4965,
		"Nexteer" => 18263,
		"Nor-Cote" => 7080,
		"Phoenix" => 6763,
		"Plymouth Tube" => 5293,
		"Precision Coatings" => 18255,
		"Premier Furnace" => 7293,
		"Roberts Sinto" => 4119,
		"RTC" => 9246,
		"SMC AK" => 12,
		"SMC Gerdau Monroe" => 18261,
		"SMC Gerdau St. Paul" => 18262,
		"SMC Gerdau" => 4965,
		"SMC GLW" => 1912,
		"SMC Republic" => 18264,
		"SMC Riverdale" => 18265,
		"Sterco" => 1355,
		"Super Radiator" => 6647,
		"Superior" => 3841,
		"Tetron" => 277,
		"Vesuvius" => 6824,
		"Ward Mfg" => 18259,
		"Woodworth" => 18254,
		"Wyandotte Power" => 8831,
		"Xertech" => 3504
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "SET FOREIGN_KEY_CHECKS=0;";
	$result = dbquery( $query, array() );
	
	
	$query = "
		DROP TABLE IF EXISTS `additive`;
	";
	
	$result = dbquery( $query, array() );
		
	$query = "
		CREATE TABLE `additive` (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`material` int(11) unsigned NOT NULL,
		`std` double DEFAULT NULL,
		`lowerSpec` double DEFAULT NULL,
		`upperSpec` double DEFAULT NULL,
		PRIMARY KEY (`id`),
		KEY `additive_material_fk` (`material`),
		CONSTRAINT `additive_material_fk` FOREIGN KEY (`material`) REFERENCES `material` (`materialID`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `productType`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productType` (
		  `productTypeID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		  `productType` varchar(255) DEFAULT NULL,
		  PRIMARY KEY (`productTypeID`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );

	$query = "
		INSERT IGNORE INTO `productType` (`productTypeID`, `productType`)
		VALUES
			(16,'Precast Product'),
			(26,'Tundish');
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `product`;
	";

	$result = dbquery( $query, array() );

	$query = "
		CREATE TABLE `product` (
		`productID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`productType` int(11) unsigned NOT NULL,
		`cost` int(11) DEFAULT NULL,
		`measure` int(11) DEFAULT NULL,
		`product` varchar(255) DEFAULT NULL,
		PRIMARY KEY (`productID`),
		KEY `product_productType_fk` (`productType`),
		CONSTRAINT `product_productType_fk` FOREIGN KEY (`productType`) REFERENCES `productType` (`productTypeID`)
		) ENGINE=InnoDB AUTO_INCREMENT=974 DEFAULT CHARSET=utf8;
	";

	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `productConsumerLink`;
	";

	$result = dbquery( $query, array() );

	$query = "
		CREATE TABLE `productConsumerLink` (
		`product` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`companyLocationLink` int(11) unsigned NOT NULL,
		PRIMARY KEY (`product`,`companyLocationLink`),
		UNIQUE KEY `companyLocationLink` (`companyLocationLink`,`product`),
		KEY `product` (`product`,`companyLocationLink`),
		CONSTRAINT `productConsumerLink_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`productID`),
		CONSTRAINT `productConsumerLink_companyLocationLink_fk` FOREIGN KEY (`companyLocationLink`) REFERENCES `companyLocationLink` (`companyLocationLinkID`)
		) ENGINE=InnoDB AUTO_INCREMENT=974 DEFAULT CHARSET=utf8;
	";

	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `productInventory`;
	";

	$result = dbquery( $query, array() );

	$query = "
		CREATE TABLE `productInventory` (
		`productInventoryID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`product` int(11) unsigned NOT NULL,
		`companyLocationLink` int(11) unsigned DEFAULT NULL,
		`stock` int(11) unsigned NOT NULL,
		`inProgress` int(11) unsigned NOT NULL DEFAULT '0',
		`stockLevelWarning` int(11) unsigned NOT NULL DEFAULT '0',
		PRIMARY KEY (`productInventoryID`),
		UNIQUE KEY `material` (`product`,`companyLocationLink`),
		KEY `inventory_material_fk` (`product`),
		KEY `inventory_owner_fk` (`companyLocationLink`),
		CONSTRAINT `productInventory_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`productID`),
		CONSTRAINT `productInventory_companyLocationLink_fk` FOREIGN KEY (`companyLocationLink`) REFERENCES `companyLocationLink` (`companyLocationLinkID`)
		) ENGINE=InnoDB AUTO_INCREMENT=18808 DEFAULT CHARSET=utf8;
	";

	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `productTransaction`;
	";
	
	$result = dbquery( $query, array() );

	$query = "
		CREATE TABLE `productTransaction` (
		`productTransactionID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`productInventory` int(11) unsigned NOT NULL,
		`transactionType` int(11) unsigned NOT NULL,
		`value` int(11) NOT NULL,
		`cost` double unsigned DEFAULT NULL,
		`companyLocationLink` int(11) unsigned DEFAULT NULL,
		`user` int(11) unsigned NOT NULL,
		`timestamp` date NOT NULL,
		`notes` varchar(255) DEFAULT NULL,
		PRIMARY KEY (`productTransactionID`),
		KEY `transaction_inventory_fk` (`productInventory`),
		KEY `transaction_transactionType_fk` (`transactionType`),
		KEY `transaction_customer_fk` (`companyLocationLink`),
		KEY `transaction_user_fk` (`user`),
		CONSTRAINT `productTransaction_productInventory_fk` FOREIGN KEY (`productInventory`) REFERENCES `productInventory` (`productInventoryID`),
		CONSTRAINT `productTransaction_companyLocationLink_fk` FOREIGN KEY (`companyLocationLink`) REFERENCES `companyLocationLink` (`companyLocationLinkID`),
		CONSTRAINT `productTransaction_transactionType_fk` FOREIGN KEY (`transactionType`) REFERENCES `transactionType` (`transactionTypeID`),
		CONSTRAINT `productTransaction_user_fk` FOREIGN KEY (`user`) REFERENCES `user` (`userID`)
		) ENGINE=InnoDB AUTO_INCREMENT=45266 DEFAULT CHARSET=utf8;
	";

	$result = dbquery( $query, array() );
	
	
	$query = "
		RENAME TABLE transaction TO materialTransaction;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE materialTransaction CHANGE transactionID materialTransactionID INT
	";
	
	$result = dbquery( $query, array() );





	$query = "
		SELECT
			m.materialID as 'productID',
			m.materialType as 'productType',
			m.cost as 'cost',
			m.measure as 'measure',
			m.material as 'product'
		FROM
			material m
		WHERE
			m.materialType = 16
		OR
			m.materialType = 26
		ORDER BY
			m.material ASC
	";

	$values = array();

	$result['products'] = dbquery( $query, $values );
	
	
	
	
	
	
	if ( ! empty( $result['products'] ) )
	{

		$query = "
			INSERT IGNORE INTO `product` (`productID`, `productType`, `cost`, `measure`, `product`)
			VALUES
		";

		$values = array();

		$query2 = "
			INSERT IGNORE INTO `productConsumerLink` (`product`, `companyLocationLink`)
			VALUES
		";

		$values2 = array();

		foreach ( $result['products'] as $row )
		{
			$found = false;
	
			foreach ( $conversion as $key => $value )
			{
		
				if ( substr( $row['product'], 0, strlen( $key ) ) === $key )
				{
			
					$found = true;
			
					$query .= "( ?, ?, ?, ?, ? ),";
					$values[] = $row['productID'];
					$values[] = $row['productType'];
					$values[] = $row['cost'];
					$values[] = $row['measure'];
					$values[] = trim( str_replace( $key, '', $row['product'] ) );
			
					$query2 .= "( ?, ? ),";
					$values2[] = $row['productID'];
					$values2[] = $value;
			
					break;
			
				}
		
			}
	
			if ( ! $found )
			{
		
				$query .= "( ?, ?, ?, ?, ? ),";
				$values[] = $row['productID'];
				$values[] = $row['productType'];
				$values[] = $row['cost'];
				$values[] = $row['measure'];
				$values[] = trim( $row['product'] );
		
				$query2 .= "( ?, ? ),";
				$values2[] = $row['productID'];
				$values2[] = $value;
		
			}
	
		}

		$query = substr( $query, 0, -1 );
		$query2 = substr( $query2, 0, -1 );

		$result['productInsert'] = dbquery( $query, $values );
		$result['productConsumer'] = dbquery( $query2, $values2 );
		
	}
	
	
	
	
	
	
	$values = array();
	
	$query = "
		INSERT IGNORE INTO productInventory
		SELECT
			mi.materialInventoryID as 'productInventoryID',
			mi.material as 'product',
			mi.companyLocationLink,
			mi.stock,
			mi.inProgress,
			mi.stockLevelWarning
		FROM
			material m
		LEFT JOIN
			materialInventory mi
			ON m.materialID = mi.material
		LEFT JOIN
			companyLocationLink cll
			ON cll.companyLocationLinkID = mi.companyLocationLink
		LEFT JOIN
			company c
			ON c.companyID = cll.company
		LEFT JOIN
			location l
			ON l.locationID = cll.location
		WHERE
			(
				m.materialType = 16
			OR
				m.materialType = 26
			)
	";

	$values = array();

	$result['transaction'] = dbquery( $query, $values );


	$query = "
		INSERT IGNORE INTO productTransaction
		SELECT
			t.materialTransactionID as 'productTransactionID',
			t.materialInventory as 'productInventory',
			t.transactionType,
			t.value,
			t.cost,
			t.companyLocationLink,
			t.user,
			t.timestamp,
			t.notes
		FROM
			material m
		LEFT JOIN
			materialInventory mi
			ON m.materialID = mi.material
		LEFT JOIN
			companyLocationLink cll
			ON cll.companyLocationLinkID = mi.companyLocationLink
		LEFT JOIN
			company c
			ON c.companyID = cll.company
		LEFT JOIN
			location l
			ON l.locationID = cll.location
		LEFT JOIN
			materialTransaction t
			ON t.materialInventory = mi.materialInventoryID
		WHERE
			(
				m.materialType = 16
			OR
				m.materialType = 26
			)
		AND
			t.materialTransactionID is not null
	";

	$values = array();

	$result['transaction'] = dbquery( $query, $values );
	
	
	
	
	
	
	
	
	
	
	$query = "
		DROP TABLE IF EXISTS `locationNumberLink`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		DROP TABLE IF EXISTS `companyLocationLinkNumberLink`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `companyLocationLinkNumberLink` (
		`companyLocationLink` int(11) unsigned NOT NULL,
		`number` int(11) unsigned NOT NULL,
		KEY `location` (`companyLocationLink`,`number`),
		KEY `locationNumberLink_number_fk` (`number`),
		CONSTRAINT `companyLocationLinkNumberLink_companyLocationLink_fk` FOREIGN KEY (`companyLocationLink`) REFERENCES `companyLocationLink` (`companyLocationLinkID`),
		CONSTRAINT `companyLocationLinkNumberLink_number_fk` FOREIGN KEY (`number`) REFERENCES `number` (`numberID`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `form` (
		`formID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`formTag` varchar(4) DEFAULT '',
		`formLocation` varchar(255) DEFAULT '',
		`formQuantity` int(11) NOT NULL DEFAULT '1',
		`formPieces` int(11) NOT NULL DEFAULT '1',
		`notes` varchar(255) DEFAULT NULL,
		PRIMARY KEY (`formID`)
		) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productionOrderTemplate` (
		`productionOrderTemplateID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`product` int(11) unsigned NOT NULL,
		`notes` varchar(255) DEFAULT NULL,
		`form` int(11) unsigned DEFAULT NULL,
		`taps` int(11) DEFAULT NULL,
		`lowerSpec` float DEFAULT NULL,
		`upperSpec` float DEFAULT NULL,
		`furnacePattern` int(11) unsigned DEFAULT NULL,
		`user` int(11) unsigned NOT NULL,
		`lastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		`active` int(1) NOT NULL DEFAULT '1',
		PRIMARY KEY (`productionOrderTemplateID`),
		KEY `productionOrderTemplate_product_fk` (`product`),
		KEY `productionOrderTemplate_furancePattern_fk` (`furnacePattern`),
		KEY `productionOrderTemplate_form_fk` (`form`),
		CONSTRAINT `productionOrderTemplate_form_fk` FOREIGN KEY (`form`) REFERENCES `form` (`formID`),
		CONSTRAINT `productionOrderTemplate_furancePattern_fk` FOREIGN KEY (`furnacePattern`) REFERENCES `furnacePattern` (`furnacePatternID`)
		) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		INSERT IGNORE INTO productionOrderTemplate
		SELECT
			productionOrderID as 'productionOrderTemplateID',
			precastProduct as 'product',
			notes,
			null as 'form',
			taps,
			lowerSpec,
			upperSpec,
			furnacePattern,
			user,
			lastEdit,
			active
		FROM
			productionOrder
	";

	$values = array();

	$result['transaction'] = dbquery( $query, $values );
	
	
	
	
	
	
	
	$query = "
		RENAME TABLE productionOrderMaterialLink TO productionOrderTemplateMaterialLink;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE productionOrderTemplateMaterialLink 
			DROP FOREIGN KEY `productionOrderMaterialLink_productionOrder_fk`,
			DROP FOREIGN KEY `productionOrderMaterialLink_material_fk`,
			DROP FOREIGN KEY `productionOrderMaterialLink_vibrationType_fk`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE productionOrderTemplateMaterialLink CHANGE productionOrder productionOrderTemplate INT(11) unsigned NOT NULL
	";
	
	$result = dbquery( $query, array() );
	
	
	
	
	
	
	
	$query = "
		RENAME TABLE productionOrderProductionOrderOptionLink TO productionOrderTemplateProductionOrderOptionLink;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE productionOrderTemplateProductionOrderOptionLink 
			DROP FOREIGN KEY `popool_productionOrder_fk`,
			DROP FOREIGN KEY `popool_productionOrderOption_fk`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE productionOrderTemplateProductionOrderOptionLink CHANGE productionOrder productionOrderTemplate INT(11) unsigned NOT NULL
	";
	
	$result = dbquery( $query, array() );
	
	
	
	
	
	
	
	
	
	$query = "
		DROP TABLE IF EXISTS `productionOrder`;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productionOrder` (
		`productionOrderID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`customer` int(11) unsigned NOT NULL,
		`consumer` int(11) unsigned NOT NULL,
		`product` int(11) unsigned NOT NULL,
		`quantityOrdered` int(11) DEFAULT NULL,
		`quantityFilled` int(11) DEFAULT '0',
		`notes` varchar(255) DEFAULT NULL,
		`form` int(11) unsigned DEFAULT NULL,
		`taps` int(11) DEFAULT NULL,
		`lowerSpec` float DEFAULT NULL,
		`upperSpec` float DEFAULT NULL,
		`furnacePattern` int(11) unsigned DEFAULT NULL,
		`user` int(11) unsigned NOT NULL,
		`lastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		`active` int(1) NOT NULL DEFAULT '1',
		PRIMARY KEY (`productionOrderID`),
		KEY `productionOrder_furnacePattern_fk` (`furnacePattern`),
		KEY `productionOrder_material_fk` (`product`),
		KEY `productionOrder_form_fk` (`form`),
		CONSTRAINT `productionOrder_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`productID`),
		CONSTRAINT `productionOrder_form_fk` FOREIGN KEY (`form`) REFERENCES `form` (`formID`),
		CONSTRAINT `productionOrder_furnacePattern_fk` FOREIGN KEY (`furnacePattern`) REFERENCES `furnacePattern` (`furnacePatternID`)
		) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productionOrderMaterialLink` (
		`productionOrder` int(11) unsigned NOT NULL,
		`material` int(11) unsigned NOT NULL,
		`quantity` float DEFAULT NULL,
		`water` float DEFAULT NULL,
		`mixTime` int(11) DEFAULT NULL,
		`vibrationType` int(11) unsigned NOT NULL DEFAULT '0',
		`vibrationTime` int(11) DEFAULT NULL,
		UNIQUE KEY `material` (`material`,`productionOrder`),
		KEY `material_2` (`material`,`productionOrder`),
		KEY `productionOrderMaterialLink_vibrationType_fk` (`vibrationType`),
		KEY `productionOrderMaterialLink_productionOrder_fk` (`productionOrder`),
		CONSTRAINT `poml_material_fk` FOREIGN KEY (`material`) REFERENCES `material` (`materialID`),
		CONSTRAINT `poml_productionOrder_fk` FOREIGN KEY (`productionOrder`) REFERENCES `productionOrder` (`productionOrderID`),
		CONSTRAINT `poml_vibrationType_fk` FOREIGN KEY (`vibrationType`) REFERENCES `vibrationType` (`vibrationTypeID`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productionOrderProductionOrderOptionLink` (
		`productionOrder` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`productionOrderOption` int(11) unsigned NOT NULL,
		UNIQUE KEY `productionOrder` (`productionOrder`,`productionOrderOption`),
		KEY `productionOrderOption` (`productionOrderOption`,`productionOrder`),
		CONSTRAINT `popool_productionOrderOption_fk` FOREIGN KEY (`productionOrderOption`) REFERENCES `productionOrderOption` (`productionOrderOptionID`),
		CONSTRAINT `popool_productionOrder_fk` FOREIGN KEY (`productionOrder`) REFERENCES `productionOrder` (`productionOrderID`)
		) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `productionOrderSchedule` (
		`productionOrder` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`pourDate` date NOT NULL DEFAULT '0000-00-00',
		`quantity` int(11) NOT NULL DEFAULT '0',
		PRIMARY KEY (`pourDate`,`productionOrder`),
		UNIQUE KEY `pourDate` (`pourDate`,`productionOrder`),
		KEY `productionOrder` (`productionOrder`,`pourDate`),
		CONSTRAINT `productionOrderSchedule_productionOrder_fk` FOREIGN KEY (`productionOrder`) REFERENCES `productionOrder` (`productionOrderID`)
		) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `qcTest` (
		`qcTestID` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`startTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
		`material` int(11) unsigned NOT NULL,
		`water` double NOT NULL,
		`mix` int(11) NOT NULL,
		`vib` int(11) NOT NULL,
		`lotcode` varchar(255) DEFAULT NULL,
		PRIMARY KEY (`qcTestID`),
		KEY `material` (`material`),
		CONSTRAINT `qcTest_material_fk` FOREIGN KEY (`material`) REFERENCES `material` (`materialID`)
		) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		CREATE TABLE `qcTestData` (
		`qcTest` int(11) unsigned NOT NULL,
		`index` int(11) NOT NULL AUTO_INCREMENT,
		`temperature` double NOT NULL,
		UNIQUE KEY `index` (`index`,`qcTest`),
		KEY `index_2` (`index`,`qcTest`),
		KEY `qcTest` (`qcTest`),
		CONSTRAINT `qcTestData_qcTest_fk` FOREIGN KEY (`qcTest`) REFERENCES `qcTest` (`qcTestID`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	";
	
	$result = dbquery( $query, array() );
	
	
	$query = "
		ALTER TABLE productionOrderTemplateMaterialLink 
			ADD CONSTRAINT `potml_pot_fk` FOREIGN KEY (`productionOrderTemplate`) REFERENCES `productionOrderTemplate` (`productionOrderTemplateID`),
			ADD CONSTRAINT `potml_material_fk` FOREIGN KEY (`material`) REFERENCES `material` (`materialID`),
			ADD CONSTRAINT `potml_vibrationType_fk` FOREIGN KEY (`vibrationType`) REFERENCES `vibrationType` (`vibrationTypeID`)
	";
	
	$result = dbquery( $query, array() );
	
	$query = "
		ALTER TABLE productionOrderTemplateProductionOrderOptionLink 
			ADD CONSTRAINT `potpool_pot_fk` FOREIGN KEY (`productionOrderTemplate`) REFERENCES `productionOrderTemplate` (`productionOrderTemplateID`),
			ADD CONSTRAINT `potpool_poo_fk` FOREIGN KEY (`productionOrderOption`) REFERENCES `productionOrderOption` (`productionOrderOptionID`)
	";
	
	$result = dbquery( $query, array() );
		

	
	$query = "
		DELETE FROM materialTransaction WHERE materialTransactionID IN (
		    SELECT * FROM (
				SELECT
					t.materialTransactionID
				FROM
					material m
				LEFT JOIN
					materialInventory mi
					ON m.materialID = mi.material
				LEFT JOIN
					companyLocationLink cll
					ON cll.companyLocationLinkID = mi.companyLocationLink
				LEFT JOIN
					company c
					ON c.companyID = cll.company
				LEFT JOIN
					location l
					ON l.locationID = cll.location
				LEFT JOIN
					materialTransaction t
					ON t.materialInventory = mi.materialInventoryID
				WHERE
					(
						m.materialType = 16
					OR
						m.materialType = 26
					OR
						m.material LIKE ?
					)
				AND
					t.materialTransactionID is not null
		    ) AS p
		)
	";

	$values = array(
		'DF%'
	);

	$result['delete'] = dbquery( $query, $values );


	$query = "
	DELETE FROM materialInventory WHERE materialInventoryID IN (
		    SELECT * FROM (
				SELECT
					mi.materialInventoryID
				FROM
					material m
				LEFT JOIN
					materialInventory mi
					ON m.materialID = mi.material
				LEFT JOIN
					companyLocationLink cll
					ON cll.companyLocationLinkID = mi.companyLocationLink
				LEFT JOIN
					company c
					ON c.companyID = cll.company
				LEFT JOIN
					location l
					ON l.locationID = cll.location
				WHERE
					(
						m.materialType = 16
					OR
						m.materialType = 26
					OR
						m.material LIKE ?
					)
		    ) AS p
		)
	";

	$values = array(
		'DF%'
	);

	$result['delete'] = dbquery( $query, $values );
	
	
	$query = "
		DELETE FROM materialManufacturerLink WHERE material IN (
		    SELECT * FROM (
				(
					SELECT
						p.productID
					FROM
						product p
				)
				UNION
				(
					SELECT
						materialID
					FROM
						material
					WHERE
						material LIKE ?
				)
		    ) AS p
		)
	";
	
	$values = array(
		'DF%'
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	
	
	$query = "
		DELETE FROM material WHERE materialID IN (
		    SELECT * FROM (
				(
					SELECT
						p.productID
					FROM
						product p
				)
				UNION
				(
					SELECT
						materialID
					FROM
						material
					WHERE
						material LIKE ?
				)
		    ) AS p
		)
	";
	
	$values = array(
		'DF%'
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	
	
	
	
	$query = "SET FOREIGN_KEY_CHECKS=1;";
	$result = dbquery( $query, array() );
	
?>