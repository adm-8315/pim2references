# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.38)
# Database: chaseNedrow_dev
# Generation Time: 2015-10-01 19:52:30 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table form
# ------------------------------------------------------------

DROP TABLE IF EXISTS `form`;

CREATE TABLE `form` (
  `formID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `formTag` varchar(4) DEFAULT '',
  `formLocation` varchar(255) DEFAULT '',
  `formQuantity` int(11) NOT NULL DEFAULT '1',
  `formPieces` int(11) NOT NULL DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`formID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `form` WRITE;
/*!40000 ALTER TABLE `form` DISABLE KEYS */;

INSERT INTO `form` (`formID`, `formTag`, `formLocation`, `formQuantity`, `formPieces`, `notes`)
VALUES
	(1,'A1','',1,1,NULL),
	(2,'B1','',1,1,NULL),
	(3,'B2','',1,1,NULL),
	(4,'C1','',1,1,NULL),
	(5,'C2','',1,1,NULL),
	(6,'C3','',1,1,NULL),
	(7,'C4','',1,1,NULL),
	(8,'D1','',1,1,NULL),
	(9,'D2','',1,1,NULL),
	(10,'E1','',1,1,NULL),
	(11,'F1','',1,1,NULL),
	(12,'F2','',1,1,NULL),
	(13,'F3','',1,1,NULL),
	(14,'F4','',1,1,NULL),
	(15,'F5','',1,1,NULL),
	(16,'F6','',1,1,NULL),
	(17,'G1','',20,1,NULL),
	(18,'G2','',1,1,NULL),
	(19,'H1','',1,1,NULL),
	(20,'H2','',2,1,NULL),
	(21,'H3','',1,1,NULL),
	(22,'H4','',1,1,NULL),
	(23,'H5','',1,1,NULL),
	(24,'H6','',1,1,NULL),
	(25,'H7','',1,1,NULL),
	(26,'H8','',1,1,NULL),
	(27,'H9','',1,1,NULL),
	(28,'H10','',1,1,NULL),
	(29,'H11','',2,1,NULL),
	(30,'I1','',1,1,NULL),
	(31,'J1','',2,1,NULL),
	(32,'J2','',2,1,NULL),
	(33,'K1','',3,1,NULL),
	(34,'L1','',1,1,NULL),
	(35,'M1','',1,10,NULL),
	(36,'M2','',7,1,NULL),
	(37,'M3','',1,1,NULL),
	(38,'M4','',1,10,NULL),
	(39,'M5','',8,1,NULL),
	(40,'M6','',9,1,NULL),
	(41,'M7','',1,1,NULL),
	(42,'M8','',1,1,NULL),
	(43,'M9','',1,1,NULL),
	(44,'M10','',1,1,NULL),
	(45,'M11','',1,1,NULL),
	(46,'N1','',1,1,NULL),
	(47,'N2','',1,1,NULL),
	(48,'N3','',1,1,NULL),
	(49,'N4','',1,1,NULL),
	(50,'N5','',1,1,NULL),
	(51,'N6','',1,1,NULL),
	(52,'N7','',5,1,NULL),
	(53,'N8','',2,1,NULL),
	(54,'N9','',2,1,NULL),
	(55,'O1','',1,1,NULL),
	(56,'P1','',2,1,NULL),
	(57,'P2','',1,1,NULL),
	(58,'Q1','',10,22,NULL),
	(59,'Q2','',1,18,NULL),
	(60,'Q3','',10,6,NULL),
	(61,'Q4','',11,1,NULL),
	(62,'Q5','',8,1,NULL),
	(63,'Q6','',2,11,NULL),
	(64,'R1','',2,1,NULL),
	(65,'R2','',1,1,NULL),
	(66,'R3','',1,1,NULL);

/*!40000 ALTER TABLE `form` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table formProductLink
# ------------------------------------------------------------

DROP TABLE IF EXISTS `formProductLink`;

CREATE TABLE `formProductLink` (
  `form` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product` int(11) unsigned NOT NULL,
  UNIQUE KEY `product` (`product`,`form`),
  KEY `form` (`form`,`product`),
  CONSTRAINT `formProductLink_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`productID`),
  CONSTRAINT `formProductLink_form_fk` FOREIGN KEY (`form`) REFERENCES `form` (`formID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `formProductLink` WRITE;
/*!40000 ALTER TABLE `formProductLink` DISABLE KEYS */;

INSERT INTO `formProductLink` (`form`, `product`)
VALUES
	(35,1),
	(38,2),
	(37,5),
	(40,7),
	(58,9),
	(58,11),
	(63,12),
	(41,37),
	(19,38),
	(29,41),
	(43,47),
	(54,69),
	(26,77),
	(26,78),
	(26,79),
	(26,129),
	(27,131),
	(28,132),
	(26,133),
	(26,138),
	(25,144),
	(25,148),
	(58,156),
	(12,162),
	(60,543),
	(23,689),
	(61,957);

/*!40000 ALTER TABLE `formProductLink` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
