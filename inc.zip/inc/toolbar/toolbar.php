<?php

/**
 * Includes
 */

require_once("inc/toolbar/toolbar_vars.php");


/**
 * Variables
 */

$result = array();
$report = "";
$date_begin = "";
$date_end = "";
$use_default_location = true;
$use_default_owner = true;


/**
 * MySQL
 */


// Owner

if ($_GET['nav'] == 'report' && $toolbar_owner) {

	$query = "
			SELECT
				c.companyID as 'ownerID',
				c.company as 'owner',
				u.defaultOwner
			FROM
				company c
			LEFT JOIN
				user u
				ON u.defaultOwner = c.companyID
				AND	u.userID = ?
			LEFT JOIN
				companyCompanyPropertyLink ccpl
				ON ccpl.company = c.companyID
			WHERE
				ccpl.companyProperty = 1
			AND
				c.active = 1
			ORDER BY
				c.company ASC
		";

	$values = array(
		$_SESSION['user_id']
	);

	$result['owner'] = dbquery($query, $values);
}


// Location

if ($_GET['nav'] == 'report' && $toolbar_location) {

	if (isset($permissions[3][$permissionBlock]) > 0) {

		$values = array();

		$query = "
				SELECT
					*
				FROM
					location l
				WHERE
			";

		foreach ($permissions[3][$permissionBlock] as $location => $enabled) {
			$query .= " l.locationID = ? OR ";
			$values[] = $location;
		}

		$query = substr($query, 0, -3);

		$query .= " ORDER BY l.location ASC";

		$result['location'] = dbquery($query, $values);
	} else if (isset($permissions[1][1])) {

		$query = "
				SELECT
					l.locationID,
					l.location
				FROM
					location l
				WHERE
					stockable = 1
				ORDER BY
					l.location ASC
			";

		$result['location'] = dbquery($query, array());
	} else {
		$result['location'] = array();
	}
}


// Shortage

switch ($subdomain) {

	case 'inventory':

		$query = "
				(
					SELECT
						*
					FROM
						materialInventory i
					WHERE
						i.stock <= i.stockLevelWarning
					AND
						i.stockLevelWarning != 0
				)
				UNION
				(
					SELECT
						*
					FROM
						productInventory i
					WHERE
						i.stock <= i.stockLevelWarning
					AND
						i.stockLevelWarning != 0
				);
			";

		$values = array();

		break;

	case 'equipment':

		$query = "
				(
					SELECT
						i.itemID as 'id'
					FROM
						job j
					LEFT JOIN
						itemList il
						ON il.job = j.jobID
					LEFT JOIN
						itemInventory ii
						ON il.itemInventory = ii.itemInventoryID
					LEFT JOIN
						item i
						ON ii.item = i.itemID
					WHERE
						j.active = 1
					AND
						il.value > ii.stock
				)
				UNION
				(
					SELECT
						i.itemID as 'id'
					FROM
						job j
					LEFT JOIN
						groupingList gl
						ON gl.job = j.jobID
					LEFT JOIN
						groupingItemLink gil
						ON gil.grouping = gl.grouping
					LEFT JOIN
						itemInventory ii
						ON gil.item = ii.item
						AND ii.location = 1
					LEFT JOIN
						item i
						ON ii.item = i.itemID
					WHERE
						j.active = 1
					AND
						gl.value * gil.value > ii.stock
				)
				UNION
				(
					SELECT
						pm.preventativeMaintenanceID as 'id'
					FROM
						preventativeMaintenance pm
					LEFT JOIN
						(
							SELECT
								*
							FROM
								preventativeMaintenanceLog pml
							GROUP BY
								pml.preventativeMaintenanceType	
							ORDER BY
								pml.date DESC
						) as temp
						ON temp.equipment = pm.equipment
						AND temp.preventativeMaintenanceType = pm.preventativeMaintenanceType
					LEFT JOIN
						preventativeMaintenanceType pmt
						ON pm.preventativeMaintenanceType = pmt.preventativeMaintenanceTypeID
					WHERE
						IF(
							pm.preventativeMaintenanceType is not NULL,
							temp.value > pm.valueInt,
							pm.valueDate < CURDATE()
						)
					AND
						pm.completeDate is null
				)
			";

		$values = array();

		break;
}

$result['shortage'] = dbquery($query, $values);


/**
 * Validation
 */

if (isset($_GET['report'])) {
	$report = $_GET['report'];
}

if (isset($_GET['date_begin'])) {
	$date_begin = $_GET['date_begin'];
}

if (isset($_GET['date_end'])) {
	$date_end = $_GET['date_end'];
}

if (isset($_GET['location']) && $toolbar_location) {

	foreach ($result['location'] as $row) {

		if ($row['locationID'] == $_GET['location']) {
			$use_default_location = false;
		}
	}
}

if (isset($_GET['owner']) && $toolbar_owner) {

	foreach ($result['owner'] as $row) {

		if ($row['ownerID'] == $_GET['owner']) {
			$use_default_owner = false;
		}
	}
}


/**
 * Display
 */

?>

<div id="toolbar">

	<div id="toolbar_application" class="toolbar_float"></div>


	<?php

	if ($toolbar_date_begin) {

		echo "
			<div id='toolbar_datepicker_begin' class='toolbar_float toolbar_container' >
				<input type='hidden' id='datepicker_begin' value='" . $date_begin . "' />
				<div class='toolbar_button'>
					<span>Date Begin</span>
				</div>
			</div>
		";
	}


	if ($toolbar_date_end) {

		echo "
			<div id='toolbar_datepicker_end' class='toolbar_float toolbar_container' >
				<input type='hidden' id='datepicker_end' value='" . $date_end . "'/>
				<div class='toolbar_button'>
					<span>Date End</span>
				</div>
			</div>
		";
	}


	if ($toolbar_owner) {

		echo "
			<div id='toolbar_owner' class='toolbar_float toolbar_container' >
				<div class='toolbar_button'>
					<span>Owner</span>
				</div>
				
				<div class='toolbar_button_options'>
		";

		foreach ($result['owner'] as $row) {

			if (isset($_GET['owner']) && !$use_default_owner && $row["ownerID"] == $_GET['owner']) {
				echo "<div class='option selected' data-id='{$row['ownerID']}'>{$row['owner']}</div>";
			} else if ($use_default_owner && isset($row['defaultOwner']) && $row["ownerID"] == $row['defaultOwner']) {
				echo "<div class='option selected' data-id='{$row['ownerID']}'>{$row['owner']}</div>";
			} else {
				echo "<div class='option' data-id='{$row['ownerID']}'>{$row['owner']}</div>";
			}
		}

		echo "
				</div>
			</div>
		";
	}

	if ($toolbar_location) {

		echo "
			<div id='toolbar_location' class='toolbar_float toolbar_container' >
				<div class='toolbar_button'>
					<span>Location</span>
				</div>
		
				<div class='toolbar_button_options'>
		";

		foreach ($result['location'] as $row) {

			if (isset($_GET['location']) && !$use_default_location && $row['locationID'] == $_GET['location']) {
				echo "<div class='option selected' data-id='{$row['locationID']}'>{$row['location']}</div>";
			} else if ($use_default_location && $row['locationID'] == $_SESSION['default_location']) {
				echo "<div class='option selected' data-id='{$row['locationID']}'>{$row['location']}</div>";
			} else {
				echo "<div class='option' data-id='{$row['locationID']}'>{$row['location']}</div>";
			}
		}

		echo "
				</div>
			</div>
		";
	}

	if ($_GET['nav'] == 'schedule') {

		echo "
			<div id='toolbar_left' class='toolbar_float toolbar_container' >
				<div class='toolbar_button'>
					<img src='img/schedule_arrow_left.png'/>
				</div>
			</div>
		";

		echo "
			<div id='toolbar_right' class='toolbar_float toolbar_container' >
				<div class='toolbar_button'>
					<img src='img/schedule_arrow_right.png'/>
				</div>
			</div>
		";
	}

	?>


	<div id="toolbar_user_profile_container" class="toolbar_float toolbar_container">
		<div id="toolbar_user_profile" class="toolbar_button">
			<span>&nbsp;</span>
		</div>

		<div class="toolbar_button_options">
			<div class='option' data-nav="user_profile">User Profile</div>
			<?php

			if (!empty($permissions[1][1])) {

				echo "<div class='option' data-nav='add_user'>Add User</div>";
				echo "<div class='option' data-nav='permissions'>Permissions</div>";

				if (!isset($_SESSION['ghosting'])) {
					echo "<div class='option' data-nav='ghost'>Ghost</div>";
				}
			}

			if (isset($_SESSION['ghosting'])) {
				echo "<div class='option' data-nav='ghost'>Un-Ghost</div>";
			}



			?>
		</div>
	</div>

	<?php

	if (
		!empty($permissions[1][1]) ||
		!empty($permissions[5][22]) ||
		!empty($permissions[5][23]) ||
		!empty($permissions[5][24]) ||
		!empty($permissions[5][25]) ||
		!empty($permissions[5][44])
	) {

		echo '	
			<div id="toolbar_add_container" class="toolbar_float toolbar_container" >
				<div id="toolbar_add" class="toolbar_button">
					<span>&nbsp;</span>
				</div>

				<div class="toolbar_button_options">
		';

		if (!empty($permissions[1][1])) {
			echo '<div class="option" data-nav="add_company">Company</div>';
		}

		if (
			!empty($permissions[1][1]) ||
			!empty($permissions[5][22])
		) {
			echo '<div class="option" data-nav="add_job">Job</div>';
		}

		if (
			!empty($permissions[1][1]) ||
			!empty($permissions[5][23])
		) {
			echo '<div class="option" data-nav="add_equipment">Equipment</div>';
		}

		if (
			!empty($permissions[1][1]) ||
			!empty($permissions[5][24])
		) {
			echo '<div class="option" data-nav="add_grouping">Grouping</div>';
		}

		if (
			!empty($permissions[1][1]) ||
			!empty($permissions[5][25])
		) {
			echo '<div class="option" data-nav="add_item">Item</div>';
		}

		if (
			!empty($permissions[1][1]) ||
			!empty($permissions[5][44])
		) {
			echo '<div class="option" data-nav="add_productionOrder">Production Order</div>';
		}

		echo '
				</div>
			</div>
		';
	}

	?>

	<?php

	if (
		(!empty($permissions[1][1]) ||
			!empty($permissions[3][21])) &&
		!empty($result['shortage'])
	) {
		echo '
			<div id="toolbar_edit_container" class="toolbar_float toolbar_container">
				<div id="toolbar_edit" class="toolbar_button">
					<span>&nbsp;</span>
				</div>
			</div>';

		echo '
			<div id="toolbar_warning_container" class="toolbar_float toolbar_container">
				<div id="toolbar_warning" class="toolbar_button">
					<span>&nbsp;</span>
				</div>
			</div>';
	}

	?>

</div>