<?php
	
	/**
	 * Variables
	 */
	
	$toolbar_location = false;
	$toolbar_date_begin = false;
	$toolbar_date_end = false;
	$toolbar_owner = false;
	
	/*
	$application_permission_block = 1;
	$application_shortage_block = 	21;
	$application_permission_block = 19;
	$application_shortage_block = 	30;
	*/
	
	if ( isset( $_GET['report'] ) )
	{
		
		switch ( $_GET['report'] )
		{

			case 'raw_material_stock':
				$permissionBlock = 		2;
				$toolbar_date_end =		true;
				$toolbar_location = 	true;
				break;

			case 'finished_product_stock':
				$permissionBlock = 		3;
				$toolbar_date_end = 	true;
				$toolbar_location = 	true;
				break;

			case 'tools_accessories_stock':
				$permissionBlock = 		4;
				$toolbar_date_end = 	true;
				$toolbar_location = 	true;
				break;

			case 'stock_value':
				$permissionBlock = 		5;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'tools_accessories_value':
				$permissionBlock = 		6;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'material_usage':
				$permissionBlock = 		7;
				$toolbar_date_begin = 	true;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'production':
				$permissionBlock = 		8;
				$toolbar_date_begin = 	true;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'finished_product_sales':
				$permissionBlock = 		9;
				$toolbar_date_begin = 	true;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'scrap':
				$permissionBlock = 		10;
				$toolbar_date_begin = 	true;
				$toolbar_date_end = 	true;
				$toolbar_owner = 		true;
				$toolbar_location = 	true;
				break;

			case 'inventory_adjustment':
				$permissionBlock = 		11;
				$toolbar_date_begin = 	true;
				$toolbar_date_end = 	true;
				$toolbar_location = 	true;
				break;

			case 'job':
				$permissionBlock = 		29;
				break;

			case 'equipment':
				$permissionBlock = 		31;
				$toolbar_location = 	true;
				break;

			case 'grouping':
				$permissionBlock = 		32;
				$toolbar_location = 	true;
				break;

			case 'item':
				$permissionBlock = 		33;
				$toolbar_location = 	true;
				break;

			case 'shortage':
				$permissionBlock = 		30;
				$toolbar_location = 	true;
				break;

		}
	
	}

?>