<?php

	/**
	 * Includes
	 */
	
	require_once( "dbfunc.php" );
		
		
	/**
	 * Variables
	 */
	
	$permissions = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset( $_SESSION['user_id'] ) )
	{
	
		$query = "
			SELECT DISTINCT
				pb.permissionGroup,
				pl.permissionBlock,
				IF(
					pl.allLocation = 1,
					l.locationID,
					pl.location
				) as 'location'
			FROM
				permissionLink pl
			LEFT JOIN
				permissionBlock pb
				ON pl.permissionBlock = pb.permissionBlockID
			LEFT JOIN
				location l
				ON l.stockable = 1
			WHERE
				pl.user = ?
			ORDER BY
				pb.permissionGroup,
				pl.permissionBlock,
				pl.location
		";
	
		$values = array(
			$_SESSION['user_id']
		);
	
		$permissions_result = dbquery( $query, $values );

		foreach ( $permissions_result as $block )
		{
			$permissions[ $block['permissionGroup'] ][ $block['permissionBlock'] ][ $block['location'] ] = 1;
		}
		
	}
	
?>