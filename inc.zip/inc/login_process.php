<?php
	
	/**
	 * MySQL
	 */
	
	

	$query = "
		SELECT
			u.userID,
			u.defaultLocation,
			u.defaultOwner
		FROM
			user u
		WHERE
			u.username = ?
		AND
			u.passwordHash = ?
		AND
			u.active = 1
		LIMIT 1
	";

	$values = array(
		$_POST['username'],
		sha1( $_POST['password'] )
	);

	$result['user'] = dbquery($query, $values);


	/**
	 * Process
	 */

	if ( $result['user'] )
	{
	
		$_SESSION['user_id'] = $result['user'][0]['userID'];
		$_SESSION['default_location'] = $result['user'][0]['defaultLocation'];
		$_SESSION['default_owner'] = $result['user'][0]['defaultOwner'];
		
		$getString = "?";
		
		if ( isset( $_GET ) )
		{
			
			if ( ! isset( $_GET['nav'] ) )
			{
				$getString .= "nav=home&";
			}
			
			foreach ( $_GET as $key => $value )
			{
				$getString .= $key . "=" . $value . "&";
			}
			
		}
		
		$getString = substr( $getString, 0, -1 );
		
		header( "Location:{$page['url']}{$getString}" );
		
	} 
	else 
	{
		$message = "Not Authenticated";
	}
