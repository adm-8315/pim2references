( function ($) {
	
	overlay_setup['item_inventory'] = {
		"title": "Item Inventory",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{
				"id": 0,
				"toSend": {
					0: "#overlay_item"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/item_edit_inventory/screens/item_edit_inventory.php",
				"validation": "overlay_edit_item_inventory_validation",
				"toSend": {
					0: "#edit_item_inventory_send"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/item_edit_inventory/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#inventory_edit", function () {
			overlay_open = 'item_inventory';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);