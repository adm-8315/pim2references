<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/normalizeItemInventory.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$json = json_decode( $_POST['edit_item_inventory_send'], true );
	
	
	/**
	 * MySQL
	 */
	
	normalizeItemInventory( $json );
	
	$values = array();
	
	$query = "
		UPDATE
			itemInventory
			SET stock = CASE
	";
	
	foreach ( $json as $row )
	{
		$query .= " WHEN location = ? THEN ? ";
		$values[] = $row['location'];
		$values[] = $row['stock'];
	}
				
	$query .= "			
			END
		WHERE
			item = ?
		AND
			location in (
	";
	
	$values[] = $json[0]['id'];
	
	foreach ( $json as $row )
	{
		$query .= " ?,";
		$values[] = $row['location'];
	}
	
	$query = substr( $query, 0, -1);
	
	$query .= ")";
	
	$values[] = $json[0]['id'];
	
	$result['itemInventoryUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['itemInventoryUpdate'] )
	{
		echo "Inventory for the item was updated.";
	}
	else
	{
		echo "There was a problem updating the item.";
	}
	

?>