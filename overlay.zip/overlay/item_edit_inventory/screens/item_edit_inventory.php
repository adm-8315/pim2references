<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			i.itemID,
			i.item,
			it.itemTypeID,
			it.itemType,
			l.locationID,
			l.location,
			IF (
				ii.stock is null,
				0,
				ii.stock
			) as 'stock'
		FROM
			item i
		JOIN
			location l
		LEFT JOIN
			itemType it
			ON it.itemTypeID = i.itemType
		LEFT JOIN
			itemInventory ii
			ON l.locationID = ii.location
			AND ii.item = ?
		WHERE
			i.itemID = ?
		AND
			l.stockable = 1
		ORDER BY
			l.location ASC
	";

	$values = array(
		$_POST['overlay_item'],
		$_POST['overlay_item']
	);

	$result['item'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id="item_inventory_table">

	<tr>
		<th>Location</th>
		<th>Stock</th>
		<input type="hidden" id="edit_item_inventory_send">
	</tr>

	<?php

	foreach ( $result['item'] as $row )
	{
		echo "<tr class='inventory_tab_row'>";
			echo "<td class='inventory_tab_row_data location'>" . $row['location'] . "</td>";
			echo "<td class='inventory_tab_row_data stock'>";
				echo "<input type='text' class='edit_item_inventory_quantity' data-location='" . $row['locationID'] . "' value='" . $row['stock'] . "' />";
			echo "</td>";
		echo "</tr>";
	}

	?>

</table>

<style>

#item_inventory_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	$(".edit_item_inventory_quantity")
		.mask('00000', {
			reverse: true
		});

	if( typeof overlay_edit_item_inventory_validation != 'function' )
	{
	
		var keyupString = '.edit_item_inventory_quantity';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_item_inventory_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_item_inventory_validation();
		});
		
		$(document).on("keyup", '.edit_item_inventory_quantity', function () {
			window.overlay_edit_item_inventory_json();
		});
	
		window.overlay_edit_item_inventory_validation = function ()
		{
			
			var valid = true;
			
			$(".edit_item_inventory_quantity").each( function () {
				
				if ( $(this).val() == "" || $(this).val() < 0 )
				{
					valid = false;
				}
			});
			
			if (valid)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_edit_item_inventory_validation();
		
		window.overlay_edit_item_inventory_json = function ()
		{
			myData = {
				"dataJSON": []
			};
				
			$(".edit_item_inventory_quantity").each( function () {
				myData.dataJSON.push( 
					{
						"id": <?php echo $_POST['overlay_item']; ?>,
						"type": "item",
						"location": $(this).attr("data-location"), 
						"stock": $(this).val() 
					} 
				);
			});
			
			$("#edit_item_inventory_send").val( JSON.stringify( myData.dataJSON ) );
		}
		
		window.overlay_edit_item_inventory_json();
	
	}

</script>