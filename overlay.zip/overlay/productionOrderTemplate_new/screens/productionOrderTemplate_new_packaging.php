<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order Options
	
	$query = "
		SELECT
			poo.productionOrderOptionID,
			poo.productionOrderOption
		FROM
			productionOrderOption poo
		WHERE
			poo.productionOrderOptionType = 2
	";

	$values = array();

	$result['productionOrderOption'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>


<div id='productionOrderTemplate_new_container'>
	
	<input type='hidden' id='new_productionOrder_product' value='<?php echo $_POST['new_productionOrder_product']; ?>'>
	<input type='hidden' id='productionOrder_material_values' value='<?php echo $_POST['productionOrder_material_values']; ?>'>
	<input type='hidden' id='new_productionOrder_taps' value='<?php echo $_POST['new_productionOrder_taps']; ?>'>
	<input type='hidden' id='new_productionOrder_lowerSpec' value='<?php echo $_POST['new_productionOrder_lowerSpec']; ?>'>
	<input type='hidden' id='new_productionOrder_upperSpec' value='<?php echo $_POST['new_productionOrder_upperSpec']; ?>'>
	<input type='hidden' id='productionOrder_curing_values' value='<?php echo $_POST['productionOrder_curing_values']; ?>'>
	<input type='hidden' id='productionOrder_curing_values' value='<?php echo $_POST['productionOrder_curing_values']; ?>'>
	<input type='hidden' id='new_productionOrder_pattern' value='<?php echo $_POST['new_productionOrder_pattern']; ?>'>
	<input type='hidden' id='new_productionOrder_packaging' value=''>

	<label class='productionOrderTemplate_new_label'>Packaging</label>

	<table id='edit_item_table'>
	
		<?php
		
		foreach( $result['productionOrderOption'] as $option )
		{
		
			echo "
				<tr>
					<td class='left'><label>{$option['productionOrderOption']}</label></td>
					<td class='right'>";
					
					echo "<input type='radio' name='packaging' class='packaging_option' data-id='{$option["productionOrderOptionID"]}' />";
		
			echo "		</td>
				</tr>	
			";
		
		}
		
		?>
	
	</table>
	
</div>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_new_productionOrder_packaging_validation != 'function' )
	{
	
		var changeString = '.packaging_option';
	
		$(document).on("change", changeString, function () {
			
			window.overlay_new_productionOrder_packaging_validation();
			
			$("#new_productionOrder_packaging").val( $("input[name='packaging']:checked").data('id') );
			
		});
	
		window.overlay_new_productionOrder_packaging_validation = function ()
		{
			
			if (
				$("input[name='packaging']:checked").val()
			)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_new_productionOrder_packaging_validation();
	
	}

</script>