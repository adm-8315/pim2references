<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/dev_tools/print_dev.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$materials = json_decode( $_POST['productionOrder_material_values'], true );
	$curing = explode( ",", $_POST['productionOrder_curing_values'] );
	
	
	/**
	 * MySQL
	 */
	
	// Template
	
	$query = "
		INSERT INTO 
			productionOrderTemplate
			( product, notes, taps, lowerSpec, upperSpec, furnacePattern, user )
		VALUES
			( ?, ?, ?, ?, ?, ?, ? );
	";
	
	$values = array(
		$_POST['new_productionOrder_product'],
		$materials['notes'],
		$_POST['new_productionOrder_taps'],
		$_POST['new_productionOrder_lowerSpec'],
		$_POST['new_productionOrder_upperSpec'],
		$_POST['new_productionOrder_pattern'],
		$_SESSION['user_id']
	);
	
	$result['productionOrderTemplate'] = dbquery( $query, $values );
	
	
	// Options
	
	$values = array();
	
	$query = "
		INSERT INTO 
			productionOrderTemplateProductionOrderOptionLink 
			( productionOrderTemplate, productionOrderOption )
		VALUES
	";
	
	$query .= "( ?, ? ),";
	$values[] = $result['productionOrderTemplate'];
	$values[] = $_POST['new_productionOrder_packaging'];
	
	foreach ( $curing as $value )
	{
		$query .= "( ?, ? ),";
		$values[] = $result['productionOrderTemplate'];
		$values[] = $value;
	}
	
	$query = substr( $query, 0, -1 );
	
	$result['productionOrderTemplateOptions'] = dbquery( $query, $values );
	
	
	// Materials
	
	$values = array();
	
	$query = "
		INSERT INTO 
			productionOrderTemplateMaterialLink 
			( productionOrderTemplate, material, quantity, water, mixTime, vibrationType, vibrationTime )
		VALUES
	";
	
	foreach ( $materials as $key => $row )
	{
		
		if ( 
			$key == "notes" || 
			$row['material'] == '-1'
		) {
			continue;
		}
		
		$query .= "( ?, ?, ?, ?, ?, ?, ? ),";
		$values[] = $result['productionOrderTemplate'];
		$values[] = $row['material'];
		$values[] = $row['quantity'];
		$values[] = $row['water'];
		$values[] = $row['mix'];
		$values[] = $row['vibType'];
		$values[] = $row['vibTime'];
		
	}
	
	$query = substr( $query, 0, -1 );
	
	$result['productionOrderTemplateMaterials'] = dbquery( $query, $values );
	
	echo "Template Created";
	
?>