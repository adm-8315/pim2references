<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Furnace
	
	$query = "
		SELECT
			*
		FROM
			furnace f
	";
	
	$values = array();
	
	$result['furnace'] = dbquery( $query, $values );
	
	/**
	 * Display
	 */

?>

<div id='productionOrderTemplate_new_container'>
	
	<input type='hidden' id='new_productionOrder_product' value='<?php echo $_POST['new_productionOrder_product']; ?>'>
	<input type='hidden' id='productionOrder_material_values' value='<?php echo $_POST['productionOrder_material_values']; ?>'>
	<input type='hidden' id='new_productionOrder_taps' value='<?php echo $_POST['new_productionOrder_taps']; ?>'>
	<input type='hidden' id='new_productionOrder_lowerSpec' value='<?php echo $_POST['new_productionOrder_lowerSpec']; ?>'>
	<input type='hidden' id='new_productionOrder_upperSpec' value='<?php echo $_POST['new_productionOrder_upperSpec']; ?>'>
	<input type='hidden' id='productionOrder_curing_values' value='<?php echo $_POST['productionOrder_curing_values']; ?>'>

	<label class='productionOrderTemplate_new_label'>Drying</label>

	<table id='edit_item_table'>
	
		<tr>
			<td class='left'><label>Furnace</label></td>
			<td class='right'>
				<select id="new_productionOrder_furnace">
					<option value='-1'>Choose...</option>
					<?php
					foreach ( $result['furnace'] as $furnace )
					{
						echo "<option value='{$furnace['furnaceID']}'>{$furnace['furnace']}</option>";
					}
					?>
				</select>
			</td>
		</tr>
	
		<tr>
			<td class='left'><label>Pattern</label></td>
			<td class='right'>
				<select id='new_productionOrder_pattern'>
					<option value='-1'>Choose...</option>
				</select>
			</td>
		</tr>
	
	</table>
	
</div>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	( function ($) {
	
		$("#new_productionOrder_furnace").on("change", function () {
		
			if ( $("#new_productionOrder_furnace").val() != "-1" )
			{
				request = $.ajax({
					url: "ajax/new_productionOrder_pattern.php",
					type: "post",
					data: "new_productionOrder_furnace=" +
						$("#new_productionOrder_furnace").val()
				}).done( function ( response, textStatus, jqXHR) {
					$("#screen_overlay_content")
						.find("#new_productionOrder_pattern")
						.html( response );
						
						window.overlay_new_productionOrder_drying_validation();
				});
			}
		
		});
	
	})(jQuery);

	if( typeof overlay_new_productionOrder_drying_validation != 'function' )
	{
	
		var changeString = '#new_productionOrder_furnace, #new_productionOrder_pattern';
	
		$(document).on("change", changeString, function () {
			window.overlay_new_productionOrder_drying_validation();
		});
	
		window.overlay_new_productionOrder_drying_validation = function ()
		{
			
			if (
				$("#new_productionOrder_furnace").val() != "-1" &&
				$("#new_productionOrder_pattern").val() != "-1"
			)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_new_productionOrder_drying_validation();
	
	}

</script>