<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Product
	
	$query = "
		SELECT
			p.productID,
			p.product
		FROM
			product p
		WHERE
			p.productID = ?
		ORDER BY
			p.product ASC
	";

	$values = array(
		$_POST['overlay_material']
	);

	$result['product'] = dbquery( $query, $values );
		
	
	// Material Type
	
	$query = "
		SELECT
			*
		FROM
			materialType
		ORDER BY
			materialType
	";
	
	$values = array();
	
	$result['materialType'] = dbquery( $query, $values );
	
	
	// Manufacturer
	
	$query = "
		SELECT
			c.companyID,
			c.company
		FROM
			companyCompanyPropertyLink ccpl
		LEFT JOIN
			company c
			ON ccpl.company = c.companyID
		WHERE
			ccpl.companyProperty = 2
		AND
			c.active = 1
		ORDER BY
			c.company
	";
	
	$values = array();
	
	$result['manufacturer'] = dbquery( $query, $values );
	
	
	// Material
	
	$query = "
		SELECT
			m.materialID,
			m.materialType,
			m.material,
			m.measure,
			me.measurePlural,
			mml.company,
			a.std as 'addStd',
			a.lowerSpec as 'addLow',
			a.upperSpec as 'addHigh'
		FROM
			material m
		LEFT JOIN
			materialManufacturerLink mml
			ON m.materialID = mml.material
		LEFT JOIN
			measure me
			ON m.measure = me.measureID
		LEFT JOIN
			additive a
			ON m.materialID = a.material
		ORDER BY
			m.material
	";
	
	$values = array();
	
	$result['material'] = dbquery( $query, $values );
	
	
	// Vibration Type
	
	$query = "
		SELECT
			*
		FROM
			vibrationType
		WHERE
			vibrationTypeID != 0
		ORDER BY
			vibrationType
	";
	
	$values = array();
	
	$result['vibType'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<div id='productionOrderTemplate_new_container'>
	
	<input type='hidden' id='new_productionOrder_product' value='<?php echo $result['product'][0]['productID']; ?>'>
	<input type='hidden' id='productionOrder_material_values' value=''>
	

	<label class='productionOrderTemplate_new_label'>Materials</label>

	<table id='edit_material_table'>
	
		<tr>
			<th>Qty.</th>
			<th></th>
			<th>Mat. Type</th>
			<th>Man.</th>
			<th>Material</th>
			<th>Water %</th>
			<th>Mix Time</th>
			<th>Vib. Type</th>
			<th>Vib. Time</th>
		</tr>
	
		<?php
		
			for( $i = 1; $i <= 6; $i++ )
			{
	
		?>
	
				<tr>
					<td><input type='text' class='quantity' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_quantity" <?php
				
						if ( isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['quantity'] ) )
						{
							echo "value='{$result['productionOrderTemplateMaterialLink'][$i - 1]['quantity']}'";
						}
				
					?>/></td>
					<td><span class='measure' data-material='<?php echo $i; ?>' ></td>
					<td>
						<select class='materialType' data-material='<?php echo $i; ?>'>
							<option value="-1">Choose...</option>
							<?php
					
							foreach( $result['materialType'] as $materialType )
							{
							
								if ( 
									isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['material'] ) &&
									$materialType['materialTypeID']	== $result['productionOrderTemplateMaterialLink'][$i - 1]['materialType']
								) {
									echo "<option selected='selected' value='{$materialType['materialTypeID']}'>{$materialType['materialType']}</option>";
								}
								else
								{
									echo "<option value='{$materialType['materialTypeID']}'>{$materialType['materialType']}</option>";
								}
								
							}
				
							?>
						</select>
					</td>
					<td>
						<select class='manufacturer' data-material='<?php echo $i; ?>'>
							<option value="-1">Choose...</option>
							<?php
				
							foreach( $result['manufacturer'] as $manufacturer )
							{
							
								if ( 
									isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['material'] ) &&
									$manufacturer['companyID']	== $result['productionOrderTemplateMaterialLink'][$i - 1]['manufacturer']
								) {
									echo "<option selected='selected' value='{$manufacturer['companyID']}'>{$manufacturer['company']}</option>";
								}
								else
								{
									echo "<option value='{$manufacturer['companyID']}'>{$manufacturer['company']}</option>";
								}
							
							}
			
							?>
						</select>
					</td>
					<td>
						<select class='edit_material' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_material">
							<option value="-1">Choose...</option>
							<?php
				
							foreach( $result['material'] as $material )
							{
								if ( 
									isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['material'] ) &&
									$material['materialID']	== $result['productionOrderTemplateMaterialLink'][$i - 1]['material']
								) {
									echo "<option ";
									echo "value='{$material['materialID']}' ";
									echo "data-type='{$material['materialType']}' ";
									echo "data-man='{$material['company']}' ";
									echo "data-measure='{$material['measurePlural']}' ";
									echo "data-addStd='{$material['addStd']}' ";
									echo "selected='selected'>";
									echo  $material['material'];
									echo "</option>";
								}
								else
								{
									echo "<option ";
									echo "value='{$material['materialID']}' ";
									echo "data-type='{$material['materialType']}' ";
									echo "data-man='{$material['company']}' ";
									echo "data-measure='{$material['measurePlural']}' ";
									echo "data-addStd='{$material['addStd']}' ";
									echo ">";
									echo $material['material'];
									echo "</option>";
								}
							
							}
			
							?>
						</select>
					</td>
					<td><div id='material_<?php echo $i; ?>_mfgWater' data-title=""><input type='text' class='water' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_water" <?php
				
						if ( isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['water'] ) )
						{
							echo "value='{$result['productionOrderTemplateMaterialLink'][$i - 1]['water']}'";
						}
				
					?>/></div></td>
					<td><div id='material_<?php echo $i; ?>_mfgMix' data-title=""><input type='text' class='mix' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_mix" <?php
				
						if ( isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['mixTime'] ) )
						{
							echo "value='{$result['productionOrderTemplateMaterialLink'][$i - 1]['mixTime']}'";
						}
				
					?>/></div></td>
					<td>
						<select class='vibType' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_vibType">
							<option value="-1">Choose...</option>
							<?php
				
							foreach( $result['vibType'] as $vibType )
							{
							
								if ( 
									isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['vibrationType'] ) &&
									$vibType['vibrationTypeID']	== $result['productionOrderTemplateMaterialLink'][$i - 1]['vibrationType']
								) {
									echo "<option value='{$vibType['vibrationTypeID']}' selected='selected'>{$vibType['vibrationType']}</option>";
								}
								else
								{
									echo "<option value='{$vibType['vibrationTypeID']}'>{$vibType['vibrationType']}</option>";
								}
							
							}
			
							?>
						</select>
					</td>
					<td><input type='text' class='vibTime' data-material='<?php echo $i; ?>' id="material_<?php echo $i; ?>_vibTime" <?php
				
						if ( isset( $result['productionOrderTemplateMaterialLink'][$i - 1]['vibrationTime'] ) )
						{
							echo "value='{$result['productionOrderTemplateMaterialLink'][$i - 1]['vibrationTime']}'";
						}
				
					?>/></td>
				</tr>
	
		<?php
			}
		
		?>
	
		<tr>
			<th>Notes</th>
			<td colspan='8'>
				<textarea class='note' id="material_notes" ></textarea>
			</td>
		</tr>
	
	</table>
	
</div>

<style>

#edit_material_table {
	margin: 0 auto;
}

#edit_material_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

.note {
	resize: none;
	width: 775px;
	height: 40px;
}

.measure {
	display: inline-block;
	width: 56px;
}

.quantity {
	width: 50px;
}

.materialType,
.manufacturer {
	width: 125px;
}

.edit_material {
	width: 200px;
}

.vibType {
	width: 75px;
}

.water,
.mix,
.vibTime {
	width: 50px;
}

.material_water_hook,
.material_mix_hook {
	position: relative;
}

.material_water_hook:hover:after {
	position: absolute;
	display: inline-block;
	top: 30px;
	left: -83px;
	background: #333;
	background: rgba(0,0,0,1);
	border-radius: 5px;
	color: #fff;
	white-space: nowrap;
	content: attr(data-title);
	padding: 5px 15px;
	z-index: 9999;
	width: 230px;
}

.material_mix_hook:hover:after {
	position: absolute;
	display: inline-block;
	top: 30px;
	left: -83px;
	background: #333;
	background: rgba(0,0,0,1);
	border-radius: 5px;
	color: #fff;
	white-space: nowrap;
	content: attr(data-title);
	padding: 5px 15px;
	z-index: 9999;
	width: 230px;
}

#productionOrderTemplate_new_container {
	text-align: center;
}

#productionOrderTemplate_new_container .productionOrderTemplate_new_label {
	margin-bottom: 10px;
	
	font-size: 20px;
	font-weight: 800;
}

</style>

<script src='js/productionOrder_material.js'></script>
<script>
	
	$("#screen_overlay_content")
		.find(".quantity")
		.mask('999999.99');

	$("#screen_overlay_content")
		.find(".water")
		.mask('999.99');

	$("#screen_overlay_content")
		.find(".mix, .vibTime")
		.mask('99');
		
	var i = 50;
	$(".material_water_hook").each( function () {
		$(this).css("z-index", i );
		i--;
	});
	
	var i = 50;
	$(".material_mix_hook").each( function () {
		$(this).css("z-index", i );
		i--;
	});
	
	if( typeof overlay_new_productionOrder_material_validation != 'function' )
	{
		
		var materialListing = $(".edit_material[data-material='1'] option").clone();
		var keyupString = ".quantity, .water, .mix, .vibTime, #material_notes";
		var changeString = '.edit_material, .vibType';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_new_productionOrder_material_validation();
			window.overlay_productionOrder_material_json();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_new_productionOrder_material_validation();
			window.overlay_productionOrder_material_json();
		});
		
		$(document).on("change", '.materialType, .manufacturer', function () {
			overlay_productionOrder_material_filter( $(this) );
		});

		$(document).on( "change", '.edit_material', function () {
			window.overlay_productionOrder_material_stds( $(this) );
		});
		
		
	
		window.overlay_new_productionOrder_material_validation = function ()
		{
			
			var valid = true;
			
			$(".edit_material").each( function () {
				
				if ( 
					$(".edit_material[data-material='" + $(this).data("material") + "']").val() != '-1' &&
					$(".quantity[data-material='" + $(this).data("material") + "']").val() == "" 
				) {
					valid = false;
				}
				
			});
			
			if ( valid )
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_new_productionOrder_material_validation();
		window.overlay_productionOrder_material_json();
		
		$(".edit_material").each( function () {
			window.overlay_productionOrder_material_stds( $(this) );
		});
	
	}

</script>