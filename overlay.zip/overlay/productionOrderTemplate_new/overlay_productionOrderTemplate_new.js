( function ($) {
	
	overlay_setup['orderTemplate_new'] = {
		"title": "New Order Template",
		"width": "850",
		"height": "550",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/productionOrderTemplate_new/screens/productionOrderTemplate_new_material.php",
				"validation": "overlay_new_productionOrder_material_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values"
				}
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrderTemplate_new/screens/productionOrderTemplate_new_qc.php",
				"validation": "overlay_new_productionOrder_qc_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec"
				}
			}, { 
				"id" : 3, 
				"url": "overlay/productionOrderTemplate_new/screens/productionOrderTemplate_new_curing.php",
				"validation": "overlay_new_productionOrder_curing_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec",
					5: "#productionOrder_curing_values"
				}
			}, { 
				"id" : 4, 
				"url": "overlay/productionOrderTemplate_new/screens/productionOrderTemplate_new_drying.php",
				"validation": "overlay_new_productionOrder_drying_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec",
					5: "#productionOrder_curing_values",
					6: "#new_productionOrder_pattern"
				}
			}, { 
				"id" : 5, 
				"url": "overlay/productionOrderTemplate_new/screens/productionOrderTemplate_new_packaging.php",
				"validation": "overlay_new_productionOrder_packaging_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec",
					5: "#productionOrder_curing_values",
					6: "#new_productionOrder_pattern",
					7: "#new_productionOrder_packaging"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 6, 
				"url": "overlay/productionOrderTemplate_new/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#potMenu_new", function () {
			overlay_open = 'orderTemplate_new';
			$("#potMenu_options").hide();
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);