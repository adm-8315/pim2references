<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset($_POST['add_equipment_name']) && $_POST['add_equipment_name'] != '' )
	{	
		
		$query = "
			INSERT
				INTO equipment
				( equipment, identifier, equipmentType, equipmentStatus, location )
				VALUES
				( ?, ?, ?, ?, ? )
		";
		
		$values = array(
			$_POST['add_equipment_name'],
			$_POST['add_equipment_identifyer'],
			$_POST['add_equipment_type'],
			$_POST['add_equipment_status'],
			$_POST['add_equipment_location']
		);
		
		$result['equipment'] = dbquery( $query, $values );
		
	}
	
	
	
	
	
	/**
	 * Display
	 */
	
	if ( $result['equipment'] )
	{
		echo $_POST['add_equipment_name'] . " was added successfully.";
	}
	else
	{
		echo "There was a problem adding the equipment.";
	}

?>