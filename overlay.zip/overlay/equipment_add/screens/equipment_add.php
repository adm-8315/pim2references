<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	
	// Equipment Type
	
	$query = "
		SELECT
			*
		FROM
			equipmentType et
		ORDER BY
			et.equipmentType 
	";
	
	$values = array();
	
	$result['equipmentType'] = dbquery( $query, $values );
	
	
	// Equipment Status
	
	$query = "
		SELECT
			*
		FROM
			equipmentStatus es
		ORDER BY
			es.equipmentStatus 
	";
	
	$values = array();
	
	$result['equipmentStatus'] = dbquery( $query, $values );
	
	
	// Location
	
	$query = "
		SELECT
			*
		FROM
			location l
		WHERE
			l.active = 1
		ORDER BY
			l.location
	";
	
	$values = array();
	
	$result['location'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id="add_equipment_table">
	
	<tr>
		<td class="left">Name</td>
		<td class="right"><input type="text" id="add_equipment_name" value="" /></td>
	</tr>
	
	<tr>
		<td class="left">Type</td>
		<td class="right">
			<select id="add_equipment_type">
				<option value='-1'>Choose...</option>
				<?php
				
					foreach ( $result['equipmentType'] as $row )
					{
						echo "<option value='" . $row['equipmentTypeID'] . "'>" . $row['equipmentType'] . "</option>";
					}
					
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Identifier</td>
		<td class="right"><input type="text" id="add_equipment_identifier" value="" /></td>
	</tr>
	
	<tr>
		<td class="left">Status</td>
		<td class="right">
			<select id="add_equipment_status">
				<?php
				
					foreach ( $result['equipmentStatus'] as $row )
					{
						echo "<option value='" . $row['equipmentStatusID'] . "'>" . $row['equipmentStatus'] . "</option>";
					}
					
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Location</td>
		<td class="right">
			<select id="add_equipment_location">
				<?php
				
					foreach ( $result['location'] as $row )
					{
						if ( $row['locationID'] == 1 )
						{
							echo "<option value='" . $row['locationID'] . "' selected='selected'>" . $row['location'] . "</option>";
						}
						else
						{
							echo "<option value='" . $row['locationID'] . "'>" . $row['location'] . "</option>";
						}
					}
					
				?>
			</select>
		</td>
	</tr>
	
</table>

<style>

#add_equipment_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_add_equipment_validation != 'function' )
	{
	
		var keyupString = '#add_equipment_name';
		var changeString = '#add_equipment_type';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_add_equipment_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_add_equipment_validation();
		});
	
		window.overlay_add_equipment_validation = function ()
		{
			if ( 
				$("#add_equipment_name").val() != "" &&
				$("#add_equipment_type").val() != -1
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_add_equipment_validation();
	
	}

</script>