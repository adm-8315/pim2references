( function ($) {
	
	overlay_setup['equipment_add'] = {
		"title": "Add Equipment",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/equipment_add/screens/equipment_add.php",
				"validation": "overlay_equipment_add_validation",
				"toSend": {
					0: "#add_equipment_name",
					1: "#add_equipment_type",
					2: "#add_equipment_identifier",
					3: "#add_equipment_status",
					4: "#add_equipment_location"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/equipment_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_equipment']", function () {
			overlay_open = 'equipment_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);