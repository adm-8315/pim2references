<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE item i
		SET
			i.item = ?,
			i.itemType = ?,
			i.lastPrice = ?,
			i.lastSupplier = ?
		WHERE
			i.itemID = ?
	";
	
	$values = array(
		$_POST['edit_item_name'],
		$_POST['edit_item_type'],
		$_POST['edit_item_lastPrice'],
		$_POST['edit_item_lastSupplier'],
		$_POST['overlay_item']
	);
	
	$result['itemUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['itemUpdate'] )
	{
		echo "The item details were updated.";
	}
	else
	{
		echo "There was a problem updating the item.";
	}

?>