<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Item
	
	$query = "
		SELECT
			*
		FROM
			item i
		WHERE
			i.itemID = ?
	";
	
	$values = array(
		$_POST['overlay_item']
	);
	
	$result['item'] = dbquery( $query, $values );
	
	
	// Item Type
	
	$query = "
		SELECT
			*
		FROM
			itemType it
	";
	
	$values = array();
	
	$result['itemType'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='edit_item_table'>

	<tr>
		<td class='left'>Name</td>
		<td class='right'><input type='text' id="edit_item_name" value='<?php echo $result['item'][0]['item']; ?>'/></td>
	</tr>
	
	<tr>
		<td class="left">Type</td>
		<td class="right">
			<select id="edit_item_type">
				<?php
				
				foreach ( $result['itemType'] as $row )
				{
					if ( $row['itemTypeID'] == $result['item'][0]['itemType'] )
					{
						echo "<option value='" . $row['itemTypeID'] . "' selected='selected'>" . $row['itemType'] . "</option>";
					}
					else
					{
						echo "<option value='" . $row['itemTypeID'] . "'>" . $row['itemType'] . "</option>";
					}
				}
					
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Last Supplier</td>
		<td class="right"><input type='text' id="edit_item_lastSupplier" value='<?php echo $result['item'][0]['lastSupplier']; ?>'/></td>
	</tr>
	
	<tr>
		<td class="left">Last Price</td>
		<td class="right"><input type='text' id="edit_item_lastPrice" value='<?php echo $result['item'][0]['lastPrice']; ?>'/></td>
	</tr>

</table>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_edit_item_validation != 'function' )
	{
	
		var keyupString = '#edit_grouping_name';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_item_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_item_validation();
		});
	
		window.overlay_edit_item_validation = function ()
		{
			overlay_valid(true);
		}
		
		window.overlay_edit_item_validation();
	
	}

</script>