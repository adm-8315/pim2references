( function ($) {
	
	overlay_setup['item_edit'] = {
		"title": "Edit Item",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_item"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/item_edit/screens/item_edit.php",
				"validation": "overlay_edit_item_validation",
				"toSend": {
					0: "#overlay_item",
					1: "#edit_item_name",
					2: "#edit_item_type",
					3: "#edit_item_lastPrice",
					4: "#edit_item_lastSupplier"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/item_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".item_edit", function () {
			overlay_open = 'item_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);