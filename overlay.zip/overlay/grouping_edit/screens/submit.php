<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE grouping g
		SET
			g.grouping = ?
		WHERE
			g.groupingID = ?
	";
	
	$values = array(
		$_POST['edit_grouping_name'],
		$_POST['overlay_grouping'],
	);
	
	$result['groupingUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['groupingUpdate'] )
	{
		echo "The grouping details were updated.";
	}
	else
	{
		echo "There was a problem updating the grouping.";
	}

?>