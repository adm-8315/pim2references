<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Job
	
	$query = "
		SELECT
			*
		FROM
			grouping g
		WHERE
			g.groupingID = ?
	";
	
	$values = array(
		$_POST['overlay_grouping']
	);
	
	$result['grouping'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='edit_grouping_table'>

	<tr>
		<td class='left'>Name</td>
		<td class='right'><input type='text' id="edit_grouping_name" value='<?php echo $result['grouping'][0]['grouping']; ?>'/></td>
	</tr>

</table>

<style>

#edit_grouping_table {
	margin: 0 auto;
}

#edit_grouping_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_edit_grouping_validation != 'function' )
	{
	
		var keyupString = '#edit_grouping_name';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_grouping_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_grouping_validation();
		});
	
		window.overlay_edit_grouping_validation = function ()
		{
			overlay_valid(true);
		}
		
		window.overlay_edit_grouping_validation();
	
	}

</script>