( function ($) {
	
	overlay_setup['curing_edit'] = {
		"title": "Edit Curing",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/productionOrderTemplate_edit_curing/screens/productionOrderTemplate_edit_curing.php",
				"validation": "overlay_edit_productionOrder_curing_validation",
				"toSend": {
					0: "#overlay_order",
					1: "#productionOrder_curing_values"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrderTemplate_edit_curing/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#po_curing_edit", function () {
			overlay_open = 'curing_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);