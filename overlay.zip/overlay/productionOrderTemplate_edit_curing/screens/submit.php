<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * Prepare Data
	 */
	
	$insertValues = explode( ",", $_POST['productionOrder_curing_values'] );
	
	
	/**
	 * MySQL
	 */
	
	// Remove Links
	
	$query = "
		DELETE 
			potpool
		FROM 
			productionOrderTemplateProductionOrderOptionLink potpool
		LEFT JOIN
			productionOrderOption poo
			ON potpool.productionOrderOption = poo.productionOrderOptionID
		WHERE
			poo.productionOrderOptionType = 1
		AND
			potpool.productionOrderTemplate = ?
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['remove'] = dbquery( $query, $values );
	
	
	// Insert Links
	
	if ( count( $insertValues ) > 0 )
	{
		$values = array();
		
		$query = "
			INSERT INTO
				productionOrderTemplateProductionOrderOptionLink
				( productionOrderTemplate, productionOrderOption )
			VALUES
		";
		
		foreach( $insertValues as $insertValue )
		{
			$query .= "( ?, ? ),";
			$values[] = $_POST['overlay_order'];
			$values[] = $insertValue;
		}
		
		$query = rtrim( $query, "," );
		
		$result['insert'] = dbquery( $query, $values );
		
	}
	
	// Production Order Update
	
	$query = "
		UPDATE productionOrderTemplate pot
		SET
			pot.user = ?
		WHERE
			pot.productionOrderTemplateID = ?
	";
	
	$values = array(
		$_SESSION['user_id'],
		$_POST['overlay_order']
	);
	
	$result['productionOrderUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
		
	echo "The production order details were updated.";

?>