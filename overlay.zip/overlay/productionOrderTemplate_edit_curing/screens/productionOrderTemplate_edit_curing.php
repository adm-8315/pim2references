<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		SELECT
			*
		FROM
			productionOrderTemplateProductionOrderOptionLink potpoo
		LEFT JOIN
			productionOrderOption poo
			ON potpoo.productionOrderOption = poo.productionOrderOptionID
		WHERE
			productionOrderTemplate = ?
		AND 
			poo.productionOrderOptionType = 1
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	
	// Production Order Option
	
	$query = "
		SELECT
			poo.productionOrderOptionID,
			poo.productionOrderOption
		FROM
			productionOrderOption poo
		WHERE
			poo.productionOrderOptionType = 1
	";

	$values = array();

	$result['productionOrderOption'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<input type="hidden" id="productionOrder_curing_values" value="">

<table id='edit_item_table'>
	
	<?php
		
	foreach( $result['productionOrderOption'] as $option )
	{
		
		echo "
			<tr>
				<td class='left'><label>{$option['productionOrderOption']}</label></td>
				<td class='right'>";
				
				$checked = false;
				
				foreach( $result['productionOrder'] as $row )
				{
					
					if ( $row['productionOrderOptionID'] == $option['productionOrderOptionID'] )
					{
						$checked = true;
					}
					
				}
				
				if ( $checked )
				{
					echo "<input type='checkbox' class='productionOrder_curing' data-id='{$option["productionOrderOptionID"]}' checked='checked' />";
				}
				else
				{
					echo "<input type='checkbox' class='productionOrder_curing' data-id='{$option["productionOrderOptionID"]}' />";
				}
				
		echo "	</td>
			</tr>	
		";
		
	}
		
	?>
	
</table>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_edit_productionOrder_curing_validation != 'function' )
	{
	
		var changeString = '.productionOrder_curing';
	
		$(document).on("change", changeString, function () {
			
			var outstring = "";
			
			$(".productionOrder_curing:checked").each( function () {
				outstring += $(this).data('id') + ",";
			});
			
			outstring = outstring.slice(0,-1);
			
			$("#productionOrder_curing_values").val( outstring );
			
		});
		
		
	
		window.overlay_edit_productionOrder_curing_validation = function ()
		{
			overlay_valid(true);
		}
		
		window.overlay_edit_productionOrder_curing_validation();
	
	}

</script>