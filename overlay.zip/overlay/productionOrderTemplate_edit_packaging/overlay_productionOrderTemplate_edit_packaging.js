( function ($) {
	
	overlay_setup['packaging_edit'] = {
		"title": "Edit Packaging",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/productionOrderTemplate_edit_packaging/screens/productionOrderTemplate_edit_packaging.php",
				"validation": "overlay_edit_productionOrder_packaging_validation",
				"toSend": {
					0: "#overlay_order",
					1: "#productionOrder_packaging_values"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrderTemplate_edit_packaging/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#po_packaging_edit", function () {
			overlay_open = 'packaging_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);