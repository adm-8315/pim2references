<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		SELECT
			potpoo.*
		FROM
			productionOrderTemplateProductionOrderOptionLink potpoo
		LEFT JOIN
			productionOrderOption poo
			ON potpoo.productionOrderOption = poo.productionOrderOptionID
		WHERE
			productionOrderTemplate = ?
		AND 
			poo.productionOrderOptionType = 2
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	
	// Production Order Options
	
	$query = "
		SELECT
			poo.productionOrderOptionID,
			poo.productionOrderOption
		FROM
			productionOrderOption poo
		WHERE
			poo.productionOrderOptionType = 2
	";

	$values = array();

	$result['productionOrderOption'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>


<input type="hidden" id="productionOrder_packaging_values" value="">

<table id='edit_item_table'>
	
	<?php
		
	foreach( $result['productionOrderOption'] as $option )
	{
		
		echo "
			<tr>
				<td class='left'><label>{$option['productionOrderOption']}</label></td>
				<td class='right'>";
				
				$checked = false;
				
				foreach( $result['productionOrder'] as $row )
				{
					
					if ( $row['productionOrderOption'] == $option['productionOrderOptionID'] )
					{
						$checked = true;
					}
					
				}
				
				if ( $checked )
				{
					echo "<input type='radio' name='packaging' class='packaging_option' data-id='{$option["productionOrderOptionID"]}' checked='checked' />";				}
				else
				{
					echo "<input type='radio' name='packaging' class='packaging_option' data-id='{$option["productionOrderOptionID"]}' />";
				}
		
		
		echo "		</td>
			</tr>	
		";
		
	}
		
	?>
	
</table>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_edit_productionOrder_packaging_validation != 'function' )
	{
	
		var changeString = '.packaging_option';
	
		$(document).on("change", changeString, function () {
			
			window.overlay_edit_productionOrder_packaging_validation();
			
			$("#productionOrder_packaging_values").val( $("input[name='packaging']:checked").data('id') );
			
		});
	
		window.overlay_edit_productionOrder_packaging_validation = function ()
		{
			
			if (
				$("input[name='packaging']:checked").val()
			)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_edit_productionOrder_packaging_validation();
	
	}

</script>