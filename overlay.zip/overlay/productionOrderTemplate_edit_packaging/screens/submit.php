<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Remove Links
	
	$query = "
		DELETE 
			potpool
		FROM 
			productionOrderTemplateProductionOrderOptionLink potpool
		LEFT JOIN
			productionOrderOption poo
			ON potpool.productionOrderOption = poo.productionOrderOptionID
		WHERE
			poo.productionOrderOptionType = 2
		AND
			potpool.productionOrderTemplate = ?
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['remove'] = dbquery( $query, $values );
	
	
	// Insert Links
	
	$query = "
		INSERT INTO
			productionOrderTemplateProductionOrderOptionLink
			( productionOrderTemplate, productionOrderOption )
		VALUES
			( ?, ? )
	";
	
	$values = array(
		$_POST['overlay_order'],
		$_POST['productionOrder_packaging_values']
	);
	
	$result['insert'] = dbquery( $query, $values );

	
	// Production Order Update
	
	$query = "
		UPDATE productionOrderTemplate pot
		SET
			pot.user = ?
		WHERE
			pot.productionOrderTemplateID = ?
	";
	
	$values = array(
		$_SESSION['user_id'],
		$_POST['overlay_order']
	);
	
	$result['productionOrderUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
		
	echo "The production order details were updated.";

?>