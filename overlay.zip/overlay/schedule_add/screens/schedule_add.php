<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/permissions.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			p.product,
			m.material as 'mainMaterial',
			CONCAT(MONTH(temp.fillDate),' / ',DAY(temp.fillDate),' / ',YEAR(temp.fillDate)) as 'fillDate',
			SUM(temp.quantityOrdered) - SUM(temp.quantityFilled) - IFNULL( SUM(pos.quantity), 0 ) as 'needToFill',
			f.formQuantity,
			f.formPieces
		FROM
			(
				SELECT
					temp.productionOrderID,
					temp.product,
					temp.quantityOrdered,
					temp.quantityFilled,
					temp.concatStringTemplate,
					temp.material,
					temp.quantity,
					GROUP_CONCAT( concatString ORDER BY temp.material ASC SEPARATOR '&' ) as 'concatStringTarget',
					temp.fillDate
				FROM
					(
						SELECT
							temp.concatStringTemplate,
							po.productionOrderID,
							poml.material,
							poml.quantity,
							po.quantityFilled,
							po.quantityOrdered,
							po.fillDate,
							po.product,
							IF (
								poml.water is not null,
								CONCAT( poml.material, '=', poml.water ),
								poml.material
							) as 'concatString'
						FROM
							(
								SELECT
									temp.product,
									GROUP_CONCAT( concatString ORDER BY temp.material ASC SEPARATOR '&' ) as 'concatStringTemplate'
								FROM
									(
										SELECT
											po.productionOrderID,
											po.product,
											poml.material,
											IF (
												poml.water is not null,
												CONCAT( poml.material, '=', poml.water ),
												poml.material
											) as 'concatString'
										FROM
											productionOrder po
										LEFT JOIN
											productionOrderMaterialLink poml
											ON po.productionOrderID = poml.productionOrder
										WHERE
											po.productionOrderID = ?
									) as temp
								GROUP BY
									temp.productionOrderID
							) as temp
						LEFT JOIN
							productionOrder po
							ON po.product = temp.product
							AND po.active = 1
						LEFT JOIN
							productionOrderMaterialLink poml
							ON po.productionOrderID = poml.productionOrder
						WHERE
							po.quantityFilled < po.quantityOrdered
						AND
							po.active = 1
						ORDER BY
							poml.quantity DESC
					) as temp
				GROUP BY
					temp.productionOrderID
			) as temp
			LEFT JOIN
				productionOrderSchedule pos
				ON temp.productionOrderID = pos.productionOrder
			LEFT JOIN
				product p
				ON p.productID = temp.product
			LEFT JOIN
				material m
				ON m.materialID = temp.material
			LEFT JOIN
				formProductLink fpl
				on temp.product = fpl.product
			LEFT JOIN
				form f
				ON fpl.form = f.formID
		WHERE
			concatStringTemplate = concatStringTarget
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrderTemplate'] = dbquery( $query, $values );
	
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<input type='hidden' id='overlay_productionOrder' value='<?php echo $_POST['overlay_order']; ?>'>
	<input type='hidden' id='overlay_delete' value='0'>

	<table id='queue_table'>
	
		<tr>
			<th>Precast Product</th>
			<td><?php echo $result['productionOrderTemplate'][0]['product']; ?></td>
		</tr>
	
		<tr>
			<th>Main Material</th>
			<td><?php echo $result['productionOrderTemplate'][0]['mainMaterial']; ?></td>
		</tr>
		
		<tr>
			<th>Date Required</th>
			<td><?php echo $result['productionOrderTemplate'][0]['fillDate']; ?></td>
		</tr>
	
		<tr>
			<th>Date</th>
			<td>
				<?php
					$datetime = new DateTime('tomorrow');
				?>
				<input type='text' id='overlay_date' value='<?= $datetime->format('m-d-Y'); ?>' class='transaction_transaction_form_date overlay_date' />
				<button class='trigger'>Date</button>
			</td>
		</tr>
		
		<tr>
			<th>Quantity</th>
			<td>
				<?php
								
					echo "<input type='number' id='overlay_quantity' min='1' ";
					
					if ( 
						! empty( $result['productionOrderTemplate'][0]['formPieces'] ) &&
						! empty( $result['productionOrderTemplate'][0]['formQuantity'] )
					) {
						$temp = $result['productionOrderTemplate'][0]['formPieces'] * $result['productionOrderTemplate'][0]['formQuantity'];
						if ( $temp <= $result['productionOrderTemplate'][0]['needToFill'] )
						{
							echo "max='{$temp}' value='{$temp}' ";
						}
						else
						{
							echo "max='{$result['productionOrderTemplate'][0]['needToFill']}' value='{$result['productionOrderTemplate'][0]['needToFill']}' ";
						}
						
					}
					else
					{
						echo "value='1' ";
					}
				
					if (
						! empty( $result['productionOrderTemplate'][0]['formPieces'] )
					) {
						$temp = $result['productionOrderTemplate'][0]['formPieces'];
						echo "step='{$temp}' ";
					}
				
					echo "/>";
				
				?>
			</td>
		</tr>
	
	</table>
	
	<?php
		
	if ( isset( $permissions[1][1] ) )
	{
		echo "<div id='transaction_deleteOrder'>
			<div data-nav='productionOrder' data-id='{$_POST['overlay_order']}'>View Order</div>
			<div>Delete Order</div>
		</div>";
	}
	?>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}

	.transaction_transaction_container table {
		margin: 0 auto;
	}
	
	.transaction_transaction_container th {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container td {
		float: right;
		
		height: 20px;
		width: 200px;
		
		margin-bottom: 10px;
		margin-left: 20px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container td select,
	.transaction_transaction_container td button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container td button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
		margin-top: 0px;
	}
	
	.trigger {
		margin-top: -10px;
	}
	
	.transaction_transaction_container input {
		width: 185px;
	}
	
	#transaction_transaction_form_adjust,
	#transaction_transaction_form_warning,
	.transaction_transaction_form_date {
		width: 100px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_unit {
		width: 76px;
	}
	
	#transaction_transaction_form_unit.display {
		float: right;
		display: inline-block;
		
		width: 40px;
		
		line-height: 30px;
		text-align: right;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
	#transaction_deleteOrder {
		position: absolute;
		
		bottom: -65px;
		left: 0;
		right: 0;
		
		text-align: center;
		
		cursor: pointer;
	}
	
	#transaction_deleteOrder div {
		position: relative;
		
		left: 70%;
		
		margin-left: -75px;
		
		width: 90px;
		height: 35px;
		
		background: #e2e2e2;
		
		border-radius: 4px;
		border: 1px solid #bbb;
		
		line-height: 35px;
	}
	
	#transaction_deleteOrder div:first-of-type {
		left: 43%;
		top: 37px;
	}
	
	#transaction_deleteOrder div:hover {
		background: #d3d3d3;

		border: 1px solid #aaa;
	}
	
	#overlay_quantity:focus:invalid {
		border-color: rgba(82,168,236,0.8);
		outline: 0;
		box-shadow: inset 0 1px 1px rgba(0,0,0,0.075), 0 0 8px rgba(82,168,236,0.6);
		color: #000;
	}
	
</style>

<script>

	if( typeof overlay_add_schedule_validation != 'function' )
	{	
		
		var keyupString = '#overlay_quantity';
		var changeString = '#overlay_quantity';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_add_schedule_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_add_schedule_validation();
		});
		
		$(document).on( "click", "#transaction_materialBrowse_deleteOrder", function () {
			
		});
	
		window.overlay_add_schedule_validation = function ()
		{
			
			if ( 
				$("#overlay_quantity").val() > 0
				<?php
					if ( 
						! empty( $result['productionOrderTemplate'][0]['formPieces'] ) &&
						! empty( $result['productionOrderTemplate'][0]['formQuantity'] )
					) {
						echo " && $(\"#overlay_quantity\").val() <= " . $result['productionOrderTemplate'][0]['formPieces'] * $result['productionOrderTemplate'][0]['formQuantity'];
					}
				?> 
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
			
		}
	
	}
	
	window.overlay_add_schedule_validation();

</script>