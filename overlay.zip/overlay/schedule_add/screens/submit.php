<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
		
	/**
	 * MySQL
	 */
	
	if ( $_POST['overlay_delete'] == 1 )
	{
		
		// Remove Scheduled
		
		$query = "
			DELETE FROM
				productionOrderSchedule
			WHERE
				productionOrder = ?
		";
		
		$values = array( $_POST['overlay_productionOrder'] );
		
		$result['removeSchedule'] = dbquery( $query, $values );
		
		// Remove Options
		
		$query = "
			DELETE FROM
				productionOrderProductionOrderOptionLink
			WHERE
				productionOrder = ?
		";
		
		$values = array( $_POST['overlay_productionOrder'] );
		
		$result['removeOptions'] = dbquery( $query, $values );
		
		
		// Remove Material Link
		
		$query = "
			DELETE FROM
				productionOrderMaterialLink
			WHERE
				productionOrder = ?
		";
		
		$result['removeMaterials'] = dbquery( $query, $values );
		
		// Remove Production Order
		
		$query = "
			DELETE FROM
				productionOrder
			WHERE
				productionOrderID = ?
		";
		
		$result['removeProductionOrder'] = dbquery( $query, $values );
		
	}
	else
	{
		
		// Schedule 
	
		$query = "
			INSERT 
				INTO 
					productionOrderSchedule
					( productionOrder, pourDate, quantity )
				VALUES
					( ?, ?, ? )
		";
	
		$values = array(
			$_POST['overlay_productionOrder'],
			date_to_mysql( $_POST['overlay_date'] ),
			$_POST['overlay_quantity']
		);
	
		$result['productionOrderSchedule'] = dbquery( $query, $values );
		
	}

?>