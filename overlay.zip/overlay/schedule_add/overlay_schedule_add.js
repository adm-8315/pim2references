( function ($) {
	
	overlay_setup['add_schedule'] = {
		"title": "Add to Schedule",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_add/screens/schedule_add.php",
				"validation": "overlay_add_schedule_validation",
				"toSend": {
					0: "#overlay_productionOrder",
					1: "#overlay_delete",
					2: "#overlay_quantity",
					3: "#overlay_date"
				},
				"closeDelay": function () {
					
					if ( $("#screen_overlay_content #overlay_delete").val() == "1" )
					{
						return 0;
					}
					else
					{
						return 2000;
					}
				},
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/schedule_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#transaction_deleteOrder div:last-of-type", function () {
			
			overlay_show( false, true );
			
			$("body").append( '<div id="dialog-confirm" title="Delete"><p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>Delete Production Order?</p></div>' );
			$( "#dialog-confirm" ).dialog({
		      	resizable: false,
		      	height:140,
		      	modal: true,
		      	buttons: {
		        	"Yes": function() {
						
						$("#screen_overlay_content #overlay_delete").val("1");
			
						overlay_update( overlay_setup[overlay_open], true );
						
		        		$( this ).dialog( "close" );
						overlay_show(false,true);
		        	},
		        	"No": function() {
		          	  	$( this ).dialog( "close" );
					 	$("#dialog-confirm").remove();
					 	overlay_show(false,true);
		        	}
		      }
		    });
			
			$('div#dialog-confirm').on( 'dialogclose', function(event) {
			     $("#dialog-confirm").remove();
			});

		});
		
		$(document).on("click", "#transaction_deleteOrder div:first-of-type", function () {
			
			overlay_show( false, true );
			
			generateURL( $(this) );

		});
		
		$(document).on("click", "tr[data-nav='overlay'][data-overlay='schedule']", function () {
			
			if ( $("#overlay_order").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_order'}) );
			}
			 
			$("#overlay_order").val( $(this).attr("data-id") );
			
			overlay_open = 'add_schedule';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);