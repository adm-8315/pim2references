<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/permissions.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Open Orders
	
	$query = "
		SELECT
			po.productionOrderID,
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			CONCAT(MONTH(po.fillDate),' / ',DAY(po.fillDate),' / ',YEAR(po.fillDate)) as 'fillDate',
			pos.pourDate
		FROM
			productionOrderSchedule pos
		LEFT JOIN
			productionOrder po
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		WHERE
			stripDate <= ?
		AND
			stripDate != '0000-00-00'
		AND
			fireDate = '0000-00-00'
	";
	
	$values = array(
		$_POST['overlay_date']
	);
	
	$result['readyFire'] = dbquery( $query, $values );
	
	
	// Strip Schedule
	
	$query = "
		SELECT
			po.productionOrderID,
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			CONCAT(MONTH(po.fillDate),' / ',DAY(po.fillDate),' / ',YEAR(po.fillDate)) as 'fillDate',
			pos.pourDate
		FROM
			productionOrderSchedule pos
		LEFT JOIN
			productionOrder po
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		WHERE
			fireDate = ?
	";
	
	$values = array(
		$_POST['overlay_date']
	);
	
	$result['fireSchedule'] = dbquery( $query, $values );
		
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<input type='hidden' id='schedule_fire_date' value='<?php echo $_POST['overlay_date']; ?>'>
	
	<div class='schedule_fireReady'>
		<h5>Ready to Fire</h5>
		<div class='product_container'>
			<table>
				
				<tr>
					<th class='product'>Product</th>
					<th></th>
					<th>Fill Date</th>
				</tr>
				
				<?php
				
				foreach( $result['readyFire'] as $row )
				{
					echo "<tr>";
					echo "<td class='alignLeft product' data-productionorder='{$row['productionOrderID']}' data-pourdate='{$row['pourDate']}'>{$row['product']}</td>";
					if ( strlen( $row['product'] ) > 22 )
					{
						echo "<td class='hover'><span data-title='{$row['product']}'></span></td>";
					}
					else
					{
						echo "<td class='hover'></td>";
					}
					echo "<td class='alignCenter fillDate'>{$row['fillDate']}</td>";
					echo "</tr>";
				}
				
				?>
			</table>
		</div>
	</div
	><div class='schedule_fire'>
		<h5>Fire Schedule</h5>
		<div class='product_container'>
			<table>
				
				<tr>
					<th class='product'>Product</th>
				</tr>
				
				<?php
				
				foreach( $result['fireSchedule'] as $row )
				{
					echo "<tr>";
					echo "<td class='alignLeft product' data-productionorder='{$row['productionOrderID']}' data-pourdate='{$row['pourDate']}'>{$row['product']}</td>";
					if ( strlen( $row['product'] ) > 22 )
					{
						echo "<td class='hover'><span data-title='{$row['product']}'></span></td>";
					}
					else
					{
						echo "<td class='hover'></td>";
					}
					echo "<td class='alignCenter fillDate'>{$row['fillDate']}</td>";
					echo "</tr>";
				}
				
				?>
			</table>
		</div>
	</div>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.schedule_fireReady,
	.schedule_fire {
		float: left;
		height: 320px;
	}
	
	.schedule_fireReady {
		width: 55%;
		margin-left: 2%;
	}
	
	.schedule_fire {
		width: 40%;
	}
	
	.schedule_fireReady {
		border-right: 1px solid #ccc;
	}
	
	.transaction_transaction_container h5 {
		color: #333;
		font-size: 14pt;
	}
	
	.alignLeft {
		text-align: left;
	}
	
	.alignRight {
		text-align: right;
	}
	
	.alignCenter {
		text-align: center;
	}
	
	td.product {
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		max-width: 150px;
	}
	
	.product_container {
		height: 320px;
		overflow: scroll;
	}
	
	.product_container table {
		border-spacing: 5px;
		border-collapse: separate;
	}
	
	.hover {
		position: relative;
	}
	
	td.product:hover ~ .hover span:after {
		position: absolute;
		display: inline-block;
		top: 20px;
		left: -158px;
		background: #333;
		background: rgba(0,0,0,1);
		border-radius: 5px;
		color: #fff;
		white-space: nowrap;
		content: attr(data-title);
		padding: 5px 15px;
		z-index: 9999;
		width: 230px;
	}
	
	.product_container tr:hover td.product {
		background: #ddd;
		cursor: pointer;
	}
	
	.ui-dialog {
	    z-index: 9999 !important;
	}
	
	.schedule_fire .hover,
	.schedule_fire .fillDate {
		display: none;
	}
	
	.mainButton {
		background: #4387fd !important;
		color: white !important;
	}

	
	
</style>

<script>

	if( typeof overlay_schedule_fire_validation != 'function' )
	{	
		
		var keyupString = '';
		var changeString = '';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_schedule_fire_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_schedule_fire_validation();
		});
	
		window.overlay_schedule_fire_validation = function ()
		{
			overlay_valid(true);
		}
		
		$(document).on("click", '.schedule_fireReady td.product', function () {
			
			var target = $(this);
			
			var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
					"pourDate=" + $(target).data('pourdate') + "&" +
					"fireDate=" + $("#schedule_fire_date").val();
			
			request = $.ajax({
				url: "ajax/schedule_add_fire.php",
				type: "post",
				data: ajaxData,
				global: false
			}).done( function ( response, textStatus, jqXHR) {
				
				var duplicate = $(target).parent().clone();
				$(duplicate).appendTo(".schedule_fire .product_container table tbody");
				
				$("div[data-date='" + $("#schedule_fire_date").val() + "'] .fire .product_scroll").append( $('<div/>',{"class":'productLine',"data-productionorder":$(target).data('productionorder'),"data-pourdate":$(target).data('pourdate')}) );
				$("div[data-date='" + $("#schedule_fire_date").val() + "'] .fire .product_scroll .productLine[data-productionorder='" + $(target).data('productionorder') + "'][data-pourdate='" + $(target).data('pourdate') + "']").text( $(target).text() );
				
				$(target).parent().remove();
				
			});	
			
		});
		
		
		$(document).on("click", '.schedule_fire td.product', function () {
			
			var target = $(this);
			
			var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
					"pourDate=" + $(target).data('pourdate');
			
			request = $.ajax({
				url: "ajax/schedule_delete_fire.php",
				type: "post",
				data: ajaxData,
				global: false
			}).done( function ( response, textStatus, jqXHR) {
				
				var duplicate = $(target).parent().clone();
				$(duplicate).appendTo(".schedule_fireReady .product_container table tbody");
				
				$("div[data-date='" + $("#schedule_fire_date").val() + "'] .fire .product_scroll .productLine[data-productionorder='" + $(target).data('productionorder') + "'][data-pourdate='" + $(target).data('pourdate') + "']").remove();
				
				$(target).parent().remove();
				
			});	
			
		});
		
	
	}
	
	window.overlay_schedule_fire_validation();

</script>