( function ($) {
	
	overlay_setup['schedule_fire'] = {
		"title": "Fire Schedule",
		"width": "600",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_date"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_fire/screens/schedule_fire.php",
				"validation": "overlay_schedule_fire_validation",
				"toSend": {
				},
				"disableBack": true,
				"closeDelay": 0,
				"pageRefresh": true
			}, { 
				"id" : 3, 
				"url": "overlay/schedule_fire/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".schedule_trigger", function () {
			
			trigger = $(this)
			
			if ( $(trigger).parent().attr('class') == 'fire' )
			{
				
				if ( $("#overlay_date").length == 0 )
				{
					$("body").append( $('<input/>',{type:'hidden',id:'overlay_date'}) );
				}
			 
				$("#overlay_date").val( $(trigger).parent().parent().data('date') );
			
				overlay_open = 'schedule_fire';
				overlay_create( overlay_setup[overlay_open] );
				
			}
			
		});
		
	});
	
})(jQuery);