<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$batchingVars = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Orders
		
	$query = "
		SELECT
			po.productionOrderID,
			pos.quantity,
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product )
			) as product,
			SUM( pos.quantity * poml2.quantity ) as 'materialSum'
		FROM
			productionOrderSchedule pos
		LEFT JOIN
			productionOrder po
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			(
				SELECT
					poml.*
				FROM
					productionOrderMaterialLink poml
				LEFT JOIN
					material m
					ON poml.material = m.materialID
				WHERE
					(
						m.materialType = 11
						OR m.materialType = 12
						OR m.materialType = 13
						OR m.materialType = 20
						OR m.materialType = 32
						OR m.materialType = 34
					)
			) poml2
			ON po.productionOrderID = poml2.productionOrder
		WHERE
			pos.pourDate = ?
		GROUP BY
			po.productionOrderID
		ORDER BY
			pos.productionOrder ASC,
			SUM( pos.quantity * poml2.quantity ) DESC
	";
	
	$values = array(
		$_POST['overlay_schedule_day']
	);
	
	$result['products'] = dbquery( $query, $values );
	
	
	// Batching 
	
	$query = "
		SELECT
			*
		FROM
			productionOrderScheduleBatching
		WHERE
			pourDate = ?
	";
	
	$values = array(
		$_POST['overlay_schedule_day']
	);
	
	$result['batching'] = dbquery( $query, $values );
	
	
	// Mixers
	
	$query = "
		SELECT
			mix.*
		FROM
			mixer mix
		WHERE
			mix.active = 1
		ORDER BY
			mix.mixerMax DESC
	";
	
	$values = array();
	
	$result['mixers'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	if ( ! empty( $result['batching'] ) )
	{
		$batchingVars = json_decode( $result['batching'][0]['batchingString'], true );
	}
		
			
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<input type='hidden' id='overlay_schedule_day' value='<?php echo $_POST['overlay_schedule_day']; ?>' />
	<input type='hidden' id='overlay_schedule_pour' value='' />
	
	<label>Schedule</label>

	<div id="schedule_container" style="height: 300px; overflow: auto;">
	<div id="schedule">
		<?php
		
			$priorityIndex = 0;
			$preplaced = array();
			
			if ( 
				isset( $batchingVars ) &&
				! empty ( $batchingVars )
			) {
				
				// Load Vars
				
				foreach ( $batchingVars as $batch )
				{
					
					echo "<div class='hour' id='" . $priorityIndex . "'><span class='hour_headers'><label>" . ($priorityIndex + 1) . "</label>";
					
					if (
						isset( $batch['batching'] )
					) {
						echo "<select disabled='disabled'>";
						
						echo "<option>Custom</option>";
					
					}
					else
					{
						
						echo "<select>";
				
						foreach ( $result['mixers'] as $row )
						{
							echo "<option value='{$row['mixerID']}'>{$row['mixer']}</option>";
						}
						
					}
					
					echo "</select><button>Batching</button></span>";
					
					foreach ( $batch['productionOrder'] as $productionOrder => $materialSum )
					{
						
						foreach ( $result['products'] as $product )
						{
							
							if ( $product['productionOrderID'] == $productionOrder )
							{
								$preplaced[] = $productionOrder;
								echo "<div class='product' data-materialSum='{$materialSum}' draggable='true' data-id='{$productionOrder}'>{$product['product']}</div>";
							}
							
						}
						
					}			
		
					echo "</div>";
					
					$priorityIndex++;
					
				}
				
			}
			
				
			// Autopopulate
			
			foreach ( $result['products'] as $product )
			{
				
				if ( ! in_array( $product['productionOrderID'], $preplaced ) )
				{
			
					echo "<div class='hour' id='" . $priorityIndex . "'><span class='hour_headers'><label>" . ($priorityIndex + 1) . "</label>";

					echo "<select>";
			
					foreach ( $result['mixers'] as $row )
					{
						echo "<option value='{$row['mixerID']}'>{$row['mixer']}</option>";
					}
			
					echo "</select><button>Batching</button></span>";
					echo "<div class='product' data-materialSum='{$product['materialSum']}' draggable='true' data-id='{$product['productionOrderID']}'>{$product['product']}</div>";
			
					echo "</div>";
				
					$priorityIndex++;
					
				}
				
			}
				
		?>
	</div>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container label {
		margin-bottom: 10px;
		
		font-size: 20px;
		font-weight: 800;
	}
	
	.schedule_container {
		height: 350px;
	}
	
	#schedule {
		width: 400px;
		margin: 0 auto;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}

	
	
	.hour.over {
	  border: 1px dotted #666;
	}
	
	.hour {
		width: 398px;
		min-height: 82px;
		border: 1px solid black;
		padding-bottom: 10px;
	}

	.hour label {
		cursor: default;
		margin-bottom: 20px;
		line-height: 40px;
	}
	
	.hour div {
		cursor: pointer;
	}
	
	.hour .hour_headers {
		position: relative;
		display: block;
		background: #ddd;
		height: 40px;
		margin-bottom: 10px;
	}
	
	.hour .hour_headers select {
		position:absolute;
		top: 5px;
		left: 5px;
		width: 100px;
		height: 30px;
	}
	
	.hour .hour_headers button {
		position:absolute;
		top: 5px;
		height: 30px;
		right: 5px;
		width: 100px;
	}
	
	.product {
		width: 364px;
		background: #eee;
		margin: 2px;
		margin-left: 10px;
		padding: 4px;
		border-radius: 2px;
		border: 1px solid #666;
	}
	
	.ignore {
		pointer-events: none;
	}
	
	/* Prevent the text contents of draggable elements from being selectable. */
	[draggable] {
	  -moz-user-select: none;
	  -khtml-user-select: none;
	  -webkit-user-select: none;
	  user-select: none;
	  /* Required to make elements draggable in old WebKit */
	  -khtml-user-drag: element;
	  -webkit-user-drag: element;
	}
		
</style>

<script>

	Object.size = function(obj) {
	    var size = 0, key;
	    for (key in obj) {
	        if (obj.hasOwnProperty(key)) size++;
	    }
	    return size;
	};

	var ready = true;
	var dragSrcEl = null;
	var schedule = [];
	var quantity = [];
	var mixers = {<?php
	
		foreach ( $result['mixers'] as $row )
		{
			echo "'" . $row['mixerID'] . "': { 'size': " .  $row['mixerMax'] . ", 'name': '" . $row['mixer'] . "' },";
		}
		
	?>};
	<?php
		if ( ! empty( $result['batching'] ) )
		{
			echo "var batching = " . $result['batching'][0]['batchingString'] . ";";
			echo "var loadedVars = true;";
		}
		else
		{
			echo "var batching = {};";
			echo "var loadedVars = undefined;";
		}
	?>

	if( typeof overlay_schedule_print_validation != 'function' )
	{	
		
		$(document).on( "dragstart", ".product", function ( e ) {
			
			dragSrcEl = $(this);
			$(".product").addClass("ignore");
			$(this).removeClass("ignore");
			
			e.originalEvent.dataTransfer.effectAllowed = 'move';
			
		});
		
		$(document).on( "dragover", ".hour", function ( e ) {
			
			if (e.preventDefault) {
				e.preventDefault();
			}

			e.originalEvent.dataTransfer.dropEffect = 'move';
			
			return false;
			
		});
		
		$(document).on( "dragenter", ".hour", function ( e ) {
			if ( $(this).hasClass("product") )
			{
				$(this).parent().addClass("over");
			}
			else
			{
				$(this).addClass("over");
			}
		});
		
		$(document).on( "dragleave", ".hour", function ( e ) {
			if ( $(this).hasClass("product") )
			{
				$(this).parent().removeClass("over");
			}
			else
			{
				$(this).removeClass("over");
			}
			
		});
		
		$(document).on( "dragend", ".product", function ( e ) {
			$(".hour").removeClass("over");
		});
		
		$(document).on( "drop", ".hour,.product", function ( e ) {
						
		    if (e.stopPropagation) {
				e.stopPropagation();
		    }
			
			var old = dragSrcEl.parent().attr("id");
			

			if ( 
				$(this).hasClass("product") &&
				! $(this).is( dragSrcEl.parent() ) &&
				! $(this).parent().is( dragSrcEl.parent() ) 
			) {
				
				$( dragSrcEl ).appendTo( $(this).parent() );
				
				$(this).parent().append( 
					$(this).parent().children("div").sort(function(a, b) {
					   var compA = $(a).text().toUpperCase();
					   var compB = $(b).text().toUpperCase();
					   return (compA < compB) ? -1 : (compA > compB) ? 1 : 0;
					})
				);
				
			}
			else if ( 
				$(this).hasClass("hour") &&
				! $(this).is( dragSrcEl.parent() ) &&
				! $(this).parent().is( dragSrcEl.parent() ) 
			) {
				
				$(this).append( dragSrcEl );
				
				$(this).append( 
					$(this).children("div").sort(function(a, b) {
					   var compA = $(a).text().toUpperCase();
					   var compB = $(b).text().toUpperCase();
					   return (compA < compB) ? -1 : (compA > compB) ? 1 : 0;
					})
				);
				
			}	
			
			
			$(".product").removeClass("ignore");
			//window.overlay_schedule_pour_string();
			window.overlay_schedule_mixer_autopick();	
			window.overlay_schedule_batch_move( $(this).attr("id"), old );
			
		});
		
		$(document).on( "change", ".hour select", function () {
			batching[$(this).parent().parent().attr("id")]['mixer'] = $(this).find("option:selected").val();
			$("#overlay_schedule_batching").val( JSON.stringify( batching ) );
		});
	
		window.overlay_schedule_print_validation = function ()
		{
			
			overlay_valid(true);
			
		}
		
		window.overlay_schedule_pour_string = function ()
		{
			
			schedule = new Array();
			
			$(".hour:has(>.product)").each( function () {
		
				var hour = $(this).attr("id");
		
				schedule[hour] = [];
		
				$(this).children(".product").each( function () {
			
					schedule[hour].push( $(this).attr("data-id") );
			
				});
		
			});
	
			$("#overlay_schedule_pour").val( JSON.stringify(schedule) );
			
			window.overlay_schedule_mixer_autopick();
			
		}
		
		window.overlay_schedule_batch_move = function ( newHour, oldHour )
		{
			
			//console.log( newHour );
			//console.log( oldHour );
						
			if ( batching[newHour] === undefined)
			{
				batching[newHour] = {};
			}
			batching[newHour]['mixer'] = $(".hour[id='" + newHour + "'] select option:selected").val();
			batching[newHour]['materialSum'] = 0;
			batching[newHour]['productionOrder'] = {};
			if ( batching[newHour]['batching'] !== undefined )
			{
				delete batching[newHour]['batching'];
			}
			
			batching[oldHour]['mixer'] = $(".hour[id='" + oldHour + "'] select option:selected").val();
			batching[oldHour]['materialSum'] = 0;
			batching[oldHour]['productionOrder'] = {};
			if ( batching[oldHour]['batching'] !== undefined )
			{
				delete batching[oldHour]['batching'];
			}
			
			// New Hour
			$(".hour[id='" + newHour + "'] .product").each( function () {
				
				// Material Sum
				batching[newHour]['materialSum'] += parseFloat($(this).attr("data-materialsum"));
				
				// Production Order
				batching[newHour]['productionOrder'][$(this).attr("data-id")] = $(this).attr("data-materialsum");
				
			});
			
			
			// Old Hour
			$(".hour[id='" + oldHour + "'] .product").each( function () {
				
				// Material Sum
				batching[oldHour]['materialSum'] += parseFloat($(this).attr("data-materialsum"));
				
				// Production Order
				batching[newHour]['productionOrder'][$(this).attr("data-id")] = $(this).attr("data-materialsum");
				
			});
			
			if ( $(".hour[id='" + oldHour + "'] .product").length === 0 )
			{
				delete batching[oldHour];
				$(".hour[id='" + oldHour + "']").remove();
			}
			
			
			// Re-number
			var index = 0;
			
			$(".hour").each( function ()
			{
				if ( index != $(this).attr("id") )
				{
					batching[index] = batching[$(this).attr("id")];
					delete batching[$(this).attr("id")];
					$(this).attr("id", index );
					$(this).find(".hour_headers label").text(index + 1);
				}
				index++;
			});
			
			
			// Add Extra Hour
			if ( $(".hour").length < $(".product").length )
			{
				var clone = $(".hour:first-of-type").clone();
				
				clone.attr("id", index);
				clone.find(".hour_headers label").text( index + 1 );
				clone.find(".hour_headers select").attr("disabled", false);
				clone.find(".hour_headers select option").each( function () {
					$(this).remove();
				});
				$.each( mixers, function ( key, value ) {
					clone.find(".hour_headers select").append("<option value='" + key + "'>" + value['name'] + "</option>");
				});
				clone.find(".product").each( function () {
					$(this).remove();
				});
				
				
				$("#schedule").append( clone );
			}
			
			
			
			$("#overlay_schedule_batching").val( JSON.stringify( batching ) );
	
		}
		
		window.overlay_schedule_mixer_autopick = function ()
		{
			
			$(".hour").each( function () {
		
				var hour = $(this).attr("id");
		
				quantity[hour] = 0;
		
				$(this).children(".product").each( function () {
			
					quantity[hour] += parseInt( $(this).attr("data-materialSum") );
			
				});
				
				var found = false;
				
				$.each( mixers, function ( index, value ) {
					
					if ( quantity[hour] < value['size'] )
					{
						$(".hour[id='" + hour + "'] select option[value='" + index + "']").prop("selected", true);
						found = true;
					} 
					
				});
				
				if ( ! found )
				{
					$(".hour[id='" + hour + "'] select option:first-of-type").prop("selected", true);
				}
		
			});
			
			//console.log( quantity );
		}
		
		window.overlay_schedule_print_validation();
		window.overlay_schedule_pour_string();		
	
	}
	
	
	$(document).ready( function () {
						
		if ( ready )
		{
						
			ready = false;
			
			
			// Add Variable Container
						
			if ( $("#overlay_schedule_batching").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_schedule_batching'}) );
			}
						
			// Load vars
			
			if ( loadedVars )
			{
				
				var index = parseInt($(".hour:last-of-type").attr("id")) + 1;
				
				$.each( batching, function ( key, value ) {
					$(".hour[id='" + key + "']").find("select").val( value['mixer'] );
				});
				
				// Add Extra Hour
				if ( $(".hour").length < $(".product").length )
				{
					var clone = $(".hour:first-of-type").clone();
				
					clone.attr("id", index);
					clone.find(".hour_headers label").text( index + 1 );
					clone.find(".hour_headers select").attr("disabled", false);
					clone.find(".hour_headers select option").each( function () {
						$(this).remove();
					});
					$.each( mixers, function ( key, value ) {
						clone.find(".hour_headers select").append("<option value='" + key + "'>" + value['name'] + "</option>");
					});
					clone.find(".product").each( function () {
						$(this).remove();
					});
				
				
					$("#schedule").append( clone );
				}
				
				$('.hour[id]').filter(function() {
				  return $(this).attr("id") >= Object.size(batching);
				}).each( function () {
					
					var hour = $(this).attr("id");
					
					batching[hour] = {};
					batching[hour]['mixer'] = $(this).find(".hour_headers select option:selected").val();
					batching[hour]['materialSum'] = 0;
					batching[hour]['productionOrder'] = {};

					$(this).children(".product").each( function () {
		
						batching[hour]['materialSum'] += parseInt( $(this).attr("data-materialsum") );
						batching[hour]['productionOrder'][$(this).attr("data-id")] = $(this).attr("data-materialsum");

					});
					
				});
				
				$("#overlay_schedule_batching").val( JSON.stringify( batching ) );
				
			}
			else
			{
				
				$(".hour").each( function () {
					var hour = $(this).attr("id");
					
					batching[hour] = {};
					batching[hour]['mixer'] = $(this).find(".hour_headers select option:selected").val();
					batching[hour]['materialSum'] = 0;
					batching[hour]['productionOrder'] = {};

					$(this).children(".product").each( function () {
		
						batching[hour]['materialSum'] += parseInt( $(this).attr("data-materialsum") );
						batching[hour]['productionOrder'][$(this).attr("data-id")] = $(this).attr("data-materialsum");

					});
					
				});
				
				$("#overlay_schedule_batching").val( JSON.stringify( batching ) );
				
			}			
			
			window.overlay_schedule_mixer_autopick();
			//window.overlay_schedule_pour_string();	
	
			$("#schedule_container").scrollTop($('.product:first-of-type').parent().offset().top - $('#schedule_container').offset().top + $('#schedule_container').scrollTop());
		
		}
		
	});

</script>
