( function ($) {
	
	overlay_setup['schedule_print'] = {
		"title": "Print",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_schedule_day"
				} 
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_print/screens/schedule.php",
				"validation": "overlay_schedule_print_validation"
			}, { 
				"id" : 2, 
				"url": "overlay/schedule_print/screens/schedule_print.php",
				"validation": "overlay_add_schedule_validation",
				"toSend": {
					0: "#overlay_schedule_day",
					1: "#overlay_schedule_batching",
					2: "#overlay_schedule_print_notes",
					3: "#overlay_schedule_print_maintenance"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"noAJAX": true
			}, { 
				"id" : 3, 
				"url": "print.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".schedule_print", function () {
			
			if ( $("#overlay_schedule_day").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_schedule_day'}) );
			}
			 
			$("#overlay_schedule_day").val( $(this).attr("data-day") );
			$("#overlay_schedule_batching").val( );
			
			overlay_open = 'schedule_print';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);