( function ($) {
	
	overlay_setup['qc_edit'] = {
		"title": "Edit Quality Control",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/productionOrderTemplate_edit_qc/screens/productionOrderTemplate_edit_qc.php",
				"validation": "overlay_edit_productionOrder_qc_validation",
				"toSend": {
					0: "#overlay_order",
					1: "#edit_productionOrder_taps",
					2: "#edit_productionOrder_lowerSpec",
					3: "#edit_productionOrder_upperSpec"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrderTemplate_edit_qc/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#po_qc_edit", function () {
			overlay_open = 'qc_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);