<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order Update
	
	$query = "
		UPDATE productionOrderTemplate pot
		SET
			pot.taps = ?,
			pot.lowerSpec = ?,
			pot.upperSpec = ?,
			pot.user = ?
		WHERE
			pot.productionOrderTemplateID = ?
	";
	
	$values = array(
		$_POST['edit_productionOrder_taps'],
		$_POST['edit_productionOrder_lowerSpec'],
		$_POST['edit_productionOrder_upperSpec'],
		$_SESSION['user_id'],
		$_POST['overlay_order']
	);
	
	$result['productionOrderUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['productionOrderUpdate'] )
	{
		echo "The production order details were updated.";
	}
	else
	{
		echo "There was a problem updating the production order.";
	}

?>