<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		SELECT
			*
		FROM
			productionOrderTemplate pot
		WHERE
			pot.productionOrderTemplateID = ?
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='edit_item_table'>
	
	<tr>
		<td class='left'><label>Taps</label></td>
		<td class='right'>
			<input type='text' id="edit_productionOrder_taps" value="<?php echo $result['productionOrder'][0]['taps']; ?>"/>
		</td>
	</tr>
	
	<tr>
		<td class='left'><label>Lower Spec</label></td>
		<td class='right'>
			<input type='text' id="edit_productionOrder_lowerSpec" class='specs' value="<?php echo $result['productionOrder'][0]['lowerSpec']; ?>"/>
		</td>
	</tr>
	
	<tr>
		<td class='left'><label>Upper Spec</label></td>
		<td class='right'>
			<input type='text' id="edit_productionOrder_upperSpec" class='specs' value="<?php echo $result['productionOrder'][0]['upperSpec']; ?>"/>
		</td>
	</tr>
	
</table>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	$("#screen_overlay_content")
		.find("#edit_productionOrder_taps")
		.mask('99');

	$("#screen_overlay_content")
		.find(".specs")
		.mask('9.9', {
			translation: {
				'~': {
					pattern: /[0-9|.]/
				}
			}
		});

	if( typeof overlay_edit_productionOrder_qc_validation != 'function' )
	{
	
		var keyupString = '#edit_productionOrder_taps, #edit_productionOrder_lowerSpec, #edit_productionOrder_upperSpec';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_productionOrder_qc_validation();
		});
	
		window.overlay_edit_productionOrder_qc_validation = function ()
		{
			
			if (
				$("#edit_productionOrder_taps").val() != "" &&
				$("#edit_productionOrder_lowerSpec").val() != "" &&
				$("#edit_productionOrder_upperSpec").val() != ""
			)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_edit_productionOrder_qc_validation();
	
	}

</script>