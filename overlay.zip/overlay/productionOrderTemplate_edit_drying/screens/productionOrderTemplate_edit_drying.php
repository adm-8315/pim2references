<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		SELECT
			*
		FROM
			productionOrderTemplate pot
		LEFT JOIN
			furnacePattern fp
			ON pot.furnacePattern = fp.furnacePatternID
		WHERE
			pot.productionOrderTemplateID = ?
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	// Furnace
	
	$query = "
		SELECT
			*
		FROM
			furnace f
	";
	
	$values = array();
	
	$result['furnace'] = dbquery( $query, $values );
	
	// Furnace Pattern
	
	if ( $result['productionOrder'][0]['furnacePatternID'] != null )
	{
		
		$query = "
			SELECT
				*
			FROM
				furnacePattern fp
			JOIN
				(
					SELECT
						fp.furnace
					FROM
						furnacePattern fp
					WHERE
						fp.furnacePatternID = 1
				) temp
			WHERE
				fp.furnace = temp.furnace
		";
		
		$values = array(
			$result['productionOrder'][0]['furnacePattern']
		);
		
		$result['furnacePattern'] = dbquery( $query, $values );
		
	}
	
	/**
	 * Display
	 */

?>

<table id='edit_item_table'>
	
	<tr>
		<td class='left'><label>Furnace</label></td>
		<td class='right'>
			<select id="new_productionOrder_furnace">
				<option value='-1'>Choose...</option>
				<?php
				foreach ( $result['furnace'] as $furnace )
				{
					if ( $result['productionOrder'][0]['furnace'] == $furnace['furnaceID'] )
					{
						echo "<option value='{$furnace['furnaceID']}' selected='selected'>{$furnace['furnace']}</option>";
					}
					else
					{
						echo "<option value='{$furnace['furnaceID']}'>{$furnace['furnace']}</option>";
					}
					
				}
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class='left'><label>Pattern</label></td>
		<td class='right'>
			<select id='new_productionOrder_pattern'>
				<option value='-1'>Choose...</option>
				
				<?php
					
				foreach ( $result['furnacePattern'] as $furnacePattern )
				{
					
					if ( $result['productionOrder'][0]['furnacePatternID'] == $furnacePattern['furnacePatternID'] )
					{
						echo "<option value='{$furnacePattern['furnacePatternID']}' selected='selected'>";
					}
					else
					{
						echo "<option value='{$furnacePattern['furnacePatternID']}'>";
					}
					
					echo $furnacePattern['furnacePattern'] . ": ";
					echo $furnacePattern['patternDescription'] . " - ";
					echo $furnacePattern['patternTemperature'] . "°F for ";
					echo $furnacePattern['patternTime'] . "hr";
					echo "</option>";
				}
				
				?>
				
			</select>
		</td>
	</tr>
	
</table>

<style>

#edit_item_table {
	margin: 0 auto;
}

#edit_item_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

</style>

<script>

	( function ($) {
	
		$("#new_productionOrder_furnace").on("change", function () {
		
			if ( $("#new_productionOrder_furnace").val() != "-1" )
			{
				request = $.ajax({
					url: "ajax/new_productionOrder_pattern.php",
					type: "post",
					data: "new_productionOrder_furnace=" +
						$("#new_productionOrder_furnace").val()
				}).done( function ( response, textStatus, jqXHR) {
					$("#screen_overlay_content")
						.find("#new_productionOrder_pattern")
						.html( response );
						
						window.overlay_edit_productionOrder_drying_validation();
				});
			}
		
		});
	
	})(jQuery);

	if( typeof overlay_edit_productionOrder_drying_validation != 'function' )
	{
	
		var changeString = '#new_productionOrder_furnace, #new_productionOrder_pattern';
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_productionOrder_drying_validation();
		});
	
		window.overlay_edit_productionOrder_drying_validation = function ()
		{
			
			if (
				$("#new_productionOrder_furnace").val() != "-1" &&
				$("#new_productionOrder_pattern").val() != "-1"
			)
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_edit_productionOrder_drying_validation();
	
	}

</script>