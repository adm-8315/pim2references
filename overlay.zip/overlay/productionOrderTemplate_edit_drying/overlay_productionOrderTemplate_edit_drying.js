( function ($) {
	
	overlay_setup['drying_edit'] = {
		"title": "Edit Drying",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/productionOrderTemplate_edit_drying/screens/productionOrderTemplate_edit_drying.php",
				"validation": "overlay_edit_productionOrder_drying_validation",
				"toSend": {
					0: "#overlay_order",
					1: "#new_productionOrder_pattern"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrderTemplate_edit_drying/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#po_drying_edit", function () {
			overlay_open = 'drying_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);