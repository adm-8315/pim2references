<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	require_once( "../../../inc/session.php" );
	require_once( "../../../inc/permissions.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			m.material,
			m.stdWater,
			m.waterLow,
			m.waterHigh,
			m.stdMix,
			m.mixLow,
			m.mixHigh,
			m.taps,
			m.lowerSpec,
			m.upperSpec
		FROM
			material m
		WHERE
			m.materialID = ?
	";
	
	$values = array(
		$_POST['overlay_material']
	);
	
	$result['material'] = dbquery( $query, $values );

?>
<div class='transaction_transaction_container'>
	
	<div id='transaction_transaction_form_transationType'>Edit</div>
	
	<div id="transaction_transaction_form_materialDisplay" data-material="<?php echo $_POST['overaly_material']; ?>"><?php echo $result['material'][0]['material']; ?></div>
	
	<table class='qc_table'>
		
		<tr>
			<th></th>
			<th class='std'>Std.</th>
			<th class='mfgLow'>Mfg. Low</th>
			<th class='mfgHigh'>Mfg. High</th>
		</tr>
		
		<tr class='qc_water'>
			<th class='left'>Water</th>
			<td class='right std'><input type='text' id='qc_edit_stdWater'<?php
				if ( isset( $result['material'][0]['stdWater'] ) )
				{
					echo "value='" . $result['material'][0]['stdWater'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][36]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgLow'><input type='text' id='qc_edit_waterLow'<?php
				if ( isset( $result['material'][0]['waterLow'] ) )
				{
					echo "value='" . $result['material'][0]['waterLow'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][37]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgHigh'><input type='text' id='qc_edit_waterHigh'<?php
				if ( isset( $result['material'][0]['waterHigh'] ) )
				{
					echo "value='" . $result['material'][0]['waterHigh'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][37]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
		</tr>
		
		<tr class='qc_mix'>
			<th class='left'>Mix</th>
			<td class='right std'><input type='text' id='qc_edit_stdMix'<?php
				if ( isset( $result['material'][0]['stdMix'] ) )
				{
					echo "value='" . $result['material'][0]['stdMix'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][36]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgLow'><input type='text' id='qc_edit_mixLow'<?php
				if ( isset( $result['material'][0]['mixLow'] ) )
				{
					echo "value='" . $result['material'][0]['mixLow'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][37]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgHigh'><input type='text' id='qc_edit_mixHigh'<?php
				if ( isset( $result['material'][0]['mixHigh'] ) )
				{
					echo "value='" . $result['material'][0]['mixHigh'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][37]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
		</tr>
		
		<tr class='qc_taps'>
			<th class='left'>Taps</th>
			<td class='right std'><input type='text' id='qc_edit_taps'<?php
				if ( isset( $result['material'][0]['taps'] ) )
				{
					echo "value='" . $result['material'][0]['taps'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][36]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgLow'></td>
			<td class='right mfgHigh'></td>
		</tr>
		
		<tr class='qc_lowerSpec'>
			<th class='left'>Lower Spec.</th>
			<td class='right std'><input type='text' id='qc_edit_lowerSpec'<?php
				if ( isset( $result['material'][0]['lowerSpec'] ) )
				{
					echo "value='" . $result['material'][0]['lowerSpec'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][36]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgLow'></td>
			<td class='right mfgHigh'></td>
		</tr>
		
		<tr class='qc_upperSpec'>
			<th class='left'>Upper Spec.</th>
			<td class='right std'><input type='text' id='qc_edit_upperSpec'<?php
				if ( isset( $result['material'][0]['upperSpec'] ) )
				{
					echo "value='" . $result['material'][0]['upperSpec'] . "'"; 	
				} 
			?> <?php
				if ( ! isset($permissions[7][36]) )
				{
					echo "disabled='disabled'";
				}
			?>/></td>
			<td class='right mfgLow'></td>
			<td class='right mfgHigh'></td>
		</tr>
		
	</table>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container #transaction_transaction_container {
		width: 300px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 35px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container div.field {
		float: right;
		
		height: 20px;
		width: 160px;
		
		margin-bottom: 10px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
	}
	
	#transaction_transaction_form_name {
		width: 170px !important;
		
		margin-right: 10px;
	}

	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
	.std input,
	.mfgLow input,
	.mfgHigh input {
		width: 50px;
	}
	
</style>

<script>

	$("#screen_overlay_content")
		.find(".qc_water input")
		.mask('999.99');
		
	$("#screen_overlay_content")
		.find(".qc_mix input")
		.mask('99');
		
	$("#screen_overlay_content")
		.find(".qc_taps input")
		.mask('99');
		
	$("#screen_overlay_content")
		.find(".qc_lowerSpec input")
		.mask('9.9');
		
	$("#screen_overlay_content")
		.find(".qc_upperSpec input")
		.mask('9.9');
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			overlay_valid(true);

		}
		
		window.overlay_transaction_transaction_validation();
		
	}


</script>