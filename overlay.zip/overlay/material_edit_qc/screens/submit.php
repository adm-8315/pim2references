<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * Prepare Data
	 */
	
	foreach ( $_POST as $key => $value )
	{
		
		if ( 
			$key != 'overlay_material' &&
			empty($value)
		) {
			$_POST[$key] = null;
		}
		
	}
		
	
	/**
	 * MySQL
	 */
	
	// Material Update
	
	$query = "
		UPDATE
			material
		SET
			stdWater = ?,
			waterLow = ?,
			waterHigh = ?,
			stdMix = ?,
			mixLow = ?,
			mixHigh = ?,
			taps = ?,
			lowerSpec = ?,
			upperSpec = ?
		WHERE
			materialID = ?
	";
	
	$values = array(
		$_POST['qc_edit_stdWater'],
		$_POST['qc_edit_waterLow'],
		$_POST['qc_edit_waterHigh'],
		$_POST['qc_edit_stdMix'],
		$_POST['qc_edit_mixLow'],
		$_POST['qc_edit_mixHigh'],
		$_POST['qc_edit_taps'],
		$_POST['qc_edit_lowerSpec'],
		$_POST['qc_edit_upperSpec'],
		intval( $_POST['overlay_material'] )
	);
	
	$result['materialUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Material Updated</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
	}
</style>