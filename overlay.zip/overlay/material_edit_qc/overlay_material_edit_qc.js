( function ($) {
	
	overlay_setup['qc_edit'] = {
		"title": "Quality Control",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/material_edit_qc/screens/material_edit_qc.php",
				"toSend": {
					0: "#overlay_material",
					1: "#qc_edit_stdWater",
					2: "#qc_edit_waterLow",
					3: "#qc_edit_waterHigh",
					4: "#qc_edit_stdMix",
					5: "#qc_edit_mixLow",
					6: "#qc_edit_mixHigh",
					7: "#qc_edit_taps",
					8: "#qc_edit_lowerSpec",
					9: "#qc_edit_upperSpec"
				},
				//"closeDelay": 2000,
				//"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/material_edit_qc/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#qc_edit", function () {
			overlay_open = 'qc_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);