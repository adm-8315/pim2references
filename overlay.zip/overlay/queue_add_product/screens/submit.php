<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once('../../../inc/functions/date_conversion.php');
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		INSERT 
			INTO 
				productionOrder
				( product, quantityOrdered, fillDate, notes, taps,lowerSpec, upperSpec, furnacePattern, user )
			SELECT
				pot.product,
				?,
				?,
				pot.notes,
				pot.taps,
				pot.lowerSpec,
				pot.upperSpec,
				pot.furnacePattern,
				?
			FROM 
				productionOrderTemplate pot
			LEFT JOIN
				productConsumerLink pcl
				ON pot.product = pcl.product
			WHERE 
				pot.productionOrderTemplateID = ?;
	";
	
	$values = array(
		$_POST['overlay_queue_quantity'],
		date_to_mysql( $_POST['overlay_date'] ),
		$_SESSION['user_id'],
		$_POST['overlay_productionOrder']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	
	// Production Order Material Link
	
	$query = "
		INSERT 
			INTO 
				productionOrderMaterialLink
			SELECT
				?,
				material,
				quantity,
				water,
				mixTime,
				vibrationType,
				vibrationTime
			FROM 
				productionOrderTemplateMaterialLink potml
			WHERE 
				potml.productionOrderTemplate = ?;
	";
	
	$values = array(
		$result['productionOrder'],
		$_POST['overlay_productionOrder']
	);
	
	$result['productionOrderMaterialLink'] = dbquery( $query, $values );
	
	
	// Production Order - Production Order Option Link
	
	$query = "
		INSERT 
			INTO 
				productionOrderProductionOrderOptionLink
			SELECT
				?,
				potpool.productionOrderOption
			FROM 
				productionOrderTemplateProductionOrderOptionLink potpool
			WHERE 
				potpool.productionOrderTemplate = ?;
	";
	
	$values = array(
		$result['productionOrder'],
		$_POST['overlay_productionOrder']
	);
	
	$result['productionOrderProductionOrderOptionLink'] = dbquery( $query, $values );

?>