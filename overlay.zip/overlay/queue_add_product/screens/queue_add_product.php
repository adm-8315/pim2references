<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Info
	
	$query = "
		SELECT
			p.product as 'product',
			m.material as 'mainMaterial',
			f.formQuantity,
			f.formPieces
		FROM
			productionOrderTemplate pot
		LEFT JOIN
			product p
			ON pot.product = p.productID
		LEFT JOIN
			productionOrderTemplateMaterialLink potml
			ON pot.productionOrderTemplateID = potml.productionOrderTemplate
		LEFT JOIN
			material m
			ON potml.material = m.materialID
		LEFT JOIN
			formProductLink fpl
			ON fpl.product = p.productID
		LEFT JOIN
			form f
			ON fpl.form = f.formID
		WHERE
			pot.productionOrderTemplateID = ?
		AND
			(
					m.materialType = 11
				OR
					m.materialType = 12
				OR
					m.materialType = 13
			)
		ORDER BY
			potml.quantity DESC
		LIMIT 1
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrderTemplate'] = dbquery( $query, $values );
	
	
	// Warnings
	
	$query = "
		SELECT
			potml.material as 'materialID',
			m.material,
			potml.quantity,
			IF(
				temp.quantity is null,
				ROUND(SUM(mi.stock)),
				ROUND(SUM(mi.stock) - temp.quantity)
			) as 'stock',
			me.measureSingular,
			me.measurePlural
		FROM
			productionOrderTemplateMaterialLink potml
		LEFT JOIN
			material m
			ON potml.material = m.materialID
		LEFT JOIN
			measure me
			ON m.measure = me.measureID
		LEFT JOIN
			materialInventory mi
			ON potml.material = mi.material
		LEFT JOIN
			companyLocationLink cll
			ON mi.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			(
				SELECT
					poml.material as 'materialID',
					SUM((po.quantityOrdered - po.quantityFilled) * poml.quantity) as 'quantity'
				FROM
					productionOrder po
				LEFT JOIN
					productionOrderSchedule pos
					ON po.productionOrderID = pos.productionOrder
				LEFT JOIN
					productionOrderMaterialLink poml
					ON po.productionOrderID = poml.productionOrder
				WHERE
					po.active = 1
				AND
					poml.material is not null
				AND
					(
						pourDate >= DATE_FORMAT(NOW(),?)
					OR
						pourDate is null
					)
				GROUP BY
					poml.material
			) temp
			ON temp.materialID = potml.material
		WHERE
			productionOrderTemplate = ?
		GROUP BY
			potml.material
		ORDER BY
			potml.quantity DESC
	";
	
	$values = array(
		'%Y-%m-%d',
		$_POST['overlay_order']
	);
	
	$result['queueWarning'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<div class='transaction_transaction_container'>
	
	<input type='hidden' id='overlay_productionOrder' value='<?php echo $_POST['overlay_order']; ?>'>

	<table id='queue_table'>
	
		<tr>
			<th>Precast Product</th>
			<td><?php echo $result['productionOrderTemplate'][0]['product'] ?></td>
		</tr>
	
		<tr>
			<th>Main Material</th>
			<td><?php echo $result['productionOrderTemplate'][0]['mainMaterial'] ?></td>
		</tr>
	
		<tr>
			<th>Form Quantity</th>
			<td><?php echo $result['productionOrderTemplate'][0]['formQuantity'] * $result['productionOrderTemplate'][0]['formPieces']; ?></td>
		</tr>
	
		<tr>
			<th>Quantity</th>
			<td>
				<input type='number' min='0' value='0' id='overlay_queue_quantity' />
			</td>
		</tr>
	
		<tr>
			<th>Date Required</th>
			<td>
				<input type='text' id='overlay_date' class='transaction_transaction_form_date overlay_date' />
				<button class='trigger'>Date</button>
			</td>
		</tr>
		
		<tr class='queueWarningLabel'>
			<th>Stock Warning</th>
			<td></td>
		</tr>
		
		<tr>
			<td class='fullwidth'>
				
				<table class='queueWarning'>
					
					<tr>
						<th>Material</th>
						<th>Non-Committed</th>
						<th>Need</th>
					</tr>
					
					<?php
					
						foreach( $result['queueWarning'] as $row )
						{
							echo "<tr>";
							echo "<td style='text-align: left'>" . $row['material'] . "</td>";
							
							if ( $row['stock'] > 1 )
							{
								echo "<td>" . $row['stock'] . " " . $row['measurePlural'] . "</td>";
							}
							else
							{
								echo "<td>" . $row['stock'] . " " . $row['measureSingular'] . "</td>";
							}
							
							echo "
								<td 
									data-needed='" . $row['quantity'] . "'
									data-stock='" . $row['stock'] . "'
									data-measureSingular='" . $row['measureSingular'] . "'
									data-measurePlural='" . $row['measurePlural'] . "'
								></td>";
							echo "</tr>";
						}
					
					?>
				</table>
				
			</td>
		</tr>
	
	</table>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}

	.transaction_transaction_container table {
		margin: 0 auto;
	}
	
	.transaction_transaction_container th {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container td {
		float: right;
		
		height: 20px;
		width: 200px;
		
		margin-bottom: 10px;
		margin-left: 20px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container td.fullwidth {
		float: left;
			
		width: 320px;
		
		margin-bottom: 10px;
		margin-left: 0;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container td select,
	.transaction_transaction_container td button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container td button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
		margin-top: 0px;
	}
	
	.trigger {
		margin-top: -10px;
	}
	
	.transaction_transaction_container input {
		width: 185px;
	}
	
	#transaction_transaction_form_warning,
	.transaction_transaction_form_date {
		width: 100px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_unit {
		width: 76px;
	}
	
	#transaction_transaction_form_unit.display {
		float: right;
		display: inline-block;
		
		width: 40px;
		
		line-height: 30px;
		text-align: right;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
	.queueWarning td,
	.queueWarning th {
		display: table-cell;
		float: none;
		width: 33%;
		text-align: right;
	}
	
	.queueWarning th {
		text-align: center;
	}
	
	.queueWarning {
		background: #fdc643;
	}
	
</style>

<script>

	if( typeof overlay_add_queue_validation != 'function' )
	{	
		
		var changeString = '#overlay_queue_quantity';
	
		$(document).on("keyup mouseup", changeString, function () {
			
			window.overlay_add_queue_validation();
			window.overlay_add_queue_warning();
			
		});
	
		window.overlay_add_queue_validation = function ()
		{
			
			if ( $("#overlay_queue_quantity").val() > 0 )
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_add_queue_warning = function ()
		{
			
			$(".queueWarning td[data-needed]").each( function () {
				
				var amount = $("#overlay_queue_quantity").val() * $(this).attr('data-needed');
				var needed = amount - $(this).attr('data-stock');
				
				if ( $(this).attr('data-stock') > amount )
				{
					$(this).parent().hide();
					$(this).parent().attr('data-hidden', true);
				}
				else
				{
					$(this).parent().show();
					$(this).parent().attr('data-hidden', false);
				}
				
				if ( needed > 1 )
				{
					$(this).html( needed + " " + $(this).attr('data-measurePlural') )
				}
				else
				{
					$(this).html( needed + " " + $(this).attr('data-measureSingular') )
				}
				
			});
			
			if ( $('.queueWarning tr[data-hidden=false]').length <= 0 )
			{
				$(".queueWarningLabel").hide();
				$(".queueWarning").hide();
			}
			else
			{
				$(".queueWarningLabel").show();
				$(".queueWarning").show();
			}
			
		}
	
	}
	
	window.overlay_add_queue_validation();
	window.overlay_add_queue_warning();

</script>