( function ($) {
	
	overlay_setup['add_queue'] = {
		"title": "Add to Queue",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/queue_add_product/screens/queue_add_product.php",
				"validation": "overlay_add_queue_validation",
				"toSend": {
					0: "#overlay_productionOrder",
					1: "#overlay_queue_quantity",
					2: "#overlay_date"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/queue_add_product/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#queue", function () {
			overlay_open = 'add_queue';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);