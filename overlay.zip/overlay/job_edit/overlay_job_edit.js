( function ($) {
	
	overlay_setup['job_edit'] = {
		"title": "Edit Job",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_job"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/job_edit/screens/job_edit.php",
				"validation": "overlay_edit_job_validation",
				"toSend": {
					0: "#overlay_job",
					1: "#edit_job_jobNumber",
					2: "#edit_job_customer",
					3: "#edit_job_location",
					4: "#edit_job_startDate",
					5: "#edit_job_deliverDate",
					6: "#edit_job_deliverVia",
					7: "#edit_job_description"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/job_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".job_edit", function () {
			overlay_open = 'job_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);