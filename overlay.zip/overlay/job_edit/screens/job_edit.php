<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Job
	
	$query = "
		SELECT
			*
		FROM
			job j
		LEFT JOIN
			companyLocationLink cll
			ON j.companyLocationLink = cll.companyLocationLinkID
		WHERE
			j.jobID = ?
	";
	
	$values = array(
		$_POST['overlay_job']
	);
	
	$result['job'] = dbquery( $query, $values );
	
	
	// Location
	
	if ( isset( $result['job'][0]['companyLocationLink'] ) )
	{
		
		$query = "
			SELECT
				l.locationID,
				l.location
			FROM
				companyLocationLink cll
			LEFT JOIN
				location l
				ON cll.location = l.locationID
			WHERE
				cll.company = ?
			ORDER BY
				l.location ASC
		";

		$values = array(
			$result['job'][0]['company']
		);

		$result['location'] = dbquery( $query, $values );
		
	}
	
	
	// Customer
	
	$query = "
		SELECT DISTINCT
			c.companyID,
			c.company
		FROM
			company c
		LEFT JOIN
			companyCompanyPropertyLink ccpl
			ON ccpl.company = c.companyID
		WHERE
			c.active = 1
		AND
			ccpl.companyProperty = 3
		ORDER BY
			c.company ASC
	";
	
	$values = array();
	
	$result['customer'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='edit_job_table'>
	
	<tr>
		<td class='left'>Job #</td>
		<td class='right'><input type='text' id="edit_job_jobNumber" value='<?php echo $result['job'][0]['jobNumber']; ?>'/></td>
	</tr>

	<tr>
		<td class='left'>Customer</td>
		<td class='right'>
			<select id="edit_job_customer">
				<option value='-1'>Choose...</option>
				<?php
					foreach ( $result['customer'] as $customer )
					{
					
						echo "<option value='{$customer['companyID']}'";
					
						if ( $customer['companyID'] == $result['job'][0]['company'] )
						{
							echo " selected ";
						}
					
						echo ">{$customer['company']}</option>";
					}
				?>
			</select>
		</td>
	</tr>

	<tr>
		<td class='left'>Location</td>
		<td class='right'>
			<select id='edit_job_location'>
				<option value='-1'>Choose...</option>
			
				<?php
			
				if ( isset( $result['job'][0]['companyLocationLink'] ) )
				{

					foreach ( $result['location'] as $location )
					{
						echo "<option value='{$location['locationID']}'";
					
						if ( $location['locationID'] == $result['job'][0]['location'] )
						{
							echo " selected ";
						}
					
						echo ">{$location['location']}</option>";
					
					}
				
				}
			
				?>
			</select>
		</td>
	</tr>

	<tr>
		<td class='left'>Start Date</td>
		<td class='right'>
			<button class='trigger' data-date="1">Date</button>
			<input type='text' id='edit_job_startDate' class='overlay_date' data-date="1" value='<?php 
			if ( ! empty ( $result['job'][0]['startDate'] ) )
			{
				echo mysql_to_date( $result['job'][0]['startDate']);
			}
		?>'/></td>
	</tr>

	<tr>
		<td class='left'>Deliver Date</td>
		<td class='right'>
			<button class='trigger' data-date="2">Date</button>
			<input type='text' id='edit_job_deliverDate' class='overlay_date' data-date="2" value='<?php 
			if ( ! empty ( $result['job'][0]['deliverDate'] ) )
			{
				echo mysql_to_date( $result['job'][0]['deliverDate']);
			}
		?>'/></td>
	</tr>

	<tr>
		<td class='left'>Deliver Via</td>
		<td class='right'><input type='text' id="edit_job_deliverVia" value='<?php echo $result['job'][0]['deliverVIA']; ?>'/></td>
	</tr>

	<tr>
		<td class='left'>Description</td>
		<td class='right'><textarea id='edit_job_description'><?php echo $result['job'][0]['description']; ?></textarea></td>
	</tr>

</table>

<style>

#edit_job_table {
	margin: 0 auto;
}

#edit_job_deliverVia[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

.overlay_date {
	width: 125px !important;
}

#edit_job_table button {
    width: 76px;
    background: #f1f1f1;
    border: 1px solid #ddd;
    border-radius: 3px;
    font-size: 12px;
    color: #555;
}

</style>

<script>

	$("#screen_overlay_content")
		.find(".transaction_transaction_form_date")
		.mask('00-00-0000', {
			reverse: true
		});

	$("#screen_overlay_content")
		.find("#transaction_transaction_form_quantity")
		.mask('999999999~99', {
			translation: {
				'~': {
					pattern: /[0-9|.]/
				}
			}
		});

	$("#screen_overlay_content")
		.find("#transaction_transaction_form_cost")
		.mask('000,000,000,000,000.00', {
			reverse: true
		});

	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
	
		var keyupString = '#edit_job_deliverVia, #edit_job_description';
		var changeString = ' #edit_job_customer, #edit_job_location, #edit_job_startDate, #edit_job_deliverDate';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", "#edit_job_customer", function () {
			
			if ( $(this).val() != "-1" )
			{
				request = $.ajax({
					url: "equipment/ajax/newJob_location.php",
					type: "post",
					data: "newJob_customer=" +
						$(this).val()
				}).done( function ( response, textStatus, jqXHR) {
					$("#edit_job_location")
						.html( response );
				});
			}
				
		});
	
		window.overlay_transaction_transaction_validation = function ()
		{
			overlay_valid(true);
		}
	
	}
	
	window.overlay_transaction_transaction_validation();

</script>