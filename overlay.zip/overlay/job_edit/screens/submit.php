<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE job j, companyLocationLink cll
		SET
			j.jobNumber = ?,
			j.companyLocationLink = cll.companyLocationLinkID,
			j.description = ?,
			j.startDate = ?,
			j.deliverDate = ?,
			j.deliverVIA = ?
		WHERE
			j.jobID = ?
		AND
			cll.company = ?
		AND
			cll.location = ?
	";
	
	$values = array(
		$_POST['edit_job_jobNumber'],
		$_POST['edit_job_description'],
		date_to_mysql( $_POST['edit_job_startDate'] ),
		date_to_mysql( $_POST['edit_job_deliverDate'] ),
		$_POST['edit_job_deliverVia'],
		$_POST['overlay_job'],
		$_POST['edit_job_customer'],
		$_POST['edit_job_location'],
	);
	
	$result['jobUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['jobUpdate'] )
	{
		echo "The job details were updated.";
	}
	else
	{
		echo "There was a problem updating the job.";
	}

?>