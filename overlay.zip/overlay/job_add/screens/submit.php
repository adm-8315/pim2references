<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		INSERT INTO
			job
			( jobNumber, companyLocationLink, description, startDate, deliverDate, deliverVIA )
			SELECT
				? as 'jobNumber',
				cll.companyLocationLinkID as 'companyLocationLink',
				? as 'description',
				? as 'startDate',
				? as 'deliverDate',
				? as 'deliverVIA'
			FROM
				companyLocationLink cll
			WHERE
				cll.company = ?
			AND
				cll.location = ?
	";
	
	$values = array(
		$_POST['add_job_jobNumber'],
		$_POST['add_job_description'],
		date_to_mysql( $_POST['add_job_startDate'] ),
		date_to_mysql( $_POST['add_job_deliverDate'] ),
		$_POST['add_job_deliverVia'],
		$_POST['add_job_customer'],
		$_POST['add_job_location']
	);
	
	$result['jobInsert'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['jobInsert'] )
	{
		echo "The job was created.";
	}
	else
	{
		echo "There was a problem creating the job.";
	}

?>