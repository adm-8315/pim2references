( function ($) {
	
	overlay_setup['job_add'] = {
		"title": "Add Job",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_job"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/job_add/screens/job_add.php",
				"validation": "overlay_add_job_validation",
				"toSend": {
					0: "#overlay_job",
					1: "#add_job_jobNumber",
					2: "#add_job_customer",
					3: "#add_job_location",
					4: "#add_job_startDate",
					5: "#add_job_deliverDate",
					6: "#add_job_deliverVia",
					7: "#add_job_description"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/job_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_job']", function () {
			overlay_open = 'job_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);