( function ($) {
	
	overlay_setup['schedule_strip'] = {
		"title": "Strip Schedule",
		"width": "600",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_date"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_strip/screens/schedule_strip.php",
				"validation": "overlay_schedule_strip_validation",
				"toSend": {
					0: "#overlay_productionOrder",
					1: "#overlay_delete",
					2: "#overlay_quantity",
					3: "#overlay_date"
				},
				"disableBack": true,
				"closeDelay": 0,
				"pageRefresh": true
			}, { 
				"id" : 3, 
				"url": "overlay/schedule_strip/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".schedule_trigger", function () {
			
			trigger = $(this)
			
			if ( $(trigger).parent().attr('class') == 'strip' )
			{
				
				if ( $("#overlay_date").length == 0 )
				{
					$("body").append( $('<input/>',{type:'hidden',id:'overlay_date'}) );
				}
			 
				$("#overlay_date").val( $(trigger).parent().parent().data('date') );
			
				overlay_open = 'schedule_strip';
				overlay_create( overlay_setup[overlay_open] );
				
			}
			
		});
		
	});
	
})(jQuery);