<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
		
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		INSERT 
			INTO 
				productionOrderSchedule
				( productionOrder, pourDate, quantity )
			VALUES
				( ?, ?, ? )
	";
	
	$values = array(
		$_POST['overlay_productionOrder'],
		date_to_mysql( $_POST['overlay_date'] ),
		1
	);
	
	$result['productionOrderSchedule'] = dbquery( $query, $values );

?>