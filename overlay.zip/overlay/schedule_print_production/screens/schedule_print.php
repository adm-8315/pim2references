<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */

	
	
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<label>Schedule</label>

	<table id='queue_table'>
	
		<tr>
			<th>Notes</th>
			<td><textarea id='overlay_schedule_print_notes'></textarea></td>
		</tr>
	
		<tr>
			<th>Maintenance</th>
			<td><textarea id='overlay_schedule_print_maintenance'></textarea></td>
		</tr>
	
	</table>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container label {
		margin-bottom: 10px;
		
		font-size: 20px;
		font-weight: 800;
	}

	.transaction_transaction_container table {
		margin: 0 auto;
	}
	
	.transaction_transaction_container th {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container td {
		float: right;
		
		width: 200px;
		
		margin-bottom: 10px;
		margin-left: 20px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container td select,
	.transaction_transaction_container td button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container td button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
		margin-top: 0px;
	}
	
	.trigger {
		margin-top: -10px;
	}
	
	
	
	.transaction_transaction_container table textarea {
		height: 125px;
		resize: none;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>

<script>

	if( typeof overlay_add_queue_validation != 'function' )
	{	
	
		window.overlay_edit_productionOrder_curing_validation = function ()
		{
			
			overlay_valid(true);
			
		}
		
		window.overlay_edit_productionOrder_curing_validation();
	
	}

</script>