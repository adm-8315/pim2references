( function ($) {
	
	overlay_setup['schedule_print_production'] = {
		"title": "Print",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_schedule_day"
				} 
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_print_production/screens/schedule_print.php",
				"validation": "overlay_add_schedule_validation",
				"toSend": {
					0: "#overlay_schedule_day",
					1: "#overlay_schedule_print_notes",
					2: "#overlay_schedule_print_maintenance"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"noAJAX": true
			}, { 
				"id" : 2, 
				"url": "print.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".print_production", function () {
			
			if ( $("#overlay_schedule_day").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_schedule_day'}) );
			}
			 
			$("#overlay_schedule_day").val( $(this).parent().parent().attr("data-date") );
			
			overlay_open = 'schedule_print_production';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);