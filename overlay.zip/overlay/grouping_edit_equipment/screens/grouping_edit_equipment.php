<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Job
	
	$query = "
		SELECT
			e.equipmentID,
			et.equipmentType,
			e.equipment,
			gel.grouping
		FROM
			equipment e
		LEFT JOIN
			groupingEquipmentLink gel
			ON gel.equipment = e.equipmentID
		LEFT JOIN
			equipmentType et
			ON e.equipmentType = et.equipmentTypeID
		ORDER BY
			IF(
				gel.grouping = ?,
				0,
				1
			),
			et.equipmentType,
			e.equipment
	";
	
	$values = array(
		$_POST['overlay_grouping']
	);
	
	$result['groupingEquipment'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>
<div id="edit_grouping_equipment_wrapper">
	
	<input type="hidden" id="edit_grouping_equipment_value">
	
	<table id='edit_grouping_equipment_table'>
	
			<tr>
				<th>Equipment Type</th>
				<th>Equipment</th>
				<th>In Grouping</th>
			</tr>

			<?php
			
			foreach( $result['groupingEquipment'] as $row )
			{
			
				echo "<tr>";
			
					echo "<td>" . $row['equipmentType'] . "</td>";
					echo "<td>" . $row['equipment'] . "</td>";
				
					if ( $row['grouping'] == $_POST['overlay_grouping'])
					{
						echo "<td><input type='checkbox' data-id='" . $row['equipmentID'] . "' checked='checked'></td>";
					}
					else
					{
						echo "<td><input type='checkbox' data-id='" . $row['equipmentID'] . "'></td>";
					}
				
			
				echo "</tr>";
			
			}
			
			?>

	</table>
</div>

<style>

#edit_grouping_equipment_wrapper {
	height: 300px;
	overflow-x: hidden;
	overflow-y: scroll;
}

#edit_grouping_equipment_table {
	margin: 0 auto;
}

#edit_grouping_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

#edit_grouping_equipment_table td {
	text-align: center;
}

</style>

<script>

	if( typeof overlay_edit_grouping_equipment_validation != 'function' )
	{
	
		var keyupString = '';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_grouping_equipment_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_grouping_equipment_validation();
		});
	
		window.overlay_edit_grouping_equipment_validation = function ()
		{
			overlay_valid(true);
		}
		
		window.overlay_edit_grouping_equipment_validation();
	
	}
	
	if( typeof overlay_edit_grouping_equipment_value != 'function' )
	{
	
		var changeString = 'input[type="checkbox"]';
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_grouping_equipment_value();
		});
	
		window.overlay_edit_grouping_equipment_value = function ()
		{
			
			var outString = "";
			
			$("input[type='checkbox']:checked").each( function () {
				outString += $(this).attr("data-id") + ",";
			});
			
			outString = outString.substring(0, outString.length - 1);
			
			$("#edit_grouping_equipment_value").val(outString);
			
		}
		
		window.overlay_edit_grouping_equipment_value();
	
	}

</script>