<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$equipment = explode( ",", $_POST['edit_grouping_equipment_value'] );
	
	
	/**
	 * MySQL
	 */
	
	// Remove
	
	$query = "
		DELETE FROM
			groupingEquipmentLink
		WHERE
			grouping = ?
	";
	
	$values = array(
		$_POST['overlay_grouping']
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	
	// Insert
	
	if ( count( $equipment ) > 0 )
	{
		
		$query = "
			INSERT INTO
				groupingEquipmentLink 
				( grouping, equipment )
				VALUES
		";
		
		$values = array();
	
		foreach ( $equipment as $key => $value )
		{
			$query .= "( ?, ? ),";
			$values[] = $_POST['overlay_grouping'];
			$values[] = $value;
		}
		
		$query = rtrim( $query, "," );
		
	}
	
	$result['insert'] = dbquery( $query, $values );
		
	
	/**
	 * Display
	 */
	
	echo "The grouping details were updated.";

?>