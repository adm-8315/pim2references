( function ($) {
	
	overlay_setup['grouping_equipment_edit'] = {
		"title": "Edit Grouping Equipment",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_grouping"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/grouping_edit_equipment/screens/grouping_edit_equipment.php",
				"validation": "overlay_edit_grouping_equipment_validation",
				"toSend": {
					0: "#overlay_grouping",
					1: "#edit_grouping_equipment_value"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/grouping_edit_equipment/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#equipment_edit", function () {
			overlay_open = 'grouping_equipment_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);