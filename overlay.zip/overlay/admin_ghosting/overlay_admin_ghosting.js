( function ($) {
	
	overlay_setup['admin_ghost'] = {
		"title": "Admin Ghosting",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/admin_ghosting/screens/admin_ghosting.php",
				"validation": "overlay_admin_ghost_validation",
				"toSend": {
					0: "#ghost_user"
				},
				"closeDelay": 0,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/admin_ghosting/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='ghost']", function () {
			overlay_open = 'admin_ghost';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);