<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Users
	
	$query = "
		SELECT
			userID,
			username
		FROM
			user u
		WHERE
			userID != ?
	";
	
	$values = array(
		$_SESSION['user_id']
	);
	
	$result['user'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<div id='overlay_admin_ghost_container'>

	<table id='overlay_admin_ghost_table'>

		<tr>
			<td class='left'>User</td>
			<td class='right'>
				<select id='ghost_user'>
					<option value='-1'>Choose...</option>
					<?php
				
						foreach ( $result['user'] as $row )
						{
							echo "<option value='{$row['userID']}'>{$row['username']}</option>";
						}
				
					?>
				</select>
			</td>
		</tr>

	</table>

</div>

<style>

#overlay_admin_ghost_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_admin_ghost_validation != 'function' )
	{
	
		var changeString = '#ghost_user';
	
		$(document).on("change", changeString, function () {
			window.overlay_admin_ghost_validation();
		});
	
		window.overlay_admin_ghost_validation = function ()
		{
			
			if (
				$("#ghost_user").val() != "-1"
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_admin_ghost_validation();
		
		<?php
			
		if( isset( $_SESSION['ghosting'] ) )
		{
			echo "overlay_update( overlay, true );";
		}
		
		?>
	
	}

</script>