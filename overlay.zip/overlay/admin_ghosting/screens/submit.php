<?php
	
	require_once( "../../../inc/session.php" );
	require_once( "../../../inc/permissions.php" );
	require_once( "../../../inc/permissions_vars.php" );
		
	
	if ( 
		isset( $permissions[1][1] ) &&
		! isset( $_SESSION['ghosting'] )
	) {
		$_SESSION['user_old'] = $_SESSION['user_id'];
		$_SESSION['user_id'] = $_POST['ghost_user'];
		$_SESSION['ghosting'] = 1;
	}
	else if ( isset( $_SESSION['ghosting'] ) )
	{
		$_SESSION['user_id'] = $_SESSION['user_old'];
		unset($GLOBALS['_SESSION']["ghosting"]);
		unset($GLOBALS['_SESSION']["user_old"]);
	}
		
?>