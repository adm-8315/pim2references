( function ($) {
	
	overlay_setup['preventative_maintenance'] = {
		"title": "Preventative Maintenance",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_equipment"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/equipment_preventative_maintenance/screens/preventative_maintenance.php",
				"validation": "overlay_preventative_maintenance_validation",
				"toSend": {
					0: "#overlay_equipment",
					1: "#preventative_maintenance_name",
					2: "#preventative_maintenance_type",
					3: "#preventative_maintenance_date",
					4: "#preventative_maintenance_value"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/equipment_preventative_maintenance/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".preventative_maintenance_trigger", function () {
			overlay_open = 'preventative_maintenance';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);