<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	
	if ( $_POST['preventative_maintenance_type'] == 'date' )
	{
		
		// Date Interval
		
		$query = "
			INSERT INTO
				preventativeMaintenance
				( equipment, preventativeMaintenanceType, preventativeMaintenance, valueInt, valueDate, completeDate )
				VALUES
				( ?, null, ?, null, ?, null)
		";
		
		$values = array(
			$_POST['overlay_equipment'],
			$_POST['preventative_maintenance_name'],
			date_to_mysql( $_POST['preventative_maintenance_date'] )
		);
		
	}
	else
	{
		
		$query = "
			INSERT INTO
				preventativeMaintenance
				( equipment, preventativeMaintenanceType, preventativeMaintenance, valueInt, valueDate, completeDate )
				VALUES
				( ?, ?, ?, ?, ?, null)
		";
		
		$values = array(
			$_POST['overlay_equipment'],
			$_POST['preventative_maintenance_type'],
			$_POST['preventative_maintenance_name'],
			$_POST['preventative_maintenance_value'],
			date_to_mysql( $_POST['preventative_maintenance_date'] )
		);
		
	}
	
	$result['preventativeMaintenance'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['preventativeMaintenance'] )
	{
		echo "The preventative maintenance interval was added.";
	}
	else
	{
		echo "There was a problem add the preventative maintenance interval.";
	}

?>