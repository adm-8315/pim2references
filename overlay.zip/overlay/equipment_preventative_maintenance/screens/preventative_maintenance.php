<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Type
	
	$query = "
		SELECT
			*
		FROM
			preventativeMaintenanceType pmt
	";
	
	$values = array();
	
	$result['type'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='preventative_maintenance_table'>
	
	<tr>
		<td class='left'>Name</td>
		<td class='right'><input type="text" id="preventative_maintenance_name"></td>
	</tr>

	<tr>
		<td class='left'>Type</td>
		<td class='right'>
			<select id='preventative_maintenance_type'>
				<option value='-1'>Choose...</option>
				<option value='date'>Date</option>
				<?php
					foreach ( $result['type'] as $row )
					{
						echo "<option value='{$row['preventativeMaintenanceTypeID']}'>{$row['preventativeMaintenanceType']}</option>";
					}
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Date</td>
		<td class='right'>
			<button class='trigger' data-date="1">Date</button><input type='text' id='preventative_maintenance_date' class='overlay_date' data-date="1" data-allowblank='true' readonly="readonly" value=''/>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Value</td>
		<td class='right'><input type="text" id="preventative_maintenance_value"></td>
	</tr>

</table>

<style>

	#preventative_maintenance_table {
		margin: 0 auto;
	}

	.left {
		font-weight: bold;
	}

	.ui-datepicker-trigger {
		display: none;
	}
	
	input[readonly] {
		background-color: #fff;
	}
	
	.overlay_date {
		width: 125px !important;
	}

</style>

<script>
	
	$("#screen_overlay_content")
		.find("#preventative_maintenance_value")
		.mask('00000000', {
			reverse: true
		});

	if( typeof overlay_preventative_maintenance_validation != 'function' )
	{
	
		var keyupString = '#preventative_maintenance_value, #preventative_maintenance_name, #preventative_maintenance_date';
		var changeString = '#preventative_maintenance_type, #preventative_maintenance_date';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_preventative_maintenance_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_preventative_maintenance_validation();
		});
		
		$(document).on("change", "#preventative_maintenance_type", function () {
			
			if ( $(this).val() == "date" )
			{
				$("#preventative_maintenance_value").val("").prop('disabled', true);
			}
			else
			{
				$("#preventative_maintenance_value").prop('disabled', false);
			}
			
		});
	
		window.overlay_preventative_maintenance_validation = function ()
		{
			
			if (
				$("#preventative_maintenance_name").val() != "" &&
				$("#preventative_maintenance_type").val() != "-1" &&
				(
					(
						$("#preventative_maintenance_type").val() == "date" &&
						$("#preventative_maintenance_date").val() != ""
					) ||
					(
						$("#preventative_maintenance_type").val() != "date" &&
						$.isNumeric( $("#preventative_maintenance_value").val() ) &&
						$("#preventative_maintenance_value").val() >= 0
					)
				)
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
	
		}
	
	}

</script>