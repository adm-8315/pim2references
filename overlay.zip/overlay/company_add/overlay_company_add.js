( function ($) {
	
	overlay_setup['company_add'] = {
		"title": "Add Company",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/company_add/screens/company_add.php",
				"validation": "overlay_company_add_validation",
				"toSend": {
					0: "#company"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/company_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_company']", function () {
			overlay_open = 'company_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);