<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Users
	
	$query = "
		SELECT
			company
		FROM
			company c
	";
	
	$values = array();
	
	$result['company'] = dbquery( $query, $values );
	
	
	
	/**
	 * Process
	 */
	
	$temp = array();
	
	foreach( $result['company'] as $row )
	{
		$temp[] = $row['company'];
	}
	
	$result['company'] = $temp;
	unset($temp);
	
	
	/**
	 * Display
	 */

?>

<div id='overlay_add_company_container'>

	<table id='company_add_table'>

		<tr>
			<td class='left'>Company</td>
			<td class='right'><input type='text' id='company' class='form_input' name='company' value='' placeholder='Company' /></td>
		</tr>

	</table>

</div>

<style>

#company_add_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>
	
	<?php 

		if ( isset( $result['company'] ) )
		{
			echo "var companyString = " . json_encode($result['company']) . "; ";
		}
		else
		{
			echo "var companyString = null; ";
		}
	
	?>

	if( typeof overlay_company_add_validation != 'function' )
	{
	
		var keyupString = '#company';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_company_add_validation();
		});
	
		window.overlay_company_add_validation = function ()
		{
			
			if (
				$("#company").val() != "" &&
				$.inArray( $("#company").val(), companyString ) < 0
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_company_add_validation();
	
	}

</script>