<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset($_POST['company']) && $_POST['company'] != '' )
	{	
		
		$query = "
			INSERT INTO
				company
			SET
				company = ?,
				active = 1
		";
		
		$values = array(
			$_POST['company']
		);
		
		$result['company'] = dbquery( $query, $values );
		
	}
	
	
	
	
	
	/**
	 * Display
	 */
	
	if ( $result['company'] )
	{
		echo $_POST['company'] . " was added successfully.";
	}
	else
	{
		echo "There was a problem adding the company.";
	}

?>