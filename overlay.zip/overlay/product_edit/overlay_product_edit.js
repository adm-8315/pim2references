( function ($) {
	
	overlay_setup['product_edit'] = {
		"title": "Product Edit",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/product_edit/screens/product_edit.php",
				"toSend": {
					0: "#overlay_material",
					1: "#transaction_transaction_consumer",
					2: "#transaction_transaction_form_name",
					3: "#transaction_transaction_form",
					4: "#transaction_transaction_productType",
					5: "#transaction_transaction_measure"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/product_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#material_edit", function () {
			overlay_open = 'product_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);