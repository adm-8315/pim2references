<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Customer
	
	$query = "
		SELECT
			cll.companyLocationLinkID as 'companyID',
			CONCAT( c.company, ' - ', l.location) as 'company'
		FROM
			companyLocationLink cll
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		WHERE
			c.active = 1
		ORDER BY
			c.company
	";
	
	$values = array();
	
	$result['consumer'] = dbquery( $query, $values );
	
	
	// Product
	
	$query = "
		SELECT
			p.product as 'material',
			fpl.form,
			cll.companyLocationLinkID as 'consumer',
			p.productType,
			p.measure
		FROM
			product p
		LEFT JOIN
			formProductLink fpl
			ON p.productID = fpl.product
		LEFT JOIN
			productConsumerLink pcl
			ON p.productID = pcl.product
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		WHERE
			p.productID = ?
	";
	
	$values = array(
		$_POST['overlay_material']
	);
	
	$result['material'] = dbquery( $query, $values );
	
	
	// Form
	
	$query = "
		SELECT
			*
		FROM
			form f
	";
	
	$values = array();
	
	$result['form'] = dbquery( $query, $values );
	
	
	// Product Type
	
	$query = "
		SELECT
			*
		FROM
			productType pt
	";
	
	$values = array();
	
	$result['productType'] = dbquery( $query, $values );
	
	
	// Measure
	
	$query = "
		SELECT
			*
		FROM
			measure me
	";
	
	$values = array();
	
	$result['measure'] = dbquery( $query, $values );

?>
<div class='transaction_transaction_container'>
	
	<div id="transaction_transaction_form_materialDisplay" data-material="<?php echo $_POST['overlay_material']; ?>"><?php echo $result['material'][0]['material']; ?></div>
	
	<div id="transaction_transaction_container">
		
		<table>
			<tr>
				<td>Consumer</td>
				<td class='field'>
					<select id='transaction_transaction_consumer'>
						<option value='-1'>Choose...</option>
						<?php
							
						foreach ( $result['consumer'] as $row )
						{
							
							if ( 
								! empty( $result['material'][0]['consumer'] ) &&
								$row['companyID'] == $result['material'][0]['consumer']
							) {
								echo "<option selected='selected' value='{$row['companyID']}'>{$row['company']}</option>";
							}
							else
							{
								echo "<option value='{$row['companyID']}'>{$row['company']}</option>";
							}
							
						}
							
						?>
					</select>
				</td>
			</tr>
			
			<tr>
				<td>Name</td>
				<td class='field'>
					<input type='text' id ="transaction_transaction_form_name" value="<?php echo htmlspecialchars( $result['material'][0]['material'] ); ?>" />
				</td>
			</tr>
			
			<tr>
				<td>Product Type</td>
				<td class='field'>
					<select id='transaction_transaction_productType'>
						<option value='-1'>Choose...</option>
						<?php
							
						foreach ( $result['productType'] as $row )
						{
							
							if ( 
								$row['productTypeID'] == $result['material'][0]['productType']
							) {
								echo "<option selected='selected' value='{$row['productTypeID']}'>{$row['productType']}</option>";
							}
							else
							{
								echo "<option value='{$row['productTypeID']}'>{$row['productType']}</option>";
							}
							
						}
							
						?>
					</select>
				</td>
			</tr>
			
			<tr>
				<td>Measure</td>
				<td class='field'>
					<select id='transaction_transaction_measure'>
						<option value='-1'>Choose...</option>
						<?php
							
						foreach ( $result['measure'] as $row )
						{
							
							if (
								$row['measureID'] == $result['material'][0]['measure']
							) {
								echo "<option selected='selected' value='{$row['measureID']}'>{$row['measureSingular']}, {$row['measurePlural']}</option>";
							}
							else
							{
								echo "<option value='{$row['measureID']}'>{$row['measureSingular']}, {$row['measurePlural']}</option>";
							}
							
						}
							
						?>
					</select>
				</td>
			</tr>
		
			<tr>
				<td>Form</td>
				<td class='field'>
					<select id='transaction_transaction_form'>
						<option value='-1'>Choose...</option>
						<?php
							
						foreach ( $result['form'] as $row )
						{
							
							if ( 
								! empty( $result['material'][0]['form'] ) &&
								$row['formID'] == $result['material'][0]['form']
							) {
								echo "<option selected='selected' value='{$row['formID']}'>{$row['formTag']}</option>";
							}
							else
							{
								echo "<option value='{$row['formID']}'>{$row['formTag']}</option>";
							}
							
						}
							
						?>
					</select>
				</td>
			</tr>
		</table>
	
	</div>

</div>

<script>
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		var keyupString = '#transaction_transaction_form_name';
		var changeString = '#transaction_transaction_consumer, #transaction_transaction_form, #transaction_transaction_productType, #transaction_transaction_measure';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			// Validation Final	
			if (
				(
					$("#transaction_transaction_form").val() != "<?php echo addslashes( $result['material'][0]['form'] ); ?>" ||
					$("#transaction_transaction_consumer").val() != "<?php echo addslashes( $result['material'][0]['consumer'] ); ?>" ||
					$("#transaction_transaction_productType").val() != "<?php echo addslashes( $result['material'][0]['productType'] ); ?>" ||
					$("#transaction_transaction_measure").val() != "<?php echo addslashes( $result['material'][0]['measure'] ); ?>" ||
					$("#transaction_transaction_form_name").val() != "<?php echo addslashes( $result['material'][0]['material'] ); ?>"
				) &&
				$("#transaction_transaction_form_name").val() != ""
			) {
			    overlay_valid(true);
			} else {
			    overlay_valid(false);
			}

		}
		
	}


</script>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container #transaction_transaction_container {
		width: 300px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 35px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container div.field {
		float: right;
		
		height: 20px;
		width: 160px;
		
		margin-bottom: 10px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
	}
	
	#transaction_transaction_form_name {
		width: 170px !important;
		
		margin-right: 10px;
	}

	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>

