<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Remove Links
	
	$query = '
		DELETE FROM
			formProductLink
		WHERE
			product = ?
	';
	
	$values = array(
		intval( $_POST['overlay_material'] )
	);
	
	$result['remove'] = dbquery( $query, $values );
	
	
	$query = '
		DELETE FROM
			productConsumerLink
		WHERE
			product = ?
	';
	
	$values = array(
		intval( $_POST['overlay_material'] )
	);
	
	$result['remove'] = dbquery( $query, $values );
	
	
	// Product Update
	
	$query = "
		UPDATE
			product
		SET
			product = ?,
			productType = ?,
			measure = ?
		WHERE
			productID = ?
	";
	
	$values = array(
		$_POST['transaction_transaction_form_name'],
		$_POST['transaction_transaction_productType'],
		$_POST['transaction_transaction_measure'],
		intval( $_POST['overlay_material'] )
	);
	
	$result['materialUpdate'] = dbquery( $query, $values );
	
	
	// Insert Values
	
	$query = '
		INSERT INTO
			formProductLink
			( form, product )
		VALUES
			( ?, ? )
	';
	
	$values = array(
		$_POST['transaction_transaction_form'],
		intval( $_POST['overlay_material'] )
	);
	
	$result['insert'] = dbquery( $query, $values );
		
	
	$query = '
		INSERT INTO
			productConsumerLink
			( product, companyLocationLink )
		VALUES
			( ?, ? )
	';

	$values = array(
		intval( $_POST['overlay_material'] ),
		$_POST['transaction_transaction_consumer']
	);

	$result['insert'] = dbquery( $query, $values );
		
		
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Product Updated</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
		
		margin-top: 30px;
	}
</style>