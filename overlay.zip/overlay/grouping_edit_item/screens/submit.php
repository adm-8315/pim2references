<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$item = explode( ",", $_POST['edit_grouping_item_value'] );
	
	
	/**
	 * MySQL
	 */
	
	// Remove
	
	$query = "
		DELETE FROM
			groupingItemLink
		WHERE
			grouping = ?
	";
	
	$values = array(
		$_POST['overlay_grouping']
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	
	// Insert
	
	if ( count( $item ) > 0 )
	{
		
		$query = "
			INSERT INTO
				groupingItemLink 
				( grouping, item, value )
				VALUES
		";
		
		$values = array();
	
		foreach ( $item as $row )
		{
			$row = explode( "=", $row );
			$query .= "( ?, ?, ? ),";
			$values[] = $_POST['overlay_grouping'];
			$values[] = $row[0];
			$values[] = $row[1];
		}
		
		$query = rtrim( $query, "," );
		
	}
	
	$result['insert'] = dbquery( $query, $values );
		
	
	/**
	 * Display
	 */
	
	echo "The grouping details were updated.";

?>