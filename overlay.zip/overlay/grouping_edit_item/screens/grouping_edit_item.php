<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Job
	
	$query = "
		SELECT
			i.itemID,
			it.itemType,
			i.item,
			gil.grouping,
			gil.value
		FROM
			item i
		LEFT JOIN
			groupingItemLink gil
			ON gil.item = i.itemID
		LEFT JOIN
			itemType it
			ON i.itemType = it.itemTypeID
		ORDER BY
			IF(
				gil.grouping = ?,
				0,
				1
			),
			it.itemType,
			i.item
	";
	
	$values = array(
		$_POST['overlay_grouping']
	);
	
	$result['groupingItem'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>
<div id="edit_grouping_item_wrapper">
	
	<input type="hidden" id="edit_grouping_item_value">
	
	<table id='edit_grouping_item_table'>
	
			<tr>
				<th>Item Type</th>
				<th>Item</th>
				<th>In Grouping</th>
			</tr>

			<?php
			
			foreach( $result['groupingItem'] as $row )
			{
			
				echo "<tr>";
			
					echo "<td>" . $row['itemType'] . "</td>";
					echo "<td><div class='item'>" . $row['item'] . "</div></td>";
				
					if ( $row['grouping'] == $_POST['overlay_grouping'])
					{
						echo "<td><input type='text' class='item_value' data-id='" . $row['itemID'] . "' value='" . $row['value'] . "'></td>";
					}
					else
					{
						echo "<td><input type='text' class='item_value' data-id='" . $row['itemID'] . "' value='0'></td>";
					}
				
			
				echo "</tr>";
			
			}
			
			?>

	</table>
</div>

<style>

#edit_grouping_item_wrapper {
	height: 300px;
	overflow-x: hidden;
	overflow-y: scroll;
}

#edit_grouping_item_table {
	margin: 0 auto;
}

#edit_grouping_name[value=""] {
	display: block !important;
}

.left {
	font-weight: bold;
}

.item {
	width: 350px;
	overflow: hidden;
}

.item_value {
	width: 50px;
}

</style>

<script>

	$(".item_value")
		.mask("000000");
		
	overlay_valid(true);
	
	if( typeof overlay_edit_grouping_item_value != 'function' )
	{
	
		var keyupString = 'input[type="text"]';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_grouping_item_value();
		});
	
		window.overlay_edit_grouping_item_value = function ()
		{
			
			var outString = "";
			
			$("input[type='text']").each( function () {
				if ( $(this).val() > 0 )
				{	
					outString += $(this).attr("data-id") + "=" + $(this).val() + ",";
				}
			});
			
			outString = outString.substring(0, outString.length - 1);
			
			$("#edit_grouping_item_value").val(outString);
			
		}
		
		window.overlay_edit_grouping_item_value();
	
	}

</script>