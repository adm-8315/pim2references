( function ($) {
	
	overlay_setup['grouping_item_edit'] = {
		"title": "Edit Grouping Equipment",
		"width": "600",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_grouping"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/grouping_edit_item/screens/grouping_edit_item.php",
				"validation": "overlay_edit_grouping_item_validation",
				"toSend": {
					0: "#overlay_grouping",
					1: "#edit_grouping_item_value"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/grouping_edit_item/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#item_edit", function () {
			overlay_open = 'grouping_item_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);