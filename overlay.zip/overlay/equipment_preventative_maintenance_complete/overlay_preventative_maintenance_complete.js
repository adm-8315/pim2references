( function ($) {
	
	overlay_setup['preventative_maintenance_complete'] = {
		"title": "Preventative Maintenance",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_equipment",
					1: "#overlay_preventative_maintenance_id"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/equipment_preventative_maintenance_complete/screens/preventative_maintenance_complete.php",
				"validation": "overlay_preventative_maintenance_complete_validation",
				"toSend": {
					0: "#overlay_preventative_maintenance_id",
					1: "#preventative_maintenance_complete_date"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/equipment_preventative_maintenance_complete/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".preventativeMaintenanceRow", function () {
			
			$("#overlay_preventative_maintenance_id").val( $(this).attr("data-id") );
			
			overlay_open = 'preventative_maintenance_complete';
			overlay_create( overlay_setup[overlay_open] );
			
		});
		
	});
	
})(jQuery);