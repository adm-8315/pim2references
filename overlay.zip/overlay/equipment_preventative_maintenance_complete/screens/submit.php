<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			preventativeMaintenance
		SET
			completeDate = ?
		WHERE
			preventativeMaintenanceID = ?
	";
	
	$values = array(
		$_POST['preventative_maintenance_complete_date'],
		$_POST['overlay_preventative_maintenance_id']
	);
	
	$result['preventativeMaintenanceUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['preventativeMaintenanceUpdate'] )
	{
		echo "The preventative maintenance interval was completed.";
	}
	else
	{
		echo "There was a problem completeing the preventative maintenance interval.";
	}

?>