<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Type
	
	$query = "
		SELECT
			pm.*,
			pmt.preventativeMaintenanceType as 'pmt'
		FROM
			preventativeMaintenance pm
		LEFT JOIN
			preventativeMaintenanceType pmt
			ON pm.preventativeMaintenanceType = pmt.preventativeMaintenanceTypeID
		WHERE
			preventativeMaintenanceID = ?
	";
	
	$values = array(
		$_POST['overlay_preventative_maintenance_id']
	);
	
	$result['preventativeMaintenance'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='preventative_maintenance_complete_table'>
	
	<tr>
		<td class='left'>Name</td>
		<td class='right'>
			<?php echo $result['preventativeMaintenance'][0]['preventativeMaintenance']; ?>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Value</td>
		<td class='right'>
			<?php echo $result['preventativeMaintenance'][0]['valueInt'] . "&nbsp;" . $result['preventativeMaintenance'][0]['pmt'] ; ?>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Date</td>
		<td class='right'>
			<?php echo mysql_to_date( $result['preventativeMaintenance'][0]['valueDate'] ); ?>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Date</td>
		<td class='right'>
			<button class='trigger' data-date="1">Date</button><input type='text' id='preventative_maintenance_complete_date' class='overlay_date' data-date="1" data-allowblank='true' readonly="readonly" value=''/>
		</td>
	</tr>

</table>

<style>

	#preventative_maintenance_complete_table {
		margin: 0 auto;
	}

	.left {
		font-weight: bold;
	}

	.ui-datepicker-trigger {
		display: none;
	}
	
	input[readonly] {
		background-color: #fff;
	}
	
	.overlay_date {
		width: 125px !important;
	}
	
	.trigger {
		margin-left: 10px;
	}

</style>

<script>

	if( typeof overlay_preventative_maintenance_complete_validation != 'function' )
	{
	
		var keyupString = '#preventative_maintenance_complete_date';
		var changeString = '#preventative_maintenance_complete_date';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_preventative_maintenance_complete_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_preventative_maintenance_complete_validation();
		});
	
		window.overlay_preventative_maintenance_complete_validation = function ()
		{
			
			if ( $("#preventative_maintenance_complete_date").val() != "" ) 
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
	
		}
	
	}

</script>