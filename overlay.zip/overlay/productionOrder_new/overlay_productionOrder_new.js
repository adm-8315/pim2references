( function ($) {
	
	overlay_setup['order_new'] = {
		"title": "New Production Order",
		"width": "850",
		"height": "550",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_product.php",
				"validation": "overlay_new_productionOrder_validation",
				"toSend": {
					0: "#new_productionOrder_product"
				}
			}, { 
				"id" : 2, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_material.php",
				"validation": "overlay_new_productionOrder_material_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values"
				}
			}, { 
				"id" : 3, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_qc.php",
				"validation": "overlay_new_productionOrder_qc_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec"
				}
			}, { 
				"id" : 4, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_curing.php",
				"validation": "overlay_new_productionOrder_curing_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec",
					5: "#productionOrder_curing_values"
				}
			}, { 
				"id" : 5, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_drying.php",
				"validation": "overlay_new_productionOrder_drying_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#productionOrder_material_values",
					2: "#new_productionOrder_taps",
					3: "#new_productionOrder_lowerSpec",
					4: "#new_productionOrder_upperSpec",
					5: "#productionOrder_curing_values",
					6: "#new_productionOrder_pattern"
				}
			}, { 
				"id" : 6, 
				"url": "overlay/productionOrder_new/screens/productionOrder_new_packaging.php",
				"validation": "overlay_new_productionOrder_packaging_validation",
				"toSend": {
					0: "#new_productionOrder_product",
					1: "#overlay_date",
					2: "#productionOrder_material_values",
					3: "#new_productionOrder_taps",
					4: "#new_productionOrder_lowerSpec",
					5: "#new_productionOrder_upperSpec",
					6: "#productionOrder_curing_values",
					7: "#new_productionOrder_pattern",
					8: "#new_productionOrder_packaging"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 7, 
				"url": "overlay/productionOrder_new/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_productionOrder']", function () {
			overlay_open = 'order_new';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);