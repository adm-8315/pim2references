<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/dev_tools/print_dev.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	//print_dev( $_POST );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$materials = json_decode( $_POST['productionOrder_material_values'], true );
	$curing = explode( ",", $_POST['productionOrder_curing_values'] );
	
	if ( ! empty( $_POST['overlay_date'] ) )
	{
		$dateToSend = date_to_mysql($_POST['overlay_date']);
	}
	else
	{
		$dateToSend = null;
	}
	
	
	
	/**
	 * MySQL
	 */
	
	// Order
	
	$query = "
		INSERT INTO 
			productionOrder
			( product, quantityOrdered, fillDate, notes, taps, lowerSpec, upperSpec, furnacePattern, user )
		VALUES
			( ?, ?, ?, ?, ?, ?, ?, ?, ? );
	";
	
	$values = array(
		$_POST['new_productionOrder_product'],
		1,
		$dateToSend,
		$materials['notes'],
		$_POST['new_productionOrder_taps'],
		$_POST['new_productionOrder_lowerSpec'],
		$_POST['new_productionOrder_upperSpec'],
		$_POST['new_productionOrder_pattern'],
		$_SESSION['user_id']
	);
	
	$result['productionOrder'] = dbquery( $query, $values );
	
	
	// Options
	
	$values = array();
	
	$query = "
		INSERT INTO 
			productionOrderProductionOrderOptionLink 
			( productionOrder, productionOrderOption )
		VALUES
	";
	
	$query .= "( ?, ? ),";
	$values[] = $result['productionOrder'];
	$values[] = $_POST['new_productionOrder_packaging'];
	
	foreach ( $curing as $value )
	{
		
		if ( ! empty( $value ) )
		{
			$query .= "( ?, ? ),";
			$values[] = $result['productionOrder'];
			$values[] = $value;
		}
		
	}
	
	$query = substr( $query, 0, -1 );
	
	$result['productionOrderOptions'] = dbquery( $query, $values );
	
	
	// Materials
	
	$values = array();
	
	$query = "
		INSERT INTO 
			productionOrderMaterialLink 
			( productionOrder, material, quantity, water, mixTime, vibrationType, vibrationTime )
		VALUES
	";
	
	foreach ( $materials as $key => $row )
	{
		
		if ( 
			$key == "notes" || 
			$row['material'] == '-1'
		) {
			continue;
		}
		
		$query .= "( ?, ?, ?, ?, ?, ?, ? ),";
		$values[] = $result['productionOrder'];
		$values[] = $row['material'];
		$values[] = $row['quantity'];
		$values[] = $row['water'];
		$values[] = $row['mix'];
		$values[] = $row['vibType'];
		$values[] = $row['vibTime'];
		
	}
	
	$query = substr( $query, 0, -1 );
	
	$result['productionOrderMaterials'] = dbquery( $query, $values );
	
	echo "Order Created";
	
?>