<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		SELECT DISTINCT
			c.companyID,
			c.company
		FROM
			company c
		LEFT JOIN
			companyCompanyPropertyLink cpl
			ON c.companyID = cpl.company
		WHERE
			c.active = 1
		AND
			cpl.companyProperty = 3
		ORDER BY
			c.company ASC
	";
	
	$values = array();
	
	$result['customer'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<div id='productionOrderTemplate_new_container'>
	
	<div>
	
		<div>
			<label>Customer</label>
			<div><select id='new_productionOrder_customer'><option value='-1'>Choose...</option><?php
				
				foreach ( $result['customer'] as $row )
				{
					echo "<option value='{$row['companyID']}'>{$row['company']}</option>";
				}
				
			?></select></div>
		</div>
	
		<div>
			<label>Location</label>
			<div><select id='new_productionOrder_location'><option value='-1'>Choose...</option></select></div>
		</div>
	
		<div>
			<label>Product</label>
			<div><select id='new_productionOrder_product'><option value='-1'>Choose...</option></select></div>
		</div>
		
		<div>
			<label>Date Required</label>
			<div>
				<input type='text' id='overlay_date' class='transaction_transaction_form_date overlay_date' data-allowblank='true' value='' />
				<button class='trigger'>Date</button>
			</div>
		</div>
	
	<div>
	
</div>

<style>

#productionOrderTemplate_new_container {
	text-align: center;
}

#productionOrderTemplate_new_container label {
	margin-bottom: 10px;
	
	font-size: 20px;
	font-weight: 800;

}

#overlay_date {
	width: 155px;
}

.trigger {
	vertical-align: top;
	height: 30px;
	float: none;
}

</style>

<script>

	if( typeof overlay_new_productionOrder_qc_validation != 'function' )
	{
	
		var changeString = '#new_productionOrder_customer, #new_productionOrder_product';
	
		$(document).on("change", changeString, function () {
			window.overlay_new_productionOrder_validation();
		});
		
		$(document).on("change", "#new_productionOrder_customer", function () {
			window.overlay_new_productionOrder_customer_location();
			window.overlay_new_productionOrder_customer_product();
		});
		
		window.overlay_new_productionOrder_customer_location = function ()
		{
			
			$("#new_productionOrder_location option").not("[value='-1']").remove();
			
			if ( $("#new_productionOrder_customer").val() != '-1' )
			{
				
				request = $.ajax({
					url: "ajax/new_productionOrder_location.php",
					type: "post",
					data: "new_productionOrder_customer=" + $("#new_productionOrder_customer").val()
				}).done( function( response, textStatus, jqXHR ) {
					$("#new_productionOrder_location").append( response );
				});
				
			}
			
		}
		
		window.overlay_new_productionOrder_customer_product = function ()
		{
			
			$("#new_productionOrder_product option").not("[value='-1']").remove();
			
			if ( $("#new_productionOrder_customer").val() != '-1' )
			{
				
				request = $.ajax({
					url: "ajax/new_productionOrder_product.php",
					type: "post",
					data: "new_productionOrder_customer=" + $("#new_productionOrder_customer").val()
				}).done( function( response, textStatus, jqXHR ) {
					$("#new_productionOrder_product").append( response );
				});
				
			}
			
		}
	
		window.overlay_new_productionOrder_validation = function ()
		{
			
			if (
				$("#new_productionOrder_customer").val() != "-1" &&
				$("#new_productionOrder_product").val() != "-1"
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
	
	}
	
	window.overlay_new_productionOrder_validation();

</script>