<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
		
	/**
	 * MySQL
	 */

	
	if ( $_POST['overlay_remove'] == 1 )
	{
		
		// Remove Schedule Entry
		
		$query = "
			DELETE FROM
				productionOrderSchedule
			WHERE
				productionOrder = ?
			AND
				pourDate = ?
		";
		
		$values = array(
			$_POST['overlay_productionOrder'],
			$_POST['overlay_remove_date']
		);
		
		$result['removeProductionOrder'] = dbquery( $query, $values );
		
		
		// Update Pour String
		
		$query = "
			SELECT
				*
			FROM
				productionOrderScheduleBatching
			WHERE
				pourDate = ?
		";
		
		$values = array(
			$_POST['overlay_remove_date']
		);
		
		$result['batchingString'] = dbquery( $query, $values );
		
		if ( ! empty( $result['batchingString'] ) )
		{
			
			$temp = json_decode( $result['batchingString'][0]['batchingString'], true );
			$adjustBatchNumber = 0;
			
			foreach ( $temp as $key => $batch )
			{
				if ( $adjustBatchNumber > 0 )
				{
					$temp[$key - $adjustBatchNumber] = $temp[$key];
					unset( $temp[$key] );
				}
				
				if ( isset( $batch['productionOrder'][ $_POST['overlay_productionOrder'] ] ) )
				{
					unset( $temp[$key]['productionOrder'][ $_POST['overlay_productionOrder'] ] );
					unset( $temp[$key]['batching'] );
				}
				
				if ( empty( $temp[$key]['productionOrder'] ) )
				{
					$adjustBatchNumber++;
					unset( $temp[$key] );
				}
			}
			
			if ( empty( $temp ) )
			{
				
				$query = "
					DELETE FROM
						productionOrderScheduleBatching
					WHERE
						pourDate = ?
				";
			
				$values = array(
					$_POST['overlay_remove_date']
				);
			
				$result['delete'] = dbquery( $query, $values );
				
			}
			else
			{
			
				$updateString = json_encode( $temp );
			
			
				$query = "
					UPDATE
						productionOrderScheduleBatching
					SET
						batchingString = ?
					WHERE
						pourDate = ?
				";
			
				$values = array(
					$updateString,
					$_POST['overlay_remove_date']
				);
			
				$result['update'] = dbquery( $query, $values );
			
			}
			
			
		}
		
	}
	else
	{
		
		// Schedule 
	
		$query = "
			UPDATE
				productionOrderSchedule
			SET
				pourDate = ?
			WHERE
				productionOrder = ?
		";
	
		$values = array(
			date_to_mysql( $_POST['overlay_date'] ),
			$_POST['overlay_productionOrder']
		);
	
		$result['productionOrderSchedule'] = dbquery( $query, $values );
		
	}

?>