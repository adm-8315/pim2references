<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			p.product,
			m.material as 'mainMaterial',
			SUM(temp.quantityOrdered) - SUM(temp.quantityFilled) as 'needToFill'
		FROM
			(
				SELECT
					temp.productionOrderID,
					temp.product,
					temp.quantityOrdered,
					temp.quantityFilled,
					temp.concatStringTemplate,
					temp.material,
					temp.quantity,
					GROUP_CONCAT( concatString ORDER BY temp.material ASC SEPARATOR '&' ) as 'concatStringTarget'
				FROM
					(
						SELECT
							temp.concatStringTemplate,
							po.productionOrderID,
							poml.material,
							poml.quantity,
							po.quantityFilled,
							po.quantityOrdered,
							po.product,
							IF (
								poml.water is not null,
								CONCAT( poml.material, '=', poml.water ),
								poml.material
							) as 'concatString'
						FROM
							(
								SELECT
									temp.product,
									GROUP_CONCAT( concatString ORDER BY temp.material ASC SEPARATOR '&' ) as 'concatStringTemplate'
								FROM
									(
										SELECT
											po.productionOrderID,
											po.product,
											poml.material,
											IF (
												poml.water is not null,
												CONCAT( poml.material, '=', poml.water ),
												poml.material
											) as 'concatString'
										FROM
											productionOrder po
										LEFT JOIN
											productionOrderMaterialLink poml
											ON po.productionOrderID = poml.productionOrder
										WHERE
											po.productionOrderID = ?
									) as temp
								GROUP BY
									temp.productionOrderID
							) as temp
						LEFT JOIN
							productionOrder po
							ON po.product = temp.product
							AND po.active = 1
						LEFT JOIN
							productionOrderMaterialLink poml
							ON po.productionOrderID = poml.productionOrder
						WHERE
							po.quantityFilled < po.quantityOrdered
						AND
							po.active = 1
						ORDER BY
							poml.quantity DESC
					) as temp
				GROUP BY
					temp.productionOrderID
			) as temp
			LEFT JOIN
				product p
				ON p.productID = temp.product
			LEFT JOIN
				material m
				ON m.materialID = temp.material
		WHERE
			concatStringTemplate = concatStringTarget
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['productionOrderTemplate'] = dbquery( $query, $values );
	
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<input type='hidden' id='overlay_productionOrder' value='<?php echo $_POST['overlay_order']; ?>'>
	<input type='hidden' id='overlay_remove' value='0'>
	<input type='hidden' id='overlay_remove_date' value='<?php echo $_POST['overlay_pourDate'] ?>'>

	<table id='queue_table'>
	
		<tr>
			<th>Precast Product</th>
			<td><?php echo $result['productionOrderTemplate'][0]['product'] ?></td>
		</tr>
	
		<tr>
			<th>Main Material</th>
			<td><?php echo $result['productionOrderTemplate'][0]['mainMaterial'] ?></td>
		</tr>
	
		<tr>
			<th>Date</th>
			<td>
				<input type='text' id='overlay_date' class='transaction_transaction_form_date overlay_date' />
				<button class='trigger'>Date</button>
			</td>
		</tr>
	
	</table>
	
	<div id='transaction_removeOrder'><div>Remove Order</div></div>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}

	.transaction_transaction_container table {
		margin: 0 auto;
	}
	
	.transaction_transaction_container th {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container td {
		float: right;
		
		height: 20px;
		width: 200px;
		
		margin-bottom: 10px;
		margin-left: 20px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container td select,
	.transaction_transaction_container td button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container td button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
		margin-top: 0px;
	}
	
	.trigger {
		margin-top: -10px;
	}
	
	#transaction_transaction_form_adjust,
	#transaction_transaction_form_warning,
	.transaction_transaction_form_date {
		width: 100px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_unit {
		width: 76px;
	}
	
	#transaction_transaction_form_unit.display {
		float: right;
		display: inline-block;
		
		width: 40px;
		
		line-height: 30px;
		text-align: right;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
	#transaction_removeOrder {
		position: absolute;
		
		bottom: -65px;
		left: 0;
		right: 0;
		
		text-align: center;
		
		cursor: pointer;
	}
	
	#transaction_removeOrder div {
		position: relative;
		
		left: 50%;
		
		margin-left: -75px;
		
		width: 150px;
		height: 35px;
		
		background: #e2e2e2;
		
		border-radius: 4px;
		border: 1px solid #bbb;
		
		line-height: 35px;
	}
	
	#transaction_removeOrder div:hover {
		background: #d3d3d3;

		border: 1px solid #aaa;
	}
	
</style>

<script>

	if( typeof overlay_edit_schedule_validation != 'function' )
	{	
	
		window.overlay_edit_schedule_validation = function ()
		{
			
			overlay_valid(true);
			
		}
		
		window.overlay_edit_schedule_validation();
	
	}

</script>