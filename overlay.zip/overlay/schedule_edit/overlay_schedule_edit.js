( function ($) {
	
	overlay_setup['edit_schedule'] = {
		"title": "Edit Schedule",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_order",
					1: "#overlay_pourDate"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_edit/screens/schedule_edit.php",
				"validation": "overlay_edit_schedule_validation",
				"toSend": {
					0: "#overlay_productionOrder",
					1: "#overlay_remove",
					2: "#overlay_queue_quantity",
					3: "#overlay_date",
					4: "#overlay_remove_date"
				},
				"closeDelay": 0,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/schedule_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#transaction_removeOrder div", function () {
			
			$("#screen_overlay_content #overlay_remove").val("1");

			overlay_update( overlay_setup[overlay_open], true );

		});
		
		$(document).on("click", "tr[data-nav='overlay'][data-overlay='schedule_edit']", function () {
			
			if ( $("#overlay_order").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_order'}) );
			}
			 
			$("#overlay_order").val( $(this).attr("data-id") );
			
			if ( $("#overlay_pourDate").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_pourDate'}) );
			}
			
			$("#overlay_pourDate").val( $(this).attr("data-pourDate") );
			
			overlay_open = 'edit_schedule';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);