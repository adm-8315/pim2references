( function ($) {
	
	overlay_setup['material_edit'] = {
		"title": "",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/material_edit/screens/material_edit.php",
				"toSend": {
					0: "#overlay_material",
					1: "#transaction_transaction_form_name",
					2: "#transaction_transaction_form_manufacturer",
					3: "#transaction_transaction_form_materialType",
					4: "#transaction_transaction_form_measure"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/material_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#material_edit", function () {
			overlay_open = 'material_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);