<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Material Update
	
	$query = "
		UPDATE
			material
		SET
			material = ?,
			materialType = ?,
			measure = ?
		WHERE	
			materialID = ?
	";
	
	$values = array(
		$_POST['transaction_transaction_form_name'],
		$_POST['transaction_transaction_form_materialType'],
		$_POST['transaction_transaction_form_measure'],
		intval( $_POST['overlay_material'] )
	);
	
	$result['materialUpdate'] = dbquery( $query, $values );
	
	
	// Remove Manufacturer
	
	$query = "
		DELETE FROM
			materialManufacturerLink
		WHERE
			material = ?
	";
	
	$values = array(
		intval( $_POST['overlay_material'] )
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	// Insert
	
	if ( $_POST['transaction_transaction_form_manufacturer'] != '-1' )
	{
		
		$query = "
			INSERT INTO
				materialManufacturerLink
				( material, company )
				VALUES
				( ?, ? )
		";
		
		$values = array(
			intval( $_POST['overlay_material'] ),
			$_POST['transaction_transaction_form_manufacturer']
		);
		
		$result['insert'] = dbquery( $query, $values );
		
	}
	
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Material Updated</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
	}
</style>