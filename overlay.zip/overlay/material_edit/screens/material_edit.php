<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Material
	
	$query = "
		SELECT
			m.material,
			c.companyID,
			m.measure,
			m.materialType
		FROM
			material m
		LEFT JOIN
			materialManufacturerLink mml
			ON m.materialID = mml.material
		LEFT JOIN
			company c
			ON mml.company = c.companyID
		WHERE
			m.materialID = ?
	";
	
	$values = array(
		$_POST['overlay_material']
	);
	
	$result['material'] = dbquery( $query, $values );
	
	
	// Manufacturers
	
	$query = "
		SELECT
			c.companyID,
			c.company
		FROM
			company c
		LEFT JOIN
			companyCompanyPropertyLink ccpl
			ON c.companyID = ccpl.company
		WHERE
			c.active = 1
		AND
			ccpl.companyProperty = 2
		ORDER BY
			c.company ASC
	";
	
	$values = array();
	
	$result['manufacturer'] = dbquery( $query, $values );
	
	
	// Material Type
	
	$query = "
		SELECT
			*
		FROM
			materialType mt
		ORDER BY
			mt.materialType ASC
	";
	
	$values = array();
	
	$result['materialType'] = dbquery( $query, $values );
	
	
	// Measure
	
	$query = "
		SELECT
			*
		FROM
			measure me
		ORDER BY
			me.measureSingular ASC
	";
	
	$values = array();
	
	$result['measure'] = dbquery( $query, $values );

?>
<div class='transaction_transaction_container'>
	
	<h4>Material</h4>
	
	<div id='transaction_transaction_form_transationType'>Edit</div>
	<div id="transaction_transaction_form_materialDisplay" data-material="<?php echo $_POST['overlay_material']; ?>"><?php echo $result['material'][0]['material']; ?></div>
	
	<div id="transaction_transaction_container">
		
		<label>Manufacturer</label>
		<div class='field'>
			<select id ="transaction_transaction_form_manufacturer">
				<option value='-1'>Choose...</option>
				<?php
					
				foreach ( $result['manufacturer'] as $row )
				{
					
					echo "<option value='{$row['companyID']}' ";
					
					if ( $result['material'][0]['companyID'] == $row['companyID'] )
					{
						echo "selected='selected'";
					}
					
					echo ">{$row['company']}</option>";
					
				}
					
				?>
			</select>
		</div>
		<div class='clearMe'></div>

		<label>Name</label>
		<div class='field'><input type='text' id ="transaction_transaction_form_name" value="<?php echo htmlspecialchars( $result['material'][0]['material'] ); ?>" /></div>
		<div class='clearMe'></div>
		
		<label>Material Type</label>
		<div class='field'>
			<select id ="transaction_transaction_form_materialType">
				<option value='-1'>Choose...</option>
				<?php
					
				foreach ( $result['materialType'] as $row )
				{
					
					echo "<option value='{$row['materialTypeID']}' ";
					
					if ( $result['material'][0]['materialType'] == $row['materialTypeID'] )
					{
						echo "selected='selected'";
					}
					
					echo ">{$row['materialType']}</option>";
					
				}
					
				?>
			</select>
		</div>
		<div class='clearMe'></div>
		
		<label>Measure</label>
		<div class='field'>
			<select id ="transaction_transaction_form_measure">
				<option value='-1'>Choose...</option>
				<?php
					
				foreach ( $result['measure'] as $row )
				{
					
					echo "<option value='{$row['measureID']}' ";
					
					if ( $result['material'][0]['measure'] == $row['measureID'] )
					{
						echo "selected='selected'";
					}
					
					echo ">{$row['measureSingular']}, {$row['measurePlural']}</option>";
					
				}
					
				?>
			</select>
		</div>
		<div class='clearMe'></div>
	</div>

</div>

<script>
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		var keyupString = '#transaction_transaction_form_name';
		var changeString = '#transaction_transaction_form_manufacturer, #transaction_transaction_form_materialType, #transaction_transaction_form_measure';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			// Validation Final	
			if (
				(
					(
						$("#transaction_transaction_form_name").val() != "<?php echo addslashes( $result['material'][0]['material'] ); ?>" ||
						$("#transaction_transaction_form_manufacturer").val() != "<?php echo addslashes( $result['material'][0]['companyID'] ); ?>" ||
						$("#transaction_transaction_form_materialType").val() != "<?php echo addslashes( $result['material'][0]['materialType'] ); ?>" ||
						$("#transaction_transaction_form_measure").val() != "<?php echo addslashes( $result['material'][0]['measure'] ); ?>"
					) &&
					$("#transaction_transaction_form_name").val() != "" 
				)
			) {
			    overlay_valid(true);
			} else {
			    overlay_valid(false);
			}

		}
		
	}
	
	window.overlay_transaction_transaction_validation();


</script>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container #transaction_transaction_container {
		width: 300px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 35px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container div.field {
		float: right;
		
		height: 20px;
		width: 160px;
		
		margin-bottom: 10px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
	}
	
	#transaction_transaction_form_name {
		width: 170px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_container select {
		width: 184px !important;
	}
	
	#transaction_transaction_container .field {
		padding-bottom: 5px;
	}

	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>

