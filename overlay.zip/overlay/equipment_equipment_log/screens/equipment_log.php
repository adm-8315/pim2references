<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Type
	
	$query = "
		SELECT
			*
		FROM
			preventativeMaintenanceType pmt
	";
	
	$values = array();
	
	$result['type'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id='equipment_log_table'>

	<tr>
		<td class='left'>Recording Type</td>
		<td class='right'>
			<select id='equipment_log_type'>
				<option value='-1'>Choose...</option>
				<?php
					foreach ( $result['type'] as $row )
					{
						echo "<option value='{$row['preventativeMaintenanceTypeID']}'>{$row['preventativeMaintenanceType']}</option>";
					}
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class='left'>Recording Value</td>
		<td class='right'><input type="text" id="equipment_log_value"></td>
	</tr>

</table>

<style>

#equipment_log_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>
	
	$("#screen_overlay_content")
		.find("#equipment_log_value")
		.mask('00000000', {
			reverse: true
		});

	if( typeof overlay_equipment_log_validation != 'function' )
	{
	
		var keyupString = '#equipment_log_value';
		var changeString = '#equipment_log_type, #equipment_log_value';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_equipment_log_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_equipment_log_validation();
		});
	
		window.overlay_equipment_log_validation = function ()
		{
			
			if (
				$("#equipment_log_type").val() != "-1" &&
				$.isNumeric( $("#equipment_log_value").val() ) &&
				$("#equipment_log_value").val() >= 0
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
	
		}
	
	}

</script>