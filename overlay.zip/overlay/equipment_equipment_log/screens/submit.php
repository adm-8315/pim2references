<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		INSERT INTO
			preventativeMaintenanceLog
			( equipment, preventativeMaintenanceType, date, value )
			VALUES
			( ?, ?, CURDATE(), ?)
			
	";
	
	$values = array(
		$_POST['overlay_equipment'],
		$_POST['equipment_log_type'],
		$_POST['equipment_log_value']
	);
	
	$result['equipmentLogInsert'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['equipmentLogInsert'] )
	{
		echo "The log recording was added.";
	}
	else
	{
		echo "There was a problem add the recording.";
	}

?>