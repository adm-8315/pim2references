( function ($) {
	
	overlay_setup['equipment_log'] = {
		"title": "Equipment Log",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_equipment"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/equipment_equipment_log/screens/equipment_log.php",
				"validation": "overlay_equipment_log_validation",
				"toSend": {
					0: "#overlay_equipment",
					1: "#equipment_log_type",
					2: "#equipment_log_value"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/equipment_equipment_log/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".equipment_log_trigger", function () {
			overlay_open = 'equipment_log';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);