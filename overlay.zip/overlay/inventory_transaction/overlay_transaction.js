( function ($) {
	
	overlay_setup['transaction'] = {
		"title": "Transaction",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/inventory_transaction/screens/lookUp.php",
				"toSend": {
					0: "#transaction_materialType",
					1: "#transaction_materialType_category",
					2: "#transaction_manufacturer"
				}
			}, { 
				"id" : 2, 
				"url": "overlay/inventory_transaction/screens/browse.php",
				"validation": "overlay_transaction_browse_validation",
				"toSend": {
					0: "#transaction_materialBrowse_material",
					1: "#transaction_materialBrowse_material_category",
					2: "#transaction_materialBrowse_pageCount"
				}
			}, { 
				"id" : 3, 
				"url": "overlay/inventory_transaction/screens/transactionType.php",
				"validation": "overlay_transaction_transactionType_validation",
				"toSend": {
					0: "#transaction_transactionType_material",
					1: "#transaction_transactionType_material_category",
					2: "#transaction_transactionType_transactionType",
					3: "#transaction_transactionType_pageCount"
				}
			}, { 
				"id" : 4, 
				"url": "overlay/inventory_transaction/screens/transaction.php",
				"validation": "overlay_transaction_transaction_validation",
				"toSend": {
					0: "#transaction_transaction_transactionType",
					1: "#transaction_transaction_material",
					2: "#transaction_transaction_material_category",
					3: "#transaction_transaction_form_date",
					4: "#transaction_transaction_form_materialType",
					5: "#transaction_transaction_form_manufacturer",
					6: "#transaction_transaction_form_material",
					7: "#transaction_transaction_form_quantity",
					8: "#transaction_transaction_form_unit",
					9: "#transaction_transaction_form_cost",
					10: "#transaction_transaction_form_owner",
					11: "#transaction_transaction_form_location",
					12: "#transaction_transaction_form_owner_to",
					13: "#transaction_transaction_form_location_to",
					14: "#transaction_transaction_form_customer",
					15: "#transaction_transaction_form_customer_location",
					16: "#transaction_transaction_form_note"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 5, 
				"url": "overlay/inventory_transaction/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".button.transaction", function () {
			overlay_open = 'transaction';
			overlay_create( overlay_setup[overlay_open] );
		});
		
		$(document).on("change", "#transaction_materialType", function () {
			$("#screen_overlay_content").find("#transaction_materialType_category").val( $("#transaction_materialType").find("option:selected").attr("data-category") );
		});
		
		$(document).on("click", ".transaction_browse_material", function() {

			$("#screen_overlay_content").find(".transaction_browse_material").removeClass("selected");
			$(this).addClass("selected");

			$("#screen_overlay_content #transaction_materialBrowse_material").val( $(this).attr("data-material") );
			$("#screen_overlay_content #transaction_materialBrowse_material_category").val( $(this).attr("data-category") );

			overlay_update( overlay_setup[overlay_open], true )

		});
		
		$(document).on("click", "#transaction_materialBrowse_newMaterial div", function () {

			$("#screen_overlay_content .transaction_browse_material").removeClass("selected");

			$("#screen_overlay_content #transaction_materialBrowse_material").val("-1");

			overlay_update( overlay_setup[overlay_open], true );

		});
		
		$(document).on("click", ".transaction_transactionType_container button", function ( target ) {
						
			$("#transaction_transactionType_transactionType").val( $(this).data("transactiontype") );

			$("#screen_overlay_content .transaction_transactionType_container button").removeClass("selected");
			$(this).addClass("selected");

			overlay_update( overlay_setup[overlay_open], true );

		});
		
		$(document).on("change", "#transaction_transaction_form_customer", function () {
			
			var request;
			var myData = "customerID=" + $(this).val(); 
			
			request = $.ajax({
				url: "ajax/customer_shipping_location.php",
				type: "post",
				data: myData
			}).done( function( response, textStatus, jqXHR ) {
				$("#transaction_transaction_form_customer_location").html(response);
			});
			
		});
		
	});
	
})(jQuery);