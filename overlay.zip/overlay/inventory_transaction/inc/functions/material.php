<?php
	
	function transaction_product()
	{
		
		global $materialID, $new, $result, $materialCategory;
		
		if ( $new )
		{
			
			echo "<label>Material</label><input type='text' id='transaction_transaction_form_material' /><div class='clearMe'>&nbsp;</div>";
			
		}
		else
		{
			
			require_once( './../inc/mysql/material.php' );
			
			echo "<div id='transaction_transaction_form_materialDisplay'>{$result['material'][0]['material']}</div>";
			
		}
		
	}
	
	$functionQueue[] = "transaction_product";
	
	
?>