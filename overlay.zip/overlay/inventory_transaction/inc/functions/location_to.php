<?php
	
	function transaction_location_to()
	{
		
		global $permissions, $result, $transactionType;
		
		require_once( './../inc/mysql/location.php' );

		echo "<label>New Location</label>";
		
		echo "<select id='transaction_transaction_form_location_to'>";

			echo "<option data-location='-1' value='-1'>Choose...</option>";
			
			foreach( $result['location'] as $locationRow )
			{
				echo "<option data-location='" . $locationRow['locationID'] . "' value='{$locationRow['locationID']}'>" . $locationRow['location'] . "</option>";
			}
			

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";
	
	}
	
	$functionQueue[] = "transaction_location_to";
	

?>