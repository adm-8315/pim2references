<?php
	
	function transaction_customer()
	{
		
		global $result;
		
		require_once( './../inc/mysql/customer.php' );
		
		echo "<label>Customer</label>";

		echo "<select id='transaction_transaction_form_customer'>";

			echo "<option data-customer='-1' value='-1'>Choose...</option>";

			foreach ( $result['customer'] as $row )
			{

				echo "<option data-customer='{$row['companyID']}' value='{$row['companyID']}'>{$row['company']}</option>";

			}

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";

	}
	
	$functionQueue[] = "transaction_customer";
	

?>