<?php
	
	function transaction_note()
	{
		echo "<label>Notes</label><input type='text' id='transaction_transaction_form_note' /><div class='clearMe'>&nbsp;</div>";
	}
	
	$functionQueue[] = "transaction_note";
	

?>