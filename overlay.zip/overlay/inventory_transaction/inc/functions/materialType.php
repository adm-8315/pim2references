<?php
	
	function transaction_materialType()
	{
		
		global $result, $transactionType;
		
		require_once( './../inc/mysql/materialType.php' );

		echo "<label>Material Type</label>";

		echo "<select id='transaction_transaction_form_materialType'>";

			echo "<option data-customer='-1' value='-1'>Choose...</option>";

			foreach ( $result['materialType'] as $row )
			{

				echo "<option data-materialtype='{$row['materialTypeID']}' value='{$row['materialTypeID']}'>{$row['materialType']}</option>";

			}

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";

	}
	
	$functionQueue[] = "transaction_materialType";
	

?>