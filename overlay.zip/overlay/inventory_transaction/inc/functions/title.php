<?php
	
	function transaction_title()
	{
		
		global $transactionType;
		
		require_once( './../inc/mysql/title.php' );
		
		
		echo "<div id='transaction_transaction_form_transationType'>{$result['title'][0]['transactionType']}</div>";
	}
	
	$functionQueue[] = "transaction_title";

?>