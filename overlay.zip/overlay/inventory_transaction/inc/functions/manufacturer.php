<?php
	
	function transaction_manufacturer()
	{
		
		global $result;
		
		require_once( './../inc/mysql/manufacturer.php' );

		echo "<label>Manufacturer</label>";

		echo "<select id='transaction_transaction_form_manufacturer'>";

			echo "<option data-customer='-1' value='-1'>Choose...</option>";

			foreach ( $result['manufacturer'] as $row )
			{

				echo "<option data-manufacturer='{$row['companyID']}' value='{$row['companyID']}'>{$row['company']}</option>";

			}

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";

	}
	
	$functionQueue[] = "transaction_manufacturer";
	

?>