<?php
	
	function transaction_cost()
	{
		
		global $transactionType;

		if ( $transactionType == 1 ) // Received
		{
			echo "<label>Total Cost</label>";
		}
		else if ( $transactionType == 2 ) // Produced
		{
			echo "<label>Cost Per Unit</label>";
		}

		echo "<input id='transaction_transaction_form_cost' type='text' min='0' /><div class='clearMe'>&nbsp;</div>";

	}
	
	$functionQueue[] = "transaction_cost";

?>