<?php
	
	function transaction_quantity()
	{
		
		global $materialID, $new, $result, $materialCategory;
		
		
		/**
		 * Quantity
		 */
		
		echo "<label>Quantity</label>";

		if ( $new )
		{
			
			require_once( './../inc/mysql/measure.php' );
			
			echo "<select id='transaction_transaction_form_unit'>";
	
			foreach ( $result['measure'] as $row )
			{

				if ( $row['measureID'] == 5 )
				{
					echo "<option data-measure='{$row['measureID']}'  value='{$row['measureID']}' selected='selected'>{$row['measure']}</option>";
				}
				else
				{
					echo "<option data-measure='{$row['measureID']}' value='{$row['measureID']}'>{$row['measure']}</option>";
				}

			}
	
			echo "</select>";
			echo "<input id='transaction_transaction_form_quantity' type='text' min='0' />";
			
		} 
		else
		{
			
			require_once( './../inc/mysql/material.php' );
			
			echo "<div id='transaction_transaction_form_unit' class='display'>{$result['material'][0]['measure']}</div>";
			echo "<input id='transaction_transaction_form_quantity' class='display' type='text' min='0' />";
			
			/**
			 * Validation
			 */
		
			require_once( './../inc/mysql/validation.php' );
		

			foreach( $result['validation'] as $row )
			{
				echo "<div class='validate' data-company='{$row['company']}' data-location='{$row['location']}' data-stock='{$row['stock']}' style='display: none'></div>";
			}

			echo "<div class='clearMe'>&nbsp;</div>";
			
		}
		
	}
	
	$functionQueue[] = "transaction_quantity";
	

?>