<?php
	
	function transaction_customer_location()
	{
		echo "<label>Ship Location</label>";

		echo "<select id='transaction_transaction_form_customer_location'>";

		echo "<option data-customerlocation='-1' value='-1'>Choose...</option>";

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";
	}
	
	$functionQueue[] = "transaction_customer_location";

?>