<?php
	
	function transaction_location()
	{
				
		global $result, $permissions, $transactionType;
		
		require_once( './../inc/mysql/location.php' );

		echo "<label>Location</label>";

		echo "<select id='transaction_transaction_form_location'>";

			foreach ( $result['location'] as $row )
			{

				if ( $row['locationID'] == $_SESSION['default_location'] )
				{
					echo "<option data-location='{$row['locationID']}' value='{$row['locationID']}' selected='selected'>{$row['location']}</option>";
				}
				else
				{
					echo "<option data-location='{$row['locationID']}' value='{$row['locationID']}'>{$row['location']}</option>";
				}

			}

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";

	}
	
	$functionQueue[] = "transaction_location";
	

?>