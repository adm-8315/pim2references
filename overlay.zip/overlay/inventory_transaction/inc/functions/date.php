<?php
	
	function transaction_date()
	{
		echo "<label>Date</label>";

		echo "<button class='trigger'>Date</button>";

		echo "<input type='text' class='transaction_transaction_form_date overlay_date' id='transaction_transaction_form_date' />";

		echo "<div class='clearMe'>&nbsp;</div>";
	}
	
	$functionQueue[] = "transaction_date";
	

?>