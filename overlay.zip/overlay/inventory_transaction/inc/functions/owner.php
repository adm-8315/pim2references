<?php
	
	function transaction_owner()
	{
		
		global $transactionType, $result;
		
		
		if ( $transactionType != 2 )
		{
			
			require_once( './../inc/mysql/owner.php' );
		
			echo "<label>Owner</label>";

			echo "<select id='transaction_transaction_form_owner'>";

				echo "<option data-owner='-1' value='-1'>Dead Stock</option>";

				foreach ( $result['owner'] as $row )
				{
		
					if ( $row['companyID'] != 0 )
					{
						if ( $row['companyID'] == $_SESSION['default_owner'] )
						{
							echo "<option data-owner='{$row['companyID']}' value='{$row['companyID']}' selected='selected'>{$row['company']}</option>";
						}
						else
						{
							echo "<option data-owner='{$row['companyID']}' value='{$row['companyID']}'>{$row['company']}</option>";
						}
					}

				}

			echo "</select>";

			echo "<div class='clearMe'>&nbsp;</div>";
			
		}
		else
		{
			echo "<input type='hidden' id='transaction_transaction_form_owner' value='47' />";
		}
		
	}
	
	$functionQueue[] = "transaction_owner";
	

?>