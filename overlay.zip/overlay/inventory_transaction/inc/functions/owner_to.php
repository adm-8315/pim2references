<?php
	
	function transaction_owner_to()
	{
		
		global $result;
		
		require_once( './../inc/mysql/owner.php' );
	
		echo "<label>New Owner</label>";

		echo "<select id='transaction_transaction_form_owner_to'>";

			echo "<option data-owner='-1' value='-1'>Choose...</option>";

			echo "<option data-owner='-1' value='-1'>Dead Stock</option>";

			foreach ( $result['owner'] as $row )
			{

				if ( $row['companyID'] == $_SESSION['default_owner'] )
				{
					echo "<option data-owner='{$row['companyID']}' value='{$row['companyID']}' selected='selected'>{$row['company']}</option>";
				}
				else
				{
					echo "<option data-owner='{$row['companyID']}' value='{$row['companyID']}'>{$row['company']}</option>";
				}

			}

		echo "</select>";

		echo "<div class='clearMe'>&nbsp;</div>";
	
	}
	
	$functionQueue[] = "transaction_owner_to";
	

?>