<?php
	
	if ( $transactionType == 1 )
	{
		$query = "
			SELECT
				*
			FROM	
				materialType
			ORDER BY
				materialType ASC
		";
	} 
	else if ( $transactionType == 2 )
	{
		$query = "
			SELECT
				productTypeID as 'materialTypeID',
				productType as 'materialType'
			FROM	
				productType
			ORDER BY
				productType ASC
		";
	}
	else
	{
		$query = "
			SELECT 1
		";
	}
	

	$values = array();

	$result['materialType'] = dbquery( $query, $values );

?>