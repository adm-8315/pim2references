<?php
	
	$query = "
		SELECT
			me.measureID,
			me.measurePlural as 'measure'
		FROM
			measure me
		ORDER BY
			me.measurePlural ASC
	";

	$values = array();

	$result['measure'] = dbquery( $query, $values );

?>