<?php
	
	if ( $materialCategory == 1 )
	{
	
		$query = "
			SELECT
				i.stock,
				cll.company,
				cll.location
			FROM
				materialInventory i
			LEFT JOIN
				companyLocationLink cll
				ON cll.companyLocationLinkID = i.companyLocationLink
			WHERE
				i.material = ?
		";

		$values = array(
			$materialID
		);

		$result['validation'] = dbquery( $query, $values );
		
	}
	else if ( $materialCategory == 2 )
	{
		
		$query = "
			SELECT
				i.stock,
				cll.company,
				cll.location
			FROM
				productInventory i
			LEFT JOIN
				companyLocationLink cll
				ON cll.companyLocationLinkID = i.companyLocationLink
			WHERE
				i.product = ?
		";

		$values = array(
			$materialID
		);

		$result['validation'] = dbquery( $query, $values );
		
	} 
	
?>