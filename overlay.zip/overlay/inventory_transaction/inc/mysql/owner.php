<?php
	
	$query = "
		SELECT
			c.companyID,
			c.company
		FROM
			company c
		LEFT JOIN
			companyCompanyPropertyLink ccpl
			ON ccpl.company = c.companyID
		WHERE
			ccpl.companyProperty = 1
		AND
			c.active = 1
		ORDER BY
			c.company ASC
	";

	$values = array();

	$result['owner'] = dbquery( $query, $values );

?>