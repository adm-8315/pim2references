<?php
	
	$query = "
		SELECT
			ma.material,
			me.measurePlural as 'measure'
		FROM
			material ma
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		WHERE
			materialID = ?
	";

	$values = array(
		$materialID
	);

	$result['material'] = dbquery( $query, $values );
	
?>