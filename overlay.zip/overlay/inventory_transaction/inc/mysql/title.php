<?php
	
	$query = "
		SELECT
			CONCAT( 
			     UPPER(SUBSTR(transactionType,1,1)), 
			     SUBSTR(transactionType,2)
			 ) as 'transactionType'
		FROM
			transactionType
		WHERE
			transactionTypeID = ?
	";

	$values = array(
		$transactionType
	);

	$result['title'] = dbquery( $query, $values );
	
?>