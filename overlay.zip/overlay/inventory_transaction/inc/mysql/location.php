<?php
	
	$query = "
		SELECT
			locationID,
			location
		FROM
			(
				( 
					SELECT
						l.locationID,
						l.location,
						1 as 'admin'
					FROM
						location l
					WHERE
						l.stockable = 1
				) 
				UNION
				(
					SELECT
						l.locationID,
						l.location,
						0 as 'admin'
					FROM
						permissionLink pl
					LEFT JOIN
						location l
						ON l.locationID = pl.location
					WHERE
						pl.user = ?
					AND
						pl.permissionBlock = ?
					AND
						l.stockable = 1
				)
			) temp
		WHERE
			admin = ?
		ORDER BY
			location ASC
	";

	$permissionBlock = $transactionType + 11;

	$values = array(
		$_SESSION['user_id'],
		$permissionBlock,
		( isset( $permissions[1][1] ) ? 1: 0 )
	);

	$result['location'] = dbquery( $query, $values );

?>