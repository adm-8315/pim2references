<?php
	
	if ( $materialCategory == 1 )
	{
	
		$query = "
			SELECT
				ma.material,
				me.measurePlural as 'measure'
			FROM
				material ma
			LEFT JOIN
				measure me
				ON ma.measure = me.measureID
			WHERE
				materialID = ?
		";

		$values = array(
			$materialID
		);

		$result['material'] = dbquery( $query, $values );
		
	}
	else if ( $materialCategory == 2 )
	{
		
		$query = "
			SELECT
				p.product as 'material',
				me.measurePlural as 'measure'
			FROM
				product p
			LEFT JOIN
				measure me
				ON p.measure = me.measureID
			WHERE
				p.productID = ?
		";

		$values = array(
			$materialID
		);

		$result['material'] = dbquery( $query, $values );
		
	} 
	
?>