<?php

	$functionQueue = array();

	switch( $transactionType )
	{

		case 1:
			// Received
			require_once( "functions/title.php" );
			( ! $new ? require_once( "functions/material.php" ) : false );
			require_once( "functions/date.php" );
			( $new ? require_once( "functions/materialType.php" ) : false );
			( $new ? require_once( "functions/manufacturer.php" ) : false );
			( $new ? require_once( "functions/material.php" ) : false );
			require_once( "functions/quantity.php" );
			require_once( "functions/cost.php" );
			( $ownerID == -1 ? require_once( "functions/owner.php" ) : false );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/note.php" );
		
			break;
			
		case 2:
			// Produced
			require_once( "functions/title.php" );
			require_once( "functions/owner.php" );
			( ! $new ? require_once( "functions/material.php" ) : false );
			require_once( "functions/date.php" );
			( $new ? require_once( "functions/materialType.php" ) : false );
			( $new ? require_once( "functions/manufacturer.php" ) : false );
			( $new ? require_once( "functions/material.php" ) : false );
			require_once( "functions/quantity.php" );
			require_once( "functions/cost.php" );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/note.php" );
			
			break;
			
		case 3:
			// Transfer
			require_once( "functions/title.php" );
			require_once( "functions/material.php" );
			require_once( "functions/date.php" );
			( $ownerID == -1 ? require_once( "functions/owner.php" ) : false );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/quantity.php" );
			require_once( "functions/owner_to.php" );
			require_once( "functions/location_to.php" );
			require_once( "functions/note.php" );
			
			break;
			
		case 4:
			// Shipped
			require_once( "functions/title.php" );
			require_once( "functions/material.php" );
			require_once( "functions/date.php" );
			require_once( "functions/quantity.php" );
			( $ownerID == -1 ? require_once( "functions/owner.php" ) : false );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/customer.php" );
			require_once( "functions/customer_location.php" );
			require_once( "functions/note.php" );
			
			break;
		
		case 5:
			// Scrapped
			require_once( "functions/title.php" );
			require_once( "functions/material.php" );
			require_once( "functions/date.php" );
			require_once( "functions/quantity.php" );
			( $ownerID == -1 ? require_once( "functions/owner.php" ) : false );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/note.php" );
			
			break;
		
		case 6:
			// Used
			require_once( "functions/title.php" );
			require_once( "functions/material.php" );
			require_once( "functions/date.php" );
			require_once( "functions/quantity.php" );
			( $ownerID == -1 ? require_once( "functions/owner.php" ) : false );
			( $locationID == -1 ? require_once( "functions/location.php" ) : false );
			require_once( "functions/note.php" );
			
			break;
			
	}
	
?>