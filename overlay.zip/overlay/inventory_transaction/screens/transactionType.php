<?php

	/**
	 *	Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	require_once( "../../../inc/session.php" );
	require_once( "../../../inc/permissions.php" );
	
	
	/**
	 * Validation
	 */
	
	if ( 
		( isset( $_POST['transaction_materialBrowse_material'] ) && $_POST['transaction_materialBrowse_material'] == -1 ) ||
		( isset( $_POST['overlay_material'] ) && $_POST['overlay_material'] == -1 )
	) {
		$new = true;
		$material = -1;
	}
	else
	{
		$new = false;
	}
	
	if ( isset( $_POST['transaction_materialBrowse_material'] ) )
	{
		$material = $_POST['transaction_materialBrowse_material'];
		$materialCategory = $_POST['transaction_materialBrowse_material_category'];
	}
	else if ( isset( $_POST['overlay_material'] ) )
	{
		$material = $_POST['overlay_material'];
		$materialCategory = $_POST['overlay_material_category'];
	}
	
	if ( 
		( isset($_POST['transaction_materialBrowse_pageCount']) && $_POST['transaction_materialBrowse_pageCount'] == 4 ) ||
		( isset($_POST['overlay_pageCount']) && $_POST['overlay_pageCount'] == 4 )
	) {
		$stepCount = 4;
	}
	else
	{
		$stepCount = 2;
	}
	
	
	/**
	 * Display 
	 */
?>

<input id='transaction_transactionType_material' type='hidden' value='<?php echo $material; ?>' />
<input id='transaction_transactionType_material_category' type='hidden' value='<?php echo $materialCategory; ?>' />
<input id='transaction_transactionType_pageCount' type='hidden' value='<?php echo $stepCount; ?>' />
<input id='transaction_transactionType_transactionType' type='hidden' />


<div class='transaction_transactionType_container'>
	<div>
		
		<?php
						
			// Produced
			if ( 
				(
					isset( $permissions[1][1] ) ||
					isset( $permissions[2][13] )
				) && (
					(
						$stepCount == 4 &&
						(
							$_POST['transaction_materialBrowse_material_category'] == 2 ||
							$_POST['transaction_materialBrowse_material'] == -1
						)
					) || (
						$stepCount == 2 &&
						$_POST['overlay_material_category'] == 2
					)
				)
			) {
				echo "<button data-transactionType='2'>Produced</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='2'>Produced</div>";
			}
			
			// Used
			if (
				(
					isset( $permissions[1][1] ) ||
					isset( $permissions[2][17] )
				) &&
				! $new
			) {
				echo "<button data-transactionType='6'>Used</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='6'>Used</div>";
			}
			
		?>
	</div>
	<div>
		<?php
			
			// Received
			if ( 
				(
					isset( $permissions[1][1] ) ||
					isset( $permissions[2][12] )
				) && (
					(
						$stepCount == 4 &&
						(
							$_POST['transaction_materialBrowse_material_category'] == 1 ||
							$_POST['transaction_materialBrowse_material'] == -1
						)
					) || (
						$stepCount == 2 &&
						$_POST['overlay_material_category'] == 1
					)
				)
			) {
				echo "<button data-transactionType='1'>Received</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='1'>Received</div>";
			}
			
			// Shipped
			if (
				(
					isset( $permissions[1][1] ) ||
					isset( $permissions[2][15] )
				) &&
				! $new
			) {
				echo "<button data-transactionType='4'>Shipped</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='4'>Shipped</div>";
			}

		?>
	</div>
	<div>
		<?php
		
			// Transfer
			if (
				(
					$stepCount == 4 ||
					isset( $permissions[1][1] ) ||
					(
						isset( $_POST['overlay_location'] ) &&
						isset( $permissions[2][14][ $_POST['overlay_location'] ] ) &&
						$permissions[2][14][ $_POST['overlay_location'] ] == 1
					)
				) &&
				! $new
			) {
				echo "<button data-transactionType='3'>Transfer</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='3'>Transfer</div>";
			}
			
			// Scrapped
			if (
				(
					isset( $permissions[1][1] ) ||
					isset( $permissions[2][16] )
				) &&
				! $new
			) {
				echo "<button data-transactionType='5'>Scrapped</button>";
			}
			else
			{
				echo "<div class='transaction_transactionType_deactivated' data-transactionType='5'>Scrapped</div>";
			}
			
		?>
	</div>
</div>

<style>
	
	.transaction_transactionType_container {
		text-align: center;
	}
	
	.transaction_transactionType_container button,
	.transaction_transactionType_container .transaction_transactionType_deactivated {
		display: inline-block;
		
		width: 150px;
		
		padding: 20px;
		margin: 20px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 4px;
		
		color: #555;
	}
	
	.transaction_transactionType_container .transaction_transactionType_deactivated {
		width: 108px;
		
		color: #ccc;
	}
	
	.transaction_transactionType_container button:hover{
		background: #c4c4c4;
		
		border: 1px solid #777;
	}
	
	.transaction_transactionType_container button.selected {
		background: #c4c4c4;
		
		border: 1px solid #777;
	}
	
</style>

<script>
<!--

	if( typeof overlay_transaction_transactionType_validation != 'function' )
	{
		
		window.overlay_transaction_transactionType_validation = function ()
		{
		
			if ( $(".transaction_browse_material.selected").length > 0 )
			{
				overlay_valid( true );
			}
		
		}
		
	}
	
-->
</script>