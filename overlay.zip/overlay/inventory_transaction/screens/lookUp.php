<?php

	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Material Type
	
	$query = "
		SELECT
			*
		FROM
			(
				(
					SELECT
						1 as 'category',
						mt.*
					FROM
						materialType mt
				)
				UNION
				(
					SELECT
						2 as 'category',
						pt.*
					FROM
						productType pt
				) 
			) as temp
		ORDER BY
			materialType ASC
	";
	
	$values = array();
	
	$result['materialType'] = dbquery($query, $values);
	
	
	// Manufacturer
	
	$query = "
		SELECT
			c.companyID,
			c.company
		FROM
			company c
		LEFT JOIN
			companyCompanyPropertyLink ccpl
			ON ccpl.company = c.companyID
		WHERE
			ccpl.companyProperty = 2
		AND
			c.active = 1
		ORDER BY
			c.company ASC
	";
	
	$values = array();
	
	$result['manufacturer'] = dbquery($query, $values);
	
	
	/**
	 * Display
	 */
	
	// Material Type
	
	echo "<div id='transaction_materialType_container'>";
	
	echo "<label for='transaction_materialType' >Material Type:</label>";
	
	echo "<select id='transaction_materialType'>";
		echo "<option value='-1' selected='selected'>Choose...</option>";
	
	foreach ( $result['materialType'] as $row )
	{
		echo "<option data-category='" . $row['category'] . "' value='" . $row['materialTypeID'] . "'>" . $row['materialType'] . "</option>";
	}
	
	echo "</select>";
	
	echo "<input type='hidden' id='transaction_materialType_category' value=''>";
	
	echo "</div>";
	
	
	// Manufacturer
	
	echo "<div id='transaction_manufacturer_container'>";
	
	echo "<label for='transaction_manufacturer' >Manufacturer:</label>";
	
	echo "<select id='transaction_manufacturer'>";
		echo "<option value='-1' selected='selected'>Choose...</option>";
	
	foreach ( $result['manufacturer'] as $row )
	{
		echo "<option value='" . $row['companyID'] . "'>" . $row['company'] . "</option>";
	}
	
	echo "</select>";
	
	echo "</div>";
?>

<style>
	
	#transaction_materialType_container,
	#transaction_manufacturer_container {
		text-align: center;
	}
	
	#transaction_materialType_container label,
	#transaction_manufacturer_container label {
		margin-bottom: 10px;
		
		font-size: 20px;
		font-weight: 800;
	}
	
	#transaction_materialType_container {
		margin-bottom: 25px;
	}
	
	
</style>