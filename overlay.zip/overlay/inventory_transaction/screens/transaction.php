<?php

	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	require_once( "../../../inc/session.php" );
	require_once( "../../../inc/permissions.php" );
	
	/**
	 * Variables
	 */
	
	// New
	
	if ( $_POST['transaction_transactionType_material'] == -1 )
	{
		$new = true;
	}
	else
	{
		$new = false;
	}
	
	
	// Transaction Type
	
	if ( 
		( 1 <= $_POST['transaction_transactionType_transactionType'] ) && 
		( $_POST['transaction_transactionType_transactionType'] <= 7 ) 
	) {
		$transactionType = $_POST['transaction_transactionType_transactionType'];
	}
	
	// Material ID
	
	$materialID = $_POST['transaction_transactionType_material'];
	
	
	// Material Category
	
	$materialCategory = $_POST['transaction_transactionType_material_category'];
	
	
	// LocationID
	
	if ( isset( $_POST['overlay_location'] ) )
	{
		$locationID = $_POST['overlay_location'];
	}
	else
	{
		$locationID = -1;
	}
	
	
	// OwnerID
	
	if ( isset( $_POST['overlay_owner'] ) )
	{
		$ownerID = $_POST['overlay_owner'];
	}
	else
	{
		$ownerID = -1;
	}
	
	
	// Step Count
	
	if ( isset($_POST['transaction_transactionType_pageCount']) && $_POST['transaction_transactionType_pageCount'] == 4 ) 
	{
		$stepCount = 4;
	}
	else
	{
		$stepCount = 2;
	}
	
	
	/**
	 * Functions
	 */
	
	require_once( "../inc/functions.php" );
	

	/**
	 * Display
	 */
	
	echo "<div class='transaction_transaction_container'>";
	
		echo "<input type='hidden' id='transaction_transaction_pageCount' value='{$stepCount}' />";
		echo "<input type='hidden' id='transaction_transaction_transactionType' value='{$transactionType}' />";
		echo "<input type='hidden' id='transaction_transaction_material' value='{$materialID}' />";
		echo "<input type='hidden' id='transaction_transaction_material_category' value='{$materialCategory}' />";
		
		echo "<div>";
		
			foreach( $functionQueue as $functionCall )
			{
				$functionCall();
			}
			
			echo "</div><div class='clearMe'>&nbsp;</div>";
		echo "</div>";
	echo "</div>";
	
?>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container div {
		width: 300px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 5px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 30px;
		
		line-height: 30px;
		font-size: 14px;
		color: #555;
	}
	
	.transaction_transaction_container div input,
	.transaction_transaction_container div button,
	.transaction_transaction_container div select {
		float: right;
		
		height: 20px;
		width: 186px;
		
		margin-bottom: 10px;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
	}
	
	.transaction_transaction_container #transaction_transaction_form_quantity,
	.transaction_transaction_container #transaction_transaction_form_cost {
		text-align: right;
	}
	
	#transaction_transaction_form_quantity,
	.transaction_transaction_form_date {
		width: 100px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_quantity.display {
		width: 136px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_unit {
		width: 76px;
	}
	
	#transaction_transaction_form_unit.display {
		float: right;
		display: inline-block;
		
		width: 40px;
		
		line-height: 30px;
		text-align: right;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>

<script>

	$("#screen_overlay_content")
		.find(".transaction_transaction_form_date")
		.mask('00-00-0000', {
			reverse: true
		});

	$("#screen_overlay_content")
		.find("#transaction_transaction_form_quantity")
		.mask('999999999~99', {
			translation: {
				'~': {
					pattern: /[0-9|.]/
				}
			}
		});

	$("#screen_overlay_content")
		.find("#transaction_transaction_form_cost")
		.mask('000,000,000,000,000.00', {
			reverse: true
		});
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		var keyupString = '.transaction_transaction_form_date, #transaction_transaction_form_quantity, #transaction_transaction_form_cost';
		var changeString = ' #transaction_transaction_form_owner, #transaction_transaction_form_location, #transaction_transaction_form_location_to, #transaction_transaction_form_customer, #transaction_transaction_form_customer_location';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", "#transaction_transaction_form_customer", function () {
			
			var myData = "customerID=" + $(this).val();
			
			request = $.ajax({
				url: "ajax/customer_shipping_location.php",
				type: "post",
				data: myData
			}).done( function( response, textStatus, jqXHR ) {
				$("#transaction_transaction_form_customer_location").html(response);
			});
		});
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			var validation_individual = false;
			var validation_quantity = false;
			var validation_basic = false;
			
			// Validation Individual
			if (
				
				(
		            ( 
						$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 1 ||
		                $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 2
		            ) &&
		            Math.floor(parseFloat($("#transaction_transaction_form_cost").val())) >= 0
		        ) || ( 
					$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 3 &&
		            $("#transaction_transaction_form_location_to option:selected").attr("data-location") != -1
		        ) || ( 
					$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 4 &&
		            $("#transaction_transaction_form_customer option:selected").attr("data-customer") != -1 &&
		            $("#transaction_transaction_form_customer_location option:selected").val() != -1
		        ) || ( 
					$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 5 ||
		            $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 6
		        )
		
			) {
				validation_individual = true;
			}
			
			
			// Validation Quantity
			if (
				( 
					$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 1 ||
		            $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 2
		        ) || (
					( 
						$(".transaction_transactionType_container button.selected").attr("data-transactionType") == 3 ||
		                $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 4 ||
		                $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 5 ||
		                $(".transaction_transactionType_container button.selected").attr("data-transactionType") == 6
		            ) && (
		                ( 
							$("#transaction_transaction_pageCount").val() == 4 &&
		                    $("#screen_overlay_content").find(".validate[data-company='" + $("#transaction_transaction_form_owner option:selected").attr("data-owner") + "'][data-location='" + $("#transaction_transaction_form_location option:selected").attr("data-location") + "']").length > 0 &&
		                    parseInt($("#transaction_transaction_form_quantity").val()) <= $("#screen_overlay_content").find(".validate[data-company='" + $("#transaction_transaction_form_owner option:selected").attr("data-owner") + "'][data-location='" + $("#transaction_transaction_form_location option:selected").attr("data-location") + "']").attr("data-stock")
		                ) || ( 
							$("#transaction_transaction_pageCount").val() == 2 &&
		                    $("#screen_overlay_content").find(".validate[data-company='" + $("#overlay_owner").val() + "'][data-location='" + $("#overlay_location").val() + "']").length > 0 &&
		                    parseInt($("#transaction_transaction_form_quantity").val()) <= $("#screen_overlay_content").find(".validate[data-company='" + $("#overlay_owner").val() + "'][data-location='" + $("#overlay_location").val() + "']").attr("data-stock")
		                )
		            )

		        )
			) {
				validation_quantity = true;
			}
			
			if (
				$(".transaction_transaction_form_date").val().split("-").length == 3 &&
		        $.isNumeric($(".transaction_transaction_form_date").val().split("-")[0]) &&
		        $.isNumeric($(".transaction_transaction_form_date").val().split("-")[1]) &&
		        $.isNumeric($(".transaction_transaction_form_date").val().split("-")[2]) &&
		        $.isNumeric($("#transaction_transaction_form_quantity").val()) &&
		        (1 <= $(".transaction_transaction_form_date").val().split("-")[0]) && ($(".transaction_transaction_form_date").val().split("-")[0] <= 12) &&
		        (1 <= $(".transaction_transaction_form_date").val().split("-")[1]) && ($(".transaction_transaction_form_date").val().split("-")[1] <= 31) &&
		        $(".transaction_transaction_form_date").val().split("-")[2].length == 4 &&
		        0 < $("#transaction_transaction_form_quantity").val() &&
		        Math.floor(parseFloat($("#transaction_transaction_form_quantity").val())) > 0
			) {
				validation_basic = true;
			}
			
			console.log( "validation_individual: " + validation_individual );
			console.log( "validation_quantity: " + validation_quantity );
			console.log( "validation_basic: " + validation_basic );
			
			// Validation Final	
			if (
			    validation_individual &&
				validation_quantity &&
				validation_basic
			) {
			    //console.log( "true" );
			    overlay_valid(true);
			} else {
			    //console.log("false");
			    overlay_valid(false);
			}

		}
		
	}
	
</script>