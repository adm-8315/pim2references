<?php

	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	require_once( "../../../inc/session.php" );
	require_once( "../../../inc/functions/date_conversion.php" );
	
	if ( $_POST['transaction_transaction_material_category'] == 1 )
	{
		require_once( "../../../inc/functions/update_materialInventory.php" );
		require_once( "../../../inc/functions/update_materialCost.php" );
	}
	
	if ( $_POST['transaction_transaction_material_category'] == 2 )
	{
		require_once( "../../../inc/functions/update_productInventory.php" );
		require_once( "../../../inc/functions/update_productCost.php" );
	}
	

	/**
	 * Variables
	 */
	
	$debug = false;
	$result = array();
	$query = "";
	$values = array();
	
	
	if ( $_POST['transaction_transaction_transactionType'] == 1 )
	{
		$_POST['transaction_transaction_material_category'] = 1;
	}
	else if ( $_POST['transaction_transaction_transactionType'] == 2 )
	{
		$_POST['transaction_transaction_material_category'] = 2;
	}
	
	
	/**
	 * Debug
	 */
	
	if ( $debug )
	{
		print_r( $_POST );
	}
	
	
	/**
	 * Validation
	 */
	
	if ( isset( $_POST['overlay_owner'] ) )
	{
		$_POST['transaction_transaction_form_owner'] = $_POST['overlay_owner'];
	}
	else if ( ! isset( $_POST['transaction_transaction_form_owner'] ) || $_POST['transaction_transaction_form_owner'] == -1 )
	{
		$_POST['transaction_transaction_form_owner'] = null;
	}
	
	if ( ! isset( $_POST['transaction_transaction_form_owner_to'] ) ||  $_POST['transaction_transaction_form_owner_to'] == -1 )
	{
		$_POST['transaction_transaction_form_owner_to'] = null;
	}
	
	if ( isset( $_POST['overlay_location'] ) )
	{
		$_POST['transaction_transaction_form_location'] = $_POST['overlay_location'];
	}
	
	
	/**
	 * Process
	 */
	
	// Cost Calculation
	
	if ( $_POST['transaction_transaction_transactionType'] == 1 ) // Received
	{
		$cost = floatval( str_replace( ',', '', $_POST['transaction_transaction_form_cost'] ) ) / floatval( $_POST['transaction_transaction_form_quantity'] );
	}
	else if ( $_POST['transaction_transaction_transactionType'] == 2 ) // Produced
	{
		$cost = floatval( str_replace( ',', '', $_POST['transaction_transaction_form_cost'] ) );
	}
	
	
	
	/**
	 * Material
	 */
	
	if ( $_POST['transaction_transaction_material_category'] == 1 ) 
	{
		
		if ( $_POST['transaction_transaction_material'] == -1 )
		{
			
			/**
			 * New Material
			 */
			
			$query = "
				INSERT
					INTO material
					( materialType, cost, measure, material )
					VALUES
					( ?, ?, ?, ? )
			";
		
			$values = array(
				$_POST['transaction_transaction_form_materialType'],
				$cost,
				$_POST['transaction_transaction_form_unit'],
				$_POST['transaction_transaction_form_material']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInsert'] = -1;
			}
			else
			{
				$result['materialInsert'] = dbquery( $query, $values );
			}
		
		
			$query = "
				INSERT
					INTO materialManufacturerLink
					( material, company )
					VALUES
					( ?, ? )
			";
		
			$values = array(
				$result['materialInsert'],
				$_POST['transaction_transaction_form_manufacturer']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialManufacturerLinkInsert'] = -1;
			}
			else
			{
				$result['materialManufacturerLinkInsert'] = dbquery( $query, $values );
			}
		
			$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
		
			$query = "
				INSERT
					INTO materialInventory
					( material, companyLocationLink, stock )
					VALUES
					( ?, ?, ? )
			";
		
			$values = array(
				$result['materialInsert'],
				$companyLocationLink[0]['companyLocationLinkID'],
				$_POST['transaction_transaction_form_quantity']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInventoryInsert'] = -1;
			}
			else
			{
				$result['materialInventoryInsert'] = dbquery( $query, $values );
			}
		
		
		
		
			$query = "
				INSERT
					INTO materialTransaction
					( materialInventory, transactionType, value, cost, user, timestamp, notes )
					VALUES
					( ?, ?, ?, ?, ?, ?, ? )
			";
		
			$values = array(
				$result['materialInventoryInsert'],
				$_POST['transaction_transaction_transactionType'],
				$_POST['transaction_transaction_form_quantity'],
				$cost,
				$_SESSION['user_id'],
				date_to_mysql( $_POST['transaction_transaction_form_date'] ),
				$_POST['transaction_transaction_form_note']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['transactionInsert'] = -1;
			}
			else
			{
				$result['transactionInsert'] = dbquery( $query, $values );
			}
			
		}
		else
		{
			
			/**
			 * Existing Material
			 */
			
			switch( $_POST['transaction_transaction_transactionType'] )
			{

				case 1:
					// Received

					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_materialInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					$query = "
						INSERT
							INTO materialTransaction
							( materialInventory, transactionType, value, cost, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['materialInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$cost,
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					update_materialCost( $_POST['transaction_transaction_material'] );
					
					break;

				case 3:
					// Transfer
				
					$companyLocationLink['from'] = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$companyLocationLink['to'] = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner_to'], $_POST['transaction_transaction_form_location_to'] );
				
					$result['inventory']['from'] = get_materialInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink['from'][0]['companyLocationLinkID'] );
					$result['inventory']['to'] = get_materialInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink['to'][0]['companyLocationLinkID'] );
				
					if ( $result['inventory']['from'] >=  $_POST['transaction_transaction_form_quantity'] )
					{
						$query = "
							INSERT
								INTO materialTransaction
								( materialInventory, transactionType, value, companyLocationLink, user, timestamp, notes )
								VALUES
								( ?, ?, ?, ?, ?, ?, ? )
						";
				
						$values = array(
							$result['inventory']['from'][0]['materialInventoryID'],
							$_POST['transaction_transaction_transactionType'],
							$_POST['transaction_transaction_form_quantity'],
							$companyLocationLink['to'][0]['companyLocationLinkID'],
							$_SESSION['user_id'],
							date_to_mysql( $_POST['transaction_transaction_form_date'] ),
							$_POST['transaction_transaction_form_note']
						);
				
						if ( $debug )
						{
							dbquery_dump( $query, $values );
							$result['transactionInsert'] = -1;
						}
						else
						{
							$result['transactionInsert'] = dbquery( $query, $values );
						}
				
					}
				
					break;

				case 4:
					// Shipped
				
					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_materialInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					if ( $_POST['transaction_transaction_form_customer_location'] == 22 )
					{
						$customerLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_customer'], $_POST['transaction_transaction_form_customer_location'] );
					}
					else
					{
						$customerLocationLink = array();
						$customerLocationLink[0]['companyLocationLinkID'] = $_POST['transaction_transaction_form_customer_location'];
					}
				
					$query = "
						INSERT
							INTO materialTransaction
							( materialInventory, transactionType, value, companyLocationLink, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['materialInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$customerLocationLink[0]['companyLocationLinkID'],
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					break;
				
				case 5:
					// Scrapped
				case 6:
					// Used
				
					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_materialInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					$query = "
						INSERT
							INTO materialTransaction
							( materialInventory, transactionType, value, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['materialInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					break;

			}
			
			update_materialInventory();
			
		}
		
	}
	
	
	
	
	
	
	/**
	 * Product
	 */
	
	if ( $_POST['transaction_transaction_material_category'] == 2 ) 
	{
				
		if ( $_POST['transaction_transaction_material'] == -1 )
		{
			
			/**
			 * New Product
			 */
			
			$query = "
				INSERT
					INTO product
					( productType, cost, measure, product )
					VALUES
					( ?, ?, ?, ? )
			";
		
			$values = array(
				$_POST['transaction_transaction_form_materialType'],
				$cost,
				$_POST['transaction_transaction_form_unit'],
				$_POST['transaction_transaction_form_material']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInsert'] = -1;
			}
			else
			{
				$result['materialInsert'] = dbquery( $query, $values );
			}
		
			$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
		
			$query = "
				INSERT
					INTO productInventory
					( product, companyLocationLink, stock )
					VALUES
					( ?, ?, ? )
			";
		
			$values = array(
				$result['materialInsert'],
				$companyLocationLink[0]['companyLocationLinkID'],
				$_POST['transaction_transaction_form_quantity']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInventoryInsert'] = -1;
			}
			else
			{
				$result['materialInventoryInsert'] = dbquery( $query, $values );
			}
		
		
		
		
			$query = "
				INSERT
					INTO productTransaction
					( productInventory, transactionType, value, cost, user, timestamp, notes )
					VALUES
					( ?, ?, ?, ?, ?, ?, ? )
			";
		
			$values = array(
				$result['materialInventoryInsert'],
				$_POST['transaction_transaction_transactionType'],
				$_POST['transaction_transaction_form_quantity'],
				$cost,
				$_SESSION['user_id'],
				date_to_mysql( $_POST['transaction_transaction_form_date'] ),
				$_POST['transaction_transaction_form_note']
			);
		
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['transactionInsert'] = -1;
			}
			else
			{
				$result['transactionInsert'] = dbquery( $query, $values );
			}
			
		}
		else
		{
			
			/**
			 * Existing Product
			 */
			
			switch( $_POST['transaction_transaction_transactionType'] )
			{

				case 2:
					// Produced

					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_productInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					$query = "
						INSERT
							INTO productTransaction
							( productInventory, transactionType, value, cost, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['productInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$cost,
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					update_productCost( $_POST['transaction_transaction_material'] );
					
					break;

				case 3:
					// Transfer
				
					$companyLocationLink['from'] = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$companyLocationLink['to'] = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner_to'], $_POST['transaction_transaction_form_location_to'] );
				
					$result['inventory']['from'] = get_productInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink['from'][0]['companyLocationLinkID'] );
					$result['inventory']['to'] = get_productInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink['to'][0]['companyLocationLinkID'] );
				
					if ( $result['inventory']['from'] >=  $_POST['transaction_transaction_form_quantity'] )
					{
						$query = "
							INSERT
								INTO productTransaction
								( productInventory, transactionType, value, companyLocationLink, user, timestamp, notes )
								VALUES
								( ?, ?, ?, ?, ?, ?, ? )
						";
				
						$values = array(
							$result['inventory']['from'][0]['productInventoryID'],
							$_POST['transaction_transaction_transactionType'],
							$_POST['transaction_transaction_form_quantity'],
							$companyLocationLink['to'][0]['companyLocationLinkID'],
							$_SESSION['user_id'],
							date_to_mysql( $_POST['transaction_transaction_form_date'] ),
							$_POST['transaction_transaction_form_note']
						);
				
						if ( $debug )
						{
							dbquery_dump( $query, $values );
							$result['transactionInsert'] = -1;
						}
						else
						{
							$result['transactionInsert'] = dbquery( $query, $values );
						}
				
					}
				
					break;

				case 4:
					// Shipped
				
					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_productInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					if ( $_POST['transaction_transaction_form_customer_location'] == 22 )
					{
						$customerLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_customer'], $_POST['transaction_transaction_form_customer_location'] );
					}
					else
					{
						$customerLocationLink = array();
						$customerLocationLink[0]['companyLocationLinkID'] = $_POST['transaction_transaction_form_customer_location'];
					}
				
					$query = "
						INSERT
							INTO productTransaction
							( productInventory, transactionType, value, companyLocationLink, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['productInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$customerLocationLink[0]['companyLocationLinkID'],
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					break;
				
				case 5:
					// Scrapped
				case 6:
					// Used
				
					$companyLocationLink = get_companyLocationLink( $debug, $_POST['transaction_transaction_form_owner'], $_POST['transaction_transaction_form_location'] );
					$result['inventory'] = get_productInventory( $debug, $_POST['transaction_transaction_material'], $companyLocationLink[0]['companyLocationLinkID'] );
				
					$query = "
						INSERT
							INTO productTransaction
							( productInventory, transactionType, value, user, timestamp, notes )
							VALUES
							( ?, ?, ?, ?, ?, ? )
					";
				
					$values = array(
						$result['inventory'][0]['productInventoryID'],
						$_POST['transaction_transaction_transactionType'],
						$_POST['transaction_transaction_form_quantity'],
						$_SESSION['user_id'],
						date_to_mysql( $_POST['transaction_transaction_form_date'] ),
						$_POST['transaction_transaction_form_note']
					);
				
					if ( $debug )
					{
						dbquery_dump( $query, $values );
						$result['transactionInsert'] = -1;
					}
					else
					{
						$result['transactionInsert'] = dbquery( $query, $values );
					}
				
					break;

			}
		
			update_productInventory();
			
		}
		
	}
	
	
	
	function get_materialInventory( $debug, $materialID, $companyLocationLink )
	{
		
		$result = array();
		
		$query = "
			SELECT
				*
			FROM
				materialInventory
			WHERE
				material = ?
			AND
				companyLocationLink = ?
		";
		
		$values = array(
			$materialID,
			$companyLocationLink
		);
		
		if ( $debug )
		{
			dbquery_dump( $query, $values );
			$result['materialInventory'] = null;
		}
		else
		{
			$result['materialInventory'] = dbquery( $query, $values );
		}
		
		if ( empty( $result['materialInventory'] ) )
		{
			$query = "
				INSERT
					INTO materialInventory
					( material, companyLocationLink, stock )
					VALUES
					( ?, ?, ? )
			";

			$values = array(
				$materialID,
				$companyLocationLink,
				0
			);
			
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInventoryInsert'] = null;
			}
			else
			{
				
				$result['materialInventoryInsert'] = dbquery( $query, $values );
				
				$result['materialInventory'] = array( 
					array(
						"materialInventoryID" => $result['materialInventoryInsert'],
						"material" => $materialID,
						"companyLocationLink" => $companyLocationLink,
						"stock" => 0,
						"stockLevelWarning" => 0
					)
				);
				
			}
				
		}
		
		return $result['materialInventory'];
		
	}
	
	function get_productInventory( $debug, $materialID, $companyLocationLink )
	{
		
		$result = array();
		
		$query = "
			SELECT
				*
			FROM
				productInventory
			WHERE
				product = ?
			AND
				companyLocationLink = ?
		";
		
		$values = array(
			$materialID,
			$companyLocationLink
		);
		
		if ( $debug )
		{
			dbquery_dump( $query, $values );
			$result['materialInventory'] = null;
		}
		else
		{
			$result['materialInventory'] = dbquery( $query, $values );
		}
		
		if ( empty( $result['materialInventory'] ) )
		{
			$query = "
				INSERT
					INTO productInventory
					( product, companyLocationLink, stock )
					VALUES
					( ?, ?, ? )
			";

			$values = array(
				$materialID,
				$companyLocationLink,
				0
			);
			
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['materialInventoryInsert'] = null;
			}
			else
			{
				
				$result['materialInventoryInsert'] = dbquery( $query, $values );
				
				$result['materialInventory'] = array( 
					array(
						"materialInventoryID" => $result['materialInventoryInsert'],
						"material" => $materialID,
						"companyLocationLink" => $companyLocationLink,
						"stock" => 0,
						"stockLevelWarning" => 0
					)
				);
				
			}
				
		}
		
		return $result['materialInventory'];
		
	}
	
	function get_companyLocationLink( $debug, $company, $location )
	{
		
		$result = array();
		$values = array();
		
		$query = "
			SELECT
				companyLocationLinkID
			FROM	
				companyLocationLink
			WHERE
				company = ?
			AND
				location = ?
		";
		
		if ( $company == null )
		{
			$values[] = "0";
		}
		else
		{
			$values[] = $company;
		}
		
		$values[] = $location;
		
		if ( $debug )
		{
			dbquery_dump( $query, $values );
			$result['companyLocationLink'] = dbquery( $query, $values );
		}
		else
		{
			$result['companyLocationLink'] = dbquery( $query, $values );
		}
		
		if ( empty( $result['companyLocationLink'] ) )
		{
			
			$query = "
				INSERT
					INTO companyLocationLink
					( company, location )
					VALUES
					( ?, ? )
			";
			
			$values = array(
				$company,
				$location
			);
			
			$result['companyLocationLink'][0] = array();
			
			if ( $debug )
			{
				dbquery_dump( $query, $values );
				$result['companyLocationLink'][0]['companyLocationLinkID'] = -1;
			}
			else
			{
				$result['companyLocationLinkInsert'] = dbquery( $query, $values );
				
				$result['companyLocationLink'][0]['companyLocationLinkID'] = $result['companyLocationLinkInsert'];
			}
				
		}
		
		return $result['companyLocationLink'];
		
	}
	
	echo "<div class='transaction_transactionSubmit_complete'>Transaction Recorded</div>";
?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
	}
</style>
