<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * Validation
	 */
	
	if ( isset( $_POST['transaction_materialType'] ) && $_POST['transaction_materialType'] != -1)
	{
		$materialTypeCategory = $_POST['transaction_materialType_category'];
		$materialType = $_POST['transaction_materialType'];
	}
	else
	{
		$materialTypeCategory = null;
		$materialType = null;
	}
	
	if ( isset( $_POST['transaction_manufacturer'] ) && $_POST['transaction_manufacturer'] != -1 )
	{
		$manufacturer = $_POST['transaction_manufacturer'];
	}
	else
	{
		$manufacturer = null;
	}
	
	
	/**
	 * MySQL
	 */
	
	// Material
	
	$query = "";
	$values = array();
	
	if ( $materialTypeCategory == null )
	{
		
		$query .= "
			SELECT
				m.materialID,
				m.material,
				m.category
			FROM
				(
					(
		";
			
	}
	
	if ( $materialTypeCategory != 2 )
	{
		
		$query .= "
						SELECT
							m.materialID,
							m.material,
							1 as 'category'
						FROM
							material m
						LEFT JOIN
							materialManufacturerLink mml
							ON mml.material = m.materialID
						WHERE 
							1 = 1
		";
		
		if ( $materialType != null && $materialTypeCategory == 1 )
		{
			$query .= "
				AND
					m.materialType = ?
			";
		
			$values[] = $materialType;
		}
	
		if ( $manufacturer != null )
		{
			$query .= "
				AND
					mml.company = ?
			";
		
			$values[] = $manufacturer;
		}
		
		if ( $materialTypeCategory == 1 )
		{
			
			$query .= "
				ORDER BY
					m.material ASC
			";
			
		}
		
	}
	
	if ( $materialTypeCategory == null )
	{
		
		$query .= "
					)
					UNION
					(
		";
			
	}
	
	if ( $materialTypeCategory != 1 )
	{
		$query .= "
						SELECT DISTINCT
							m.productID as 'materialID',
							IF ( 
								c.company is not null,
								CONCAT( c.company, ' ', m.product ),
								m.product
							) as 'material',
							2 as 'category'
						FROM
							product m
						LEFT JOIN
							productConsumerLink pcl
							ON m.productID = pcl.product
						LEFT JOIN
							companyLocationLink cll
							ON pcl.companyLocationLink = cll.companyLocationLinkID
						LEFT JOIN
							company c
							ON cll.company = c.companyID
						WHERE
							1 = 1
		";
		
		if ( $materialType != null && $materialTypeCategory == 2 )
		{
			$query .= "
				AND
					m.productType = ?
			";
		
			$values[] = $materialType;
		}
		
		if ( $materialTypeCategory == 2 )
		{
			
			$query .= "
				ORDER BY
					IF ( 
						c.company is not null,
						CONCAT( c.company, ' ', m.product ),
						m.product
					) ASC
			";
			
		}
		
	}
	
	if ( $materialTypeCategory == null )
	{
		
		$query .= "
			)
		) as m
	ORDER BY
		m.material ASC
		";
			
	}
	
	$result['material'] = dbquery($query, $values);
	
	
	/**
	 * Display
	 */
	
	echo "<input id='transaction_materialBrowse_material' type='hidden' />";
	echo "<input id='transaction_materialBrowse_material_category' type='hidden' />";
	echo "<input id='transaction_materialBrowse_pageCount' type='hidden' />";
	echo "<div id='transaction_browse_container'>";
		
		echo "<label>Material</label>";
		echo "<div id='transaction_browse_wrapper'>";
		echo "<div id='transaction_browse'>";
	
		foreach ( $result['material'] as $row )
		{
		
			echo "<div class='transaction_browse_material' data-material='{$row["materialID"]}' data-category='{$row["category"]}'>";
			echo $row['material'];
			echo "</div>";
		
		}
		echo "</div>";
		echo "</div>";
	
	echo "</div>";
	
	echo "<div id='transaction_materialBrowse_newMaterial'><div>New Material</div></div>";
	
?>

<style>
	
	#transaction_browse_container {
		height: 325px;
		
		text-align: center;
	}
	
	#transaction_browse_container label {
		margin-bottom: 10px;
		
		font-size: 20px;
		font-weight: 800;
	}
	
	#transaction_browse_wrapper {
		display: inline-block;
		
		height: 300px;
		width: 100%;
		
		overflow-x: hidden;
		overflow-y: auto;
	}
	
	#transaction_browse {
		display: inline-block;
		
		width: auto;
		min-width: 300px;
		max-width: 400px;
		
		text-align: left;
	}
	
	.transaction_browse_material {
		display: block;
		
		padding: 5px 10px;
		
		cursor: pointer;
		cursor: hand;
	}
	
	.transaction_browse_material:hover {
		background: #cacaca;
	}
	
	.transaction_browse_material.selected {
		background: #c4c4c4;
	}
	
	.transaction_browse_material.selected:hover {
		background: #c4c4c4;
	}
	
	#transaction_materialBrowse_newMaterial {
		position: absolute;
		
		bottom: -55px;
		left: 0;
		right: 0;
		
		text-align: center;
	}
	
	#transaction_materialBrowse_newMaterial div {
		position: relative;
		
		left: 50%;
		
		margin-left: -75px;
		
		width: 150px;
		height: 35px;
		
		background: #e2e2e2;
		
		border-radius: 4px;
		border: 1px solid #bbb;
		
		line-height: 35px;
	}
	
	#transaction_materialBrowse_newMaterial div:hover {
		background: #d3d3d3;

		border: 1px solid #aaa;
	}
	
</style>

<script>
<!--

	$("#transaction_materialBrowse_pageCount").val( $(".overlay_page").length - 1 );

	if( typeof overlay_transaction_browse_validation != 'function' )
	{
		
		window.overlay_transaction_browse_validation = function ()
		{
		
			if ( $(".transaction_browse_material.selected").length > 0 )
			{
				overlay_valid( true );
			}
		
		}
		
	}
	
-->
</script>