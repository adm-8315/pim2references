( function ($) {
	
	overlay_setup['overlay'] = {
		"title": "Transaction",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material",
					1: "#overlay_material_category",
					2: "#overlay_pageCount",
					3: "#overlay_location",
					4: "#overlay_owner"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/inventory_transaction/screens/transactionType.php",
				"validation": "overlay_transaction_transactionType_validation",
				"toSend": {
					0: "#transaction_transactionType_material",
					1: "#transaction_transactionType_material_category",
					2: "#transaction_transactionType_transactionType",
					3: "#transaction_transactionType_pageCount",
					4: "#overlay_owner",
					5: "#overlay_location"
				}
			}, { 
				"id" : 2, 
				"url": "overlay/inventory_transaction/screens/transaction.php",
				"validation": "overlay_transaction_transaction_validation",
				"toSend": {
					0: "#transaction_transaction_transactionType",
					1: "#transaction_transaction_material",
					2: "#transaction_transaction_material_category",
					3: "#transaction_transaction_form_date",
					4: "#transaction_transaction_form_materialType",
					5: "#transaction_transaction_form_manufacturer",
					6: "#transaction_transaction_form_material",
					7: "#transaction_transaction_form_quantity",
					8: "#transaction_transaction_form_unit",
					9: "#transaction_transaction_form_cost",
					10: "#overlay_owner",
					11: "#overlay_location",
					12: "#transaction_transaction_form_owner_to",
					13: "#transaction_transaction_form_location_to",
					14: "#transaction_transaction_form_customer",
					15: "#transaction_transaction_form_customer_location",
					16: "#transaction_transaction_form_note"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 3, 
				"url": "overlay/inventory_transaction/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".transaction_button", function () {
			
			$("#overlay_material").val( $(this).attr("data-material") );
			$("#overlay_owner").val( $(this).attr("data-owner") );
			$("#overlay_location").val( $(this).attr("data-location") );
			
			overlay_open = 'overlay';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);