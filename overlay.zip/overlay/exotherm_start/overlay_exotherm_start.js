( function ($) {
	
	overlay_setup['exotherm_start'] = {
		"title": "Start Exothermal Test",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: '#startSlot'
				}
			}, { 
				"id" : 1, 
				"url": "overlay/exotherm_start/screens/exotherm_start.php",
				"toSend": {
					0: '#startSlot',
					2: '#exotherm_start_material',
					3: '#exotherm_start_water',
					4: '#exotherm_start_mix',
					5: '#exotherm_start_vib',
					6: '#exotherm_start_lotcode',
					7: '#exotherm_start_materialType',
					8: '#exotherm_start_materialNew',
					9: '#exotherm_start_measure',
					10: '#exotherm_start_newMaterialRadio'
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/exotherm_start/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".startButton", function () {
			$("#startSlot").val( $(this).data('id') );
			overlay_open = 'exotherm_start';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);