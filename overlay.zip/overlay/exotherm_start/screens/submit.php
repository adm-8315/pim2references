<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	date_default_timezone_set( 'America/Detroit' );
	$result = array();
		
	
	/**
	 * MySQL
	 */
	
	// New Material
	
	if ( intval($_POST['exotherm_start_newMaterialRadio']) )
	{
		
		$query = "
			INSERT INTO 
				material 
				( materialType, cost, measure, material )
			VALUES
				( ?, ?, ?, ? )
		";
		
		$values = array(
			$_POST['exotherm_start_materialType'],
			0.00,
			$_POST['exotherm_start_measure'],
			$_POST['exotherm_start_materialNew']
		);
		
		$result['newMaterial'] = dbquery( $query, $values );
		
	}
	
	// Start Test
	
	$query = '
		INSERT INTO 
			qcTest
			( slot, startTime, stopTime, material, water, mix, vib, lotcode)
		VALUES
			( ?, NOW(), NOW() + INTERVAL 18 HOUR, ?, ?, ?, ?, ? );
	';
	
	$values = array();
	$values[] = intval( $_POST['startSlot'] );
	
	if ( intval($_POST['exotherm_start_newMaterialRadio']) )
	{
		$values[] = $result['newMaterial'];
	}
	else
	{
		$values[] = intval( $_POST['exotherm_start_material'] );
	}
	
	$values[] = $_POST['exotherm_start_water'];
	$values[] = $_POST['exotherm_start_mix'];
	$values[] = $_POST['exotherm_start_vib'];
	$values[] = $_POST['exotherm_start_lotcode'];
	
	$result['start'] = dbquery( $query, $values );
		
		
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Test Started</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
		
		margin-top: 30px;
	}
</style>