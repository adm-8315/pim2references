<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Material
	
	$query = '
		SELECT
			m.materialID,
			m.material
		FROM
			material m
		WHERE
			m.materialType = 11
		OR
			m.materialType = 12
		OR
			m.materialType = 13
		OR
			m.materialType = 18
		OR
			m.materialType = 34
		ORDER BY
			material ASC
	';
	
	$values = array();
	
	$result['material'] = dbquery( $query, $values );
	
	
	// Material Type
	
	$query = '
		SELECT
			*
		FROM
			materialType mt
		WHERE
			mt.materialTypeID = 11
		OR
			mt.materialTypeID = 12
		OR
			mt.materialTypeID = 13
		OR
			mt.materialTypeID = 18
		OR
			mt.materialTypeID = 34
		ORDER BY
			mt.materialType ASC
	';
	
	$values = array();
	
	$result['materialType'] = dbquery( $query, $values );
	
	
	// Measure
	
	$query = '
		SELECT
			me.measureID,
			me.measurePlural as "measure"
		FROM
			measure me
		ORDER BY
			me.measurePlural ASC
	';
	
	$values = array();
	
	$result['measure'] = dbquery( $query, $values );
	
	

?>
<div class='transaction_transaction_container'>
	
	<table id='exotherm_start_table'>

		<tr>
			<td class='left'>Slot</td>
			<td class='right'>
				<?php echo $_POST['startSlot'] + 1; ?>
				<input type='hidden' id='exotherm_start_slot' value='<?php echo $_POST['startSlot'] + 1; ?>' />
			</td>
		</tr>
		
		<tr>
			<td class='left'>New Material</td>
			<td class='right'>
				<input type="radio" name="new" value="0" checked='checked'><span class='valignmiddle'>No</span>&nbsp;&nbsp;
				<input type="radio" name="new" value="1"><span class='valignmiddle'>Yes</span>
				<input type='hidden' id='exotherm_start_newMaterialRadio' value='0' />
			</td>
		</tr>
		
		<tr class='newMaterial'>
			<td class='left'>Material Type</td>
			<td class='right'>
				
				<select id='exotherm_start_materialType'>
					<option value='-1'>Choose...</option>
					<?php
					
					foreach( $result['materialType'] as $row )
					{
						echo "<option value='{$row['materialTypeID']}'>{$row['materialType']}</option>";
					}
					
					?>
				</select>
			</td>
		</tr>
		
		<tr class='oldMaterial'>
			<td class='left'>Material</td>
			<td class='right'>
				
				<select id='exotherm_start_material'>
					<option value='-1'>Choose...</option>
					<?php
					
					foreach( $result['material'] as $row )
					{
						echo "<option value='{$row['materialID']}'>{$row['material']}</option>";
					}
					
					?>
				</select>
			</td>
		</tr>
		
		<tr class='newMaterial'>
			<td class='left'>Material</td>
			<td class='right'><input type='text' id='exotherm_start_materialNew' /></td>
		</tr>
		
		<tr class='newMaterial'>
			<td class='left'>Measure</td>
			<td class='right'>
				
				<select id='exotherm_start_measure'>
					<?php
					
					foreach( $result['measure'] as $row )
					{
						
						if ( $row['measureID'] == 5 )
						{
							echo "<option value='{$row['measureID']}' selected='selected'>{$row['measure']}</option>";
						}
						else
						{
							echo "<option value='{$row['measureID']}'>{$row['measure']}</option>";
						}
						
					}
					
					?>
				</select>
			</td>
		</tr>
		
		<tr>
			<td class='left'>Lot Code</td>
			<td class='right'><input type='text' id='exotherm_start_lotcode' /></td>
		</tr>
		
		<tr>
			<td class='left'>Water</td>
			<td class='right'><input type='text' id='exotherm_start_water' /></td>
		</tr>
		
		<tr>
			<td class='left'>Mix Time</td>
			<td class='right'><input type='text' id='exotherm_start_mix' /></td>
		</tr>
		
		<tr>
			<td class='left'>Vib. Time</td>
			<td class='right'><input type='text' id='exotherm_start_vib' /></td>
		</tr>

	</table>
	
	

</div>

<script>

	$("input:radio[name=new]").on('change', function () {
		$("#exotherm_start_newMaterialRadio").val( $("input:radio[name=new]:checked").val() );
	});
	
	if( typeof overlay_exotherm_start_validation != 'function' )
	{
		
		var keyupString = '';
		var changeString = '';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_exotherm_start_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_exotherm_start_validation();
		});
		
		$(document).on("change", "input[name='new']", function () {
			if ( $("input[name='new']:checked").val() == 0 )
			{
				$(".newMaterial").hide();
				$(".oldMaterial").show();
			}
			else
			{
				$(".newMaterial").show();
				$(".oldMaterial").hide();
			}
		});
		
		window.overlay_exotherm_start_validation = function ()
		{
		   overlay_valid(true);
		}
		
	}


</script>

<style>
	
#exotherm_start_table {
	margin: 0 auto;
	margin-top: 25px;
}

#exotherm_start_table td.left {
	font-weight: 800;
}

#exotherm_start_table td.right {
	padding: 1px;
	height: 30px !important;
}

#exotherm_start_table td.right select,
#exotherm_start_table td.right input {
	margin-top: 5px;
}

#exotherm_start_table input[type='radio'] {
	margin-top: 0px !important;
}

.valignmiddle {
	vertical-align: bottom;
	line-height: 13px;
	margin-left: 5px;
}
	
.newMaterial {
	display: none;
}
	
</style>

