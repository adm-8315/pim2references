( function ($) {
	
	overlay_setup['schedule_batching'] = {
		"title": "Batching",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [ 
			{
				"id": 0,
				"toSend": {
					0: "#overlay_schedule_batching",
					1: "#overlay_schedule_batching_hour"
				}
			}, {
				"id": 1,
				"url": "overlay/schedule_batching/screens/schedule_batching.php",
				"validation": "overlay_schedule_batching_validation",
				"toSend": {
					//0: "#overlay_schedule_day",
					0: "#overlay_date",
					1: "#overlay_schedule_batching"
				}
			}, {
				"id": 2,
				"url": "overlay/schedule_batching/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".hour_headers button", function () {
			
			if ( $("#overlay_schedule_batching_hour").length == 0 )
			{
				$("body").append( $('<input/>',{type:'hidden',id:'overlay_schedule_batching_hour'}) );
			}
			
			$("#overlay_schedule_batching_hour").val( $(this).parent().parent().attr("id") );
			
			window.overlay_schedule_pour_validation = null;
					
			overlay_open = 'schedule_batching';
			overlay_create( overlay_setup[overlay_open] );
			
			$(".overlay_button").addClass("overlaySwitch");
			$(".overlay_button.back").addClass("active");
			
		});
		
		$(document).on( "click", ".overlay_button.back.overlaySwitch", function () 
		{
			
			$(".overlay_button").removeClass("overlaySwitch");
			$(".overlay_button.back").removeClass('active');
			window.overlay_schedule_batching_backButton();
		
		});
		
		$(document).on( "click", ".overlay_button.forward.overlaySwitch", function () 
		{
						
			var batchingHour = $("#overlay_schedule_batching_hour").val();
			var temp = $.parseJSON( $("#overlay_schedule_batching").val() );
			
			temp[batchingHour]['batching'] = {};
			
			$(".batch").each( function() {
				
				var batchID = $(this).attr("data-batchid");
				
				temp[batchingHour]['batching'][batchID] = {};
				temp[batchingHour]['batching'][batchID]['mixer'] = $(this).find("select").val();
				temp[batchingHour]['batching'][batchID]['material'] = {};
				
				$(this).find("input").each( function () {
					temp[batchingHour][ 'batching' ][ batchID ]['material'][ $(this).attr("data-material") ] = $(this).val();
				});
				
			});
			
			$("#overlay_schedule_batching").val( JSON.stringify( temp ) ); 
			
		});
		
		
		
	});
	
})(jQuery);