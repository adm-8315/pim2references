<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/permissions.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	$materials = json_decode( $_POST['overlay_schedule_batching'], true );
	if ( 
		! empty( $materials ) && 
		! empty( $materials[ $_POST['overlay_schedule_batching_hour'] ] )
	) {
		$materials = $materials[$_POST['overlay_schedule_batching_hour']]['productionOrder'];
	}
	
	$totalMaterial = 0;
	$totalPieceMaterial = 0;
	$materialPercentage = array();
				
		
	/**
	 * MySQL
	 */
	
	// Materials
	
	$values = array();
	
	$query = "
		SELECT
			m.materialID,
			m.material,
			poml.quantity
		FROM
			productionOrderMaterialLink poml
		LEFT JOIN
			material m
			ON poml.material = m.materialID
		WHERE
			(
				m.materialType = 11
				OR m.materialType = 12
				OR m.materialType = 13
				OR m.materialType = 20
				OR m.materialType = 32
				OR m.materialType = 34
			)
	";
	
	if ( count( $materials ) > 0 )
	{
		$query .= "AND (";
		
		foreach ( $materials as $materialID => $materialAmount )
		{
		
			$totalMaterial += $materialAmount;
		
			$query .= "poml.productionOrder = ? OR ";
			$values[] = $materialID;
		
		}
	
		$query = substr( $query, 0, -4 );
		
		$query .= ")";
	}
	
	
	
	$query .= " 
		GROUP BY
			m.materialID
		ORDER BY
			poml.quantity DESC
	";
	
	$result['materials'] = dbquery( $query, $values );
	
	
	// Mixers
	
	$query = "
		SELECT
			*
		FROM
			mixer mix
		WHERE
			mix.active = 1
		ORDER BY
			mix.mixerMax DESC
	";
	
	$result['mixers'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	foreach ( $result['materials'] as $row )
	{
		$totalPieceMaterial += $row['quantity'];
	}
	
	foreach ( $result['materials'] as $row )
	{
		$materialPercentage[$row['materialID']] = $row['quantity'] / $totalPieceMaterial;
	}
	
	
	/**
	 * Display
	 */	

?>


<div class='transaction_transaction_container' id='overlay_batch_container'>
		
</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	    height: 400px;
	    overflow: scroll;
	}

	.transaction_transaction_container table {
		margin: 0 auto;
		margin-top: 30px;
	}
	
	.transaction_transaction_container td {		
		width: 100px;
		
		margin-bottom: 10px;
		margin-left: 20px;
		
		text-align: left;
		line-height: 20px;
		vertical-align: top;
	}
	
	.transaction_transaction_container td input {
		width: 200px;
	}
	
	.transaction_transaction_container td select {
		width: 214px;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
	.batch_header {
		margin-top: 30px;
		font-weight: 800;
	}
	
	.batch table {
		margin-top: 10px;
	}
	
</style>

<script>

	( function ($) {
				
		var batchIndex = 0;
		var totalMaterial = <?php echo $totalMaterial; ?>;
		var mixers = <?php echo json_encode( $result['mixers'] ); ?>;
		var materials = <?php echo json_encode( $result['materials'] ); ?>;
		var materialPercentage = <?php echo json_encode( $materialPercentage ); ?>;
		
		$(".overlay_button.forward").removeClass("complete");
						
		$(document).on( "change", ".batch select", function () {
			overlay_schedule_batching_mixerChange();
			overlay_schedule_batching_materialMaxes();
			overlay_schedule_batching_amounts( parseInt( $(this).attr("data-batchid") ), true );
			//overlay_schedule_batching_validation();
		});
		
		$(document).on( "keyup change", ".batch input", function () {
			overlay_schedule_batching_balance( $(this) );
			overlay_schedule_batching_amounts( parseInt( $(this).attr("data-batchid") ) );
			//overlay_schedule_batching_validation();
		});
		
		window.overlay_schedule_batching_addBatch = function () 
		{
							
			if ( $(".batch:last-of-type").length == 0 )
			{
				batchIndex = 1;
			}
			else
			{
				batchIndex = parseInt( $(".batch:last-of-type").attr("data-batchid") ) + 1;
			}
							
			$("#overlay_batch_container").append( "<div data-batchid='" + batchIndex + "' class='batch'></div>" );
			
			var selectedBatch = $(".batch[data-batchid='" + batchIndex + "']");
			selectedBatch.append( "<div class='batch_header'>Batch " + batchIndex + "</div>");
			selectedBatch.append( "<table></table>");
			selectedBatch.find("table").append( "<tr><td>Mixer</td></tr>");
			selectedBatch.find("tr:last-of-type").append( "<td><select data-batchid='" + batchIndex + "'></select></td>");
			
			for ( var key in mixers ) 
			{
				selectedBatch.find("select").append("<option data-mixermax='" + mixers[key]['mixerMax'] + "' value='" + mixers[key]['mixerID'] + "'>" + mixers[key]['mixer'] + "</option>" );
			}
			
			for ( var key in materials )
			{
				selectedBatch.find("table").append( "<tr><td>" + materials[key]['material'] + "</td></tr>");
				selectedBatch.find("tr:last-of-type").append( "<td><input data-batchid='" + batchIndex + "' data-material='" + materials[key]['materialID'] + "' type='number' min='0' /></td>");
			}
			
		}
		
		window.overlay_schedule_batching_removeBatch = function () 
		{
				
			batchIndex--;
			$(".batch:last-of-type").remove();
			
		}
		
		window.overlay_schedule_batching_materialMaxes = function () 
		{
			
			$(".batch input").each( function () {
				
				var batchMaterialAmount = $(".batch[data-batchid='" + $(this).attr("data-batchid") + "'] select option:selected").attr("data-mixerMax");
				var materialPercentageTemp = materialPercentage[ $(this).attr("data-material") ];
				
				if ( batchMaterialAmount > totalMaterial )
				{
					batchMaterialAmount = totalMaterial;
				}
									
				$(this).prop( "max", Math.round( batchMaterialAmount * materialPercentageTemp ) );
			});
			
		}
		
		window.overlay_schedule_batching_mixerChange = function () 
		{
							
			var maxMixerMaterial = 0;
		
			$(".batch select option:selected").each( function () {
				maxMixerMaterial += parseInt( $(this).attr("data-mixermax") );
			});
			
			// Add batches if needed
			while ( maxMixerMaterial < totalMaterial )
			{
									
				overlay_schedule_batching_addBatch();
				
				maxMixerMaterial += parseInt( mixers[0]['mixerMax'] );
				
			}
			
			// Remove batches if needed
			while ( ( maxMixerMaterial - parseInt( $(".batch:last-of-type select option:selected").attr('data-mixermax') ) ) > totalMaterial )
			{
									
				overlay_schedule_batching_removeBatch();
				
				maxMixerMaterial = 0;
				
				$(".batch select option:selected").each( function () {
					maxMixerMaterial += parseInt( $(this).attr("data-mixermax") );
				});
				
			}
			
		}
		
		window.overlay_schedule_batching_balance = function ( trigger )
		{
			
			var batchMaterialAmount = trigger.val() / materialPercentage[trigger.attr("data-material")];
			var currentTotal = 0;
			
			$(".batch[data-batchid='" + trigger.attr("data-batchid") + "'] input").each( function () {
				$(this).val( Math.round( batchMaterialAmount * materialPercentage[ parseInt( $(this).attr('data-material') ) ] ) );
			});
			
			currentTotal = $(".batch input").val();
			
			window.overlay_schedule_batching_validation();
			
		}
		
		window.overlay_schedule_batching_amounts = function ( triggerIndex, include )
		{
			
			var batchMaterialAmount = 0;
			var protectedMaterial = 0;
			var materialToBatch = totalMaterial;
			var maxMixerMaterial = parseInt( $(".batch[data-batchid='" + triggerIndex + "'] select option:selected").attr("data-mixerMax") );
			var loopIndex = triggerIndex + 1;
							
			if ( include !== undefined )
			{
				loopIndex = triggerIndex;
			}
			
			// Protected Material
			
			$(".batch input").filter( function () {
				if ( include !== undefined )
				{
					return $(this).attr("data-batchid") < triggerIndex;
				}
				else
				{
					return $(this).attr("data-batchid") <= triggerIndex;
				}
			}).each( function () {
				protectedMaterial += parseInt( $(this).val() );
			});
			
			materialToBatch -= protectedMaterial;
			
			while ( materialToBatch > 0 )
			{
				
				if ( $(".batch[data-batchid='" + loopIndex + "']").length === 0 )
				{
					overlay_schedule_batching_addBatch();
				}
									
				maxMixerMaterial = parseInt( $(".batch[data-batchid='" + loopIndex + "'] select option:selected").attr("data-mixerMax") ); 
				
				if ( maxMixerMaterial > materialToBatch )
				{
					batchMaterialAmount = materialToBatch;
				}
				else
				{
					batchMaterialAmount = maxMixerMaterial;
				}
									
				$(".batch[data-batchid='" + loopIndex + "'] input").each( function () {
					$(this).val( Math.round( batchMaterialAmount * materialPercentage[ parseInt( $(this).attr('data-material') ) ] ) );
				});
				
				materialToBatch -= batchMaterialAmount;
				loopIndex++;
				
			}
			
			if ( $(".batch[data-batchid='" + loopIndex + "']").length !== 0 )
			{
				overlay_schedule_batching_removeBatch();
			}
			
		}
		
		window.overlay_schedule_batching_init = function () 
		{
						
			overlay_schedule_batching_amounts(1, true);
			overlay_schedule_batching_materialMaxes();
			
		}
	
		
		

		if( typeof overlay_schedule_batching_validation != 'function' )
		{	
			
			window.overlay_schedule_batching_backButton = function () 
			{
				
				overlay_show(false);
				overlay_open = 'schedule_pour';
				overlay_create_skip( overlay_setup[overlay_open], 2 );
			
			}
	
			window.overlay_schedule_batching_validation = function ()
			{
				
				<?php 
					if ( isset($permissions[1][1]) )
					{ 
						echo "overlay_valid(true);";
					}
					else
					{
						echo "
							var valid = true;
						
							$('.batch input[type=\"number\"]').each( function () { 
								if ( 
									parseInt( $(this).attr('min') ) >= parseInt( $(this).val()       ) ||
									parseInt( $(this).val()       ) >  parseInt( $(this).attr('max') ) 
								) {
									valid = false;
									console.log($(this));
								}
							});
							
							if ( valid )
							{
								overlay_valid(true);
							}
							else
							{
								overlay_valid(false);
							}
							
							";
					}
				?>
				
			}
	
		}
		
		
		$(document).ready( function () {
			window.overlay_schedule_batching_init();
			window.overlay_schedule_batching_validation();
		});
		
		
	
	})(jQuery);

</script>