<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/functions/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
		
	/**
	 * MySQL
	 */
	
	// Production Order
	
	$query = "
		INSERT INTO 
			productionOrderScheduleBatching 
			( pourDate, batchingString ) 
		VALUES 
			( ?, ? )
		ON DUPLICATE KEY UPDATE 
			batchingString = ?;
	";
	
	$values = array(
		//date_to_mysql( $_POST['overlay_schedule_day'] ),
		date_to_mysql( $_POST['overlay_date'] ),
		$_POST['overlay_schedule_batching'],
		$_POST['overlay_schedule_batching']
	);
	
	$result['add'] = dbquery( $query, $values );
	
	//print_r( $_POST['overlay_schedule_batching'] );

?>

<script>
	
	$(".overlay_button").removeClass("overlaySwitch");
	
	overlay_show(false);

	//overlay_open = 'schedule_print';
	//overlay_create( overlay_setup[overlay_open] );
	overlay_open = 'schedule_pour';
	overlay_create_skip( overlay_setup[overlay_open], 1 );
	
</script>