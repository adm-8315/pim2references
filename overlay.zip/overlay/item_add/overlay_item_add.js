( function ($) {
	
	overlay_setup['item_add'] = {
		"title": "Add Item",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/item_add/screens/item_add.php",
				"validation": "overlay_item_add_validation",
				"toSend": {
					0: "#add_item_name",
					1: "#add_item_type",
					4: "#add_item_stock"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/item_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_item']", function () {
			overlay_open = 'item_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);