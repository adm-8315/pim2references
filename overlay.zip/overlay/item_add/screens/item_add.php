<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	
	// Item Type
	
	$query = "
		SELECT
			*
		FROM
			itemType et
		ORDER BY
			et.itemType 
	";
	
	$values = array();
	
	$result['itemType'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id="add_item_table">
	
	<tr>
		<td class="left">Name</td>
		<td class="right"><input type="text" id="add_item_name" value="" /></td>
	</tr>
	
	<tr>
		<td class="left">Type</td>
		<td class="right">
			<select id="add_item_type">
				<option value='-1'>Choose...</option>
				<?php
				
					foreach ( $result['itemType'] as $row )
					{
						echo "<option value='" . $row['itemTypeID'] . "'>" . $row['itemType'] . "</option>";
					}
					
				?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Stock</td>
		<td class="right"><input type="number" id="add_item_stock" value="" /></td>
	</tr>
	
	
	
</table>

<style>

#add_item_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_add_item_validation != 'function' )
	{
	
		var keyupString = '#add_item_name';
		var changeString = '#add_item_type';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_add_item_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_add_item_validation();
		});
	
		window.overlay_add_item_validation = function ()
		{
			if ( 
				$("#add_item_name").val() != "" &&
				$("#add_item_type").val() != -1
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_add_item_validation();
	
	}

</script>