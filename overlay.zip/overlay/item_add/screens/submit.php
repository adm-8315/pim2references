<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset($_POST['add_item_name']) && $_POST['add_item_name'] != '' )
	{	
		
		// Item
		
		$query = "
			INSERT
				INTO item
				( item, itemType )
				VALUES
				( ?, ? )
		";
		
		$values = array(
			$_POST['add_item_name'],
			$_POST['add_item_type'],	
		);
		
		$result['item'] = dbquery( $query, $values );
		
		
		// Set Stock Level
		
		$query = "
			INSERT 
				INTO itemInventory 
				( item, location, stock )
				VALUES
				( ?, ?, ? )
		";
		
		$values = array(
			$result['item'],
			1,
			$_POST['add_item_stock']
		);

		$result['itemInventoryInsert'] = dbquery( $query, $values );
		
	}
	
	
	/**
	 * Display
	 */
	
	if ( $result['itemInventoryInsert'] )
	{
		echo $_POST['add_item_name'] . " was added successfully.";
	}
	else
	{
		echo "There was a problem adding the item.";
	}

?>