( function ($) {
	
	overlay_setup['adjust'] = {
		"title": "",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_material",
					1: "#overlay_owner",
					2: "#overlay_location",
					3: "#overlay_material_category"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/material_edit_inventory/screens/material_edit_inventory.php",
				"toSend": {
					0: "#overlay_material",
					1: "#overlay_owner",
					2: "#overlay_location",
					3: "#transaction_transaction_form_date",
					4: "#transaction_transaction_form_adjust",
					5: "#transaction_transaction_form_note",
					6: "#transaction_transaction_form_warning",
					7: "#overlay_material_category"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/material_edit_inventory/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".adjust_button", function () {
			
			$("#overlay_owner").val( $(this).attr("data-owner") );
			$("#overlay_location").val( $(this).attr("data-location") );
			
			overlay_open = 'adjust';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);