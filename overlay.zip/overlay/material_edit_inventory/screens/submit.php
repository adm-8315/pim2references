<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/functions/date_conversion.php");
	require_once("../../../inc/functions/update_materialInventory.php");
	require_once("../../../inc/functions/update_productInventory.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	$companyID = $_POST['overlay_owner'];
	$locationID = $_POST['overlay_location'];
	
	$companyLocationLinkQuery = "SELECT companyLocationLinkID FROM companyLocationLink where company=$companyID and location=$locationID;";
	$companyLocationLinkID = dbquery_row($companyLocationLinkQuery)['companyLocationLinkID'];
	
	
	/**
	 * MySQL
	 */
	
	if ( $_POST['overlay_material_category'] == '1' )
	{
	
		// Material Inventory Insert
	
		$query = "
			INSERT INTO
				materialInventory
			( material, companyLocationLink, stockLevelWarning )
			VALUES
			( ?, ?, ? )
			ON DUPLICATE KEY UPDATE
				stockLevelWarning = ?
		";

		$values = array(
			$_POST['overlay_material'],
			//FLOOR( .5 * ($_POST['overlay_location'] + $_POST['overlay_owner']) * ($_POST['overlay_location'] + $_POST['overlay_owner'] + 1) + $_POST['overlay_owner'] ),
			$companyLocationLinkID,
			$_POST['transaction_transaction_form_warning'],
			$_POST['transaction_transaction_form_warning']
		);

		$result['materialInventoryInsert'] = dbquery( $query, $values );
	
	
		// Material Inventory
	
		$query = "
			SELECT
				i.materialInventoryID,
				i.stock,
				i.stockLevelWarning
			FROM
				materialInventory i
			WHERE
				i.material = ?
			AND
				i.companyLocationLink = ?
		";

		$values = array(
			$_POST['overlay_material'],
			//FLOOR( .5 * ($_POST['overlay_location'] + $_POST['overlay_owner']) * ($_POST['overlay_location'] + $_POST['overlay_owner'] + 1) + $_POST['overlay_owner'] )
			$companyLocationLinkID
		);

		$result['materialInventory'] = dbquery( $query, $values );
	
	
		// Transaction Insert
	
		if ( $result['materialInventory'][0]['stock'] != $_POST['transaction_transaction_form_adjust'] )
		{
	
			$query = "
				INSERT INTO
					materialTransaction
				( materialInventory, transactionType, value, user, timestamp, notes )
				VALUES
				( ?, 7, ?, ?, ?, ? )
			";

			$values = array(
				$result['materialInventory'][0]['materialInventoryID'],
				$_POST['transaction_transaction_form_adjust'],
				$_SESSION['user_id'],
				date_to_mysql( $_POST['transaction_transaction_form_date'] ),
				$_POST['transaction_transaction_form_note']
			);

			$result['transactionInsert'] = dbquery( $query, $values );
	
		}
	
		update_materialInventory();
		
	}
	else if ( $_POST['overlay_material_category'] == '2' )
	{
		
		// Product Inventory Insert
	
		$query = "
			INSERT INTO
				productInventory
			( product, companyLocationLink, stockLevelWarning )
			VALUES
			( ?, ?, ? )
			ON DUPLICATE KEY UPDATE
				stockLevelWarning = ?
		";

		$values = array(
			$_POST['overlay_material'],
			//FLOOR( .5 * ($_POST['overlay_location'] + $_POST['overlay_owner']) * ($_POST['overlay_location'] + $_POST['overlay_owner'] + 1) + $_POST['overlay_owner'] ),
			$companyLocationLinkID, 
			$_POST['transaction_transaction_form_warning'],
			$_POST['transaction_transaction_form_warning']
		);


		$result['productInventoryInsert'] = dbquery( $query, $values );
	
		// Product Inventory
	
		$query = "
			SELECT
				i.productInventoryID,
				i.stock,
				i.stockLevelWarning
			FROM
				productInventory i
			WHERE
				i.product = ?
			AND
				i.companyLocationLink = ?
		";

		$values = array(
			$_POST['overlay_material'],
			//FLOOR( .5 * ($_POST['overlay_location'] + $_POST['overlay_owner']) * ($_POST['overlay_location'] + $_POST['overlay_owner'] + 1) + $_POST['overlay_owner'] )
			$companyLocationLinkID
		);

		$result['productInventory'] = dbquery( $query, $values );      

		// Transaction Insert
	
		if ( $result['productInventory'][0]['stock'] != $_POST['transaction_transaction_form_adjust'] )
		{
	
			$query = "
				INSERT INTO
					productTransaction
				( productInventory, transactionType, value, user, timestamp, notes )
				VALUES
				( ?, 7, ?, ?, ?, ? )
			";

			$values = array(
				$result['productInventory'][0]['productInventoryID'],
				$_POST['transaction_transaction_form_adjust'],
				$_SESSION['user_id'],
				date_to_mysql( $_POST['transaction_transaction_form_date'] ),
				$_POST['transaction_transaction_form_note']
			);

			$result['transactionInsert'] = dbquery( $query, $values );
	
		}
		
		update_productInventory();
		
	}
	
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Transaction Recorded</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
	}
</style>