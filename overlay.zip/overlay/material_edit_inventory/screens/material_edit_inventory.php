<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../../../inc/dbfunc.php" );
	require_once( "../../../inc/session.php" );
	require_once("../../../inc/permissions.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( $_POST['overlay_material_category'] == '1' )
	{
		
		$query = "
			SELECT
				m.material
			FROM
				material m
			WHERE
				m.materialID = ?
		";
	
		$values = array(
			$_POST['overlay_material']
		);
	
		$result['material'] = dbquery( $query, $values );
		
	}
	else if ( $_POST['overlay_material_category'] == '2' )
	{
		
		$query = "
			SELECT
				p.product as 'material'
			FROM
				product p
			WHERE
				p.productID = ?
		";
	
		$values = array(
			$_POST['overlay_material']
		);
	
		$result['material'] = dbquery( $query, $values );
		
	}
	
	
	$query = "
		SELECT
			c.company
		FROM
			company c
		WHERE
			c.companyID = ?
	";
	
	$values = array(
		$_POST['overlay_owner']
	);
	
	$result['owner'] = dbquery( $query, $values );
	
	
	$query = "
		SELECT
			l.location
		FROM
			location l
		WHERE
			l.locationID = ?
	";
	
	$values = array(
		$_POST['overlay_location']
	);
	
	$result['location'] = dbquery( $query, $values );
	
	
	if ( $_POST['overlay_material_category'] == '1' )
	{
	
		$query = "
			SELECT
				i.stock,
				i.stockLevelWarning
			FROM
				materialInventory i
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			WHERE
				cll.company = ?
			AND
				cll.location = ?
			AND
				i.material = ?
		";
	
		$values = array(
			$_POST['overlay_owner'],
			$_POST['overlay_location'],
			$_POST['overlay_material']
		);
	
		$result['inventory'] = dbquery( $query, $values );
		
	}
	else if ( $_POST['overlay_material_category'] == '2' )
	{
		
		$query = "
			SELECT
				i.stock,
				i.stockLevelWarning
			FROM
				productInventory i
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			WHERE
				cll.company = ?
			AND
				cll.location = ?
			AND
				i.product = ?
		";
	
		$values = array(
			$_POST['overlay_owner'],
			$_POST['overlay_location'],
			$_POST['overlay_material']
		);
	
		$result['inventory'] = dbquery( $query, $values );
		
	}
	
	/**
	 * Normalization
	 */
	
	if ( empty( $result['inventory'] ) )
	{
		$result['inventory'][0]['stock'] = 0;
	}

?>
<div class='transaction_transaction_container'>
	
	<input type='hidden' id="overlay_material_category" value="<?php echo $_POST['overlay_material_category']; ?>" >
	
	<h4>Transaction</h4>
	
	<div id='transaction_transaction_form_transationType'>Adjust</div>
	
	<div id="transaction_transaction_form_materialDisplay" data-material="<?php echo $_POST['overlay_material']; ?>"><?php echo $result['material'][0]['material']; ?></div>
	
	<div id="transaction_transaction_container">
		
		<?php

		if ( 
			isset( $permissions[1][1] ) ||
			isset( $permissions[2][18] ) 
		) {

		?>

		<label>Owner</label>
		<div id="transaction_transaction_form_owner" class='field' data-owner="<?php echo $_POST['overlay_owner']; ?>"><?php echo $result['owner'][0]['company']; ?></div>
		<div class="clearMe">&nbsp;</div>
		
		<label>Date</label>
		<div class='field'>
			<input type='text' id='transaction_transaction_form_date' class='transaction_transaction_form_date overlay_date' />
			<button class='trigger'>Date</button>
		</div>
		<div class='clearMe'>&nbsp;</div>

		<label>Location</label>
		<div id="transaction_transaction_form_location" class='field'  data-location="<?php echo $_POST['overlay_location']; ?>"><?php echo $result['location'][0]['location']; ?></div>
		<div class="clearMe">&nbsp;</div>
		
		<br />

		<label>Stock</label>
		<div class='field'><input type='number' step='any' id="transaction_transaction_form_adjust" value="<?php echo $result['inventory'][0]['stock']; ?>" /></div>
		<div class="clearMe">&nbsp;</div>
		
		<label>Note</label>
		<div class='field'><input type='text' style="margin-top:5px" id="transaction_transaction_form_note" /></div>
		<div class="clearMe">&nbsp;</div>
		
		<br />
		<br />
		
		<?php
		
		}
		
		
		
		if ( 
			isset( $permissions[1][1] ) ||
			isset( $permissions[4][20] ) 
		) {
		
		?>
		
		<label>Stock Warning</label>
		<div class='field'><input type='number' step='any' id ="transaction_transaction_form_warning" value="<?php if ( ! empty( $result['inventory'][0]['stockLevelWarning'] ) ) { echo $result['inventory'][0]['stockLevelWarning']; } else { echo '0'; } ?>" /></div>
		<div class="clearMe">&nbsp;</div>
		
		<?php
		
		}
		
		?>
	
	</div>

</div>

<script>

	( function ($) {
		
		$("#screen_overlay_content")
			.find(".transaction_transaction_form_date")
			.on("change", function () {
				updateDate();
			});
			
		// Validation

		$("#screen_overlay_content")
			.find(".transaction_transaction_form_date")
			.mask('00-00-0000', {reverse: true});
			
		// Functions
		
		function updateDate () {
			myData = "dataMaterial=<?php echo $_POST['overlay_material']; ?>" +
				"&dataDate=" +
					$("#transaction_transaction_form_date").val() +
				"&dataLocation=<?php echo $_POST['overlay_location']; ?>" +
				"&dataOwner=<?php echo $_POST['overlay_owner']; ?>";
		
			request = $.ajax({
				<?php
				
					if ( $_POST['overlay_material_category'] == '1' )
					{
						echo "url: 'inventory/ajax/material_stock_on_date.php',";
					}
					else if ( $_POST['overlay_material_category'] == '2' )
					{
						echo "url: 'inventory/ajax/product_stock_on_date.php',";
					}
				
				?>
				
				type: "post",
				data: myData
			}).done( function ( response, textStatus, jqXHR) {
				$("#transaction_transaction_form_adjust").val( response );
			});
		}
			
	})(jQuery);

</script>
	
<script>

	$("#screen_overlay_content")
		.find(".transaction_transaction_form_date")
		.mask('00-00-0000', {
			reverse: true
		});
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		var keyupString = '#transaction_transaction_form_adjust, #transaction_transaction_form_warning';
		var changeString = '#transaction_transaction_form_adjust, #transaction_transaction_form_warning';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			// Validation Final	
			if (
				(
					$("#transaction_transaction_form_adjust").val() != <?php echo $result['inventory'][0]['stock']; ?> &&
					$("#transaction_transaction_form_adjust").val() != ""
				) 
				||
				(
					$("#transaction_transaction_form_warning").val() != <?php 
						if ( isset( $result['inventory'][0]['stockLevelWarning'] ) ) 
						{ 
							echo $result['inventory'][0]['stockLevelWarning']; 
						} 
						else 
						{ 
							echo "0"; 
						} 
					?> &&
					$("#transaction_transaction_form_warning").val() != ""
				)
			) {
			    overlay_valid(true);
			} else {
			    overlay_valid(false);
			}

		}
		
	}


</script>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container #transaction_transaction_container {
		width: 320px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 35px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container div.field {
		float: right;
		
		height: 20px;
		width: 200px;
		
		margin-bottom: 10px;
		
		text-align: left;
		line-height: 20px;
		
		vertical-align: top;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
		
	    margin-top: 0px;
	}
	
	.trigger {
		margin-top: -10px;
	}
	
	#transaction_transaction_form_adjust,
	#transaction_transaction_form_warning,
	.transaction_transaction_form_date {
		width: 100px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_adjust.display {
		width: 136px !important;
		
		margin-right: 10px;
	}
	
	#transaction_transaction_form_unit {
		width: 76px;
	}
	
	#transaction_transaction_form_unit.display {
		float: right;
		display: inline-block;
		
		width: 40px;
		
		line-height: 30px;
		text-align: right;
	}
	
	#transaction_transaction_form_note {
		width: 186px;
	}
	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>