<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$materials = json_decode( $_POST['productionOrder_material_values'], true );
	
	
	/**
	 * MySQL
	 */
	
	// Remove Links
	
	$query = "
		DELETE FROM
			productionOrderTemplateMaterialLink
		WHERE
			productionOrderTemplate = ?
	";
	
	$values = array(
		$_POST['overlay_order']
	);
	
	$result['removeLinks'] = dbquery( $query, $values );
	
	
	// Insert Links
	
	$values = array();
	
	$query = "
		INSERT INTO 
			productionOrderTemplateMaterialLink 
			( productionOrderTemplate, material, quantity, water, mixTime, vibrationType, vibrationTime )
		VALUES
	";
	
	foreach ( $materials as $key => $row )
	{
		
		if ( 
			$key == "notes" || 
			$row['material'] == '-1'
		) {
			continue;
		}
		
		$query .= "( ?, ?, ?, ?, ?, ?, ? ),";
		$values[] = $_POST['overlay_order'];
		$values[] = $row['material'];
		$values[] = $row['quantity'];
		if ( empty( $row['water'] ) )
		{
			$values[] = null;
		}
		else
		{
			$values[] = $row['water'];
		}
		
		if ( empty( $row['mix'] ) )
		{
			$values[] = null;
		}
		else
		{
			$values[] = $row['mix'];
		}
		
		if (
			empty( $row['vibType'] ) ||
			(
				! empty( $row['vibType'] ) &&
				$row['vibType'] == '-1'
			)
		) {
			$values[] = null;
		}
		else
		{
			$values[] = $row['vibType'];
		}
		
		if ( empty( $row['vibTime'] ) )
		{
			$values[] = null;
		}
		else
		{
			$values[] = $row['vibTime'];
		}
		
	}
	
	$query = substr( $query, 0, -1 );
	
	$result['productionOrderTemplateMaterials'] = dbquery( $query, $values );
	
	
	// Notes
	
	$query = "
		UPDATE
			productionOrderTemplate
		SET
			notes = ?
		WHERE
			productionOrderTemplateID = ?
	";
	
	$values = array(
		$materials['notes'],
		$_POST['overlay_order']
	);
	
	$result['notes'] = dbquery( $query, $values );
	
	/**
	 * Display
	 */
	

	echo "The production order details were updated.";
	
?>