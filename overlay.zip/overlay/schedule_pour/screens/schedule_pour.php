<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	require_once("../../../inc/session.php");
	require_once("../../../inc/permissions.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Open Orders
	
	$query = "
		SELECT
			po.productionOrderID,
			IF (
				temp.quantity is null,
				po.quantityOrdered,
				po.quantityOrdered - temp.quantity
			) as 'openOrders',
			CONCAT(MONTH(po.fillDate),' / ',DAY(po.fillDate),' / ',YEAR(po.fillDate)) as 'fillDate',
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			f.formQuantity,
			f.formPieces
		FROM
			productionOrder po
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			(
				SELECT
					pos.productionOrder,
					SUM(pos.quantity) as 'quantity'
				FROM
					productionOrderSchedule pos
				GROUP BY
					productionOrder
			) temp
			ON temp.productionOrder = po.productionOrderID
		LEFT JOIN
			formProductLink fpl
			ON p.productID = fpl.product
		LEFT JOIN
			form f
			ON fpl.form = f.formID
		WHERE
			(
				temp.quantity < po.quantityOrdered
			OR
				temp.quantity is null
			)
		AND
			po.active = 1
		ORDER BY
			po.fillDate DESC,
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) ASC
	";
	
	$values = array();
	
	$result['openOrders'] = dbquery( $query, $values );
	
	
	// Pour Schedule
	
	$query = "
		SELECT
			po.productionOrderID,
			pos.quantity,
			CONCAT(MONTH(po.fillDate),' / ',DAY(po.fillDate),' / ',YEAR(po.fillDate)) as 'fillDate',
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			f.formQuantity,
			f.formPieces,
			po.fillDate
		FROM
			productionOrderSchedule pos
		LEFT JOIN
			productionOrder po
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			formProductLink fpl
			ON p.productID = fpl.product
		LEFT JOIN
			form f
			ON fpl.form = f.formID
		WHERE
			pourDate = ?
	";
	
	$values = array(
		$_POST['overlay_date']
	);
	
	$result['pourSchedule'] = dbquery( $query, $values );
		
	/**
	 * Display
	 */

?>


<div class='transaction_transaction_container'>
	
	<input type='hidden' id='schedule_pour_date' value='<?php echo $_POST['overlay_date']; ?>'>
	
	<div class='schedule_open'>
		<h5>Open Orders</h5>
		<div class='product_container'>
			<table>
				
				<tr>
					<th class='product'>Product</th>
					<th></th>
					<th>Quantity</th>
					<th>Fill Date</th>
				</tr>
				
				<?php
				
				foreach( $result['openOrders'] as $row )
				{
					echo "<tr>";
					echo "<td class='alignLeft product' data-productionorder='{$row['productionOrderID']}'>{$row['product']}</td>";
					if ( strlen( $row['product'] ) > 22 )
					{
						echo "<td class='hover'><span data-title='{$row['product']}'></span></td>";
					}
					else
					{
						echo "<td class='hover'></td>";
					}
					echo "<td class='alignLeft quantity'>{$row['openOrders']}</td>";
					echo "<td class='alignCenter fillDate'>{$row['fillDate']}</td>";
					echo "</tr>";
				}
				
				?>
			</table>
		</div>
	</div
	><div class='schedule_pour'>
		<h5>Pour Schedule</h5>
		<div class='product_container'>
			<table>
				
				<tr>
					<th class='product'>Product</th>
					<th>Quantity</th>
				</tr>
				
				<?php
				
				foreach( $result['pourSchedule'] as $row )
				{
					echo "<tr>";
					echo "<td class='alignLeft product' data-productionorder='{$row['productionOrderID']}'>{$row['product']}</td>";
					if ( strlen( $row['product'] ) > 22 )
					{
						echo "<td class='hover'><span data-title='{$row['product']}'></span></td>";
					}
					else
					{
						echo "<td class='hover'></td>";
					}
					echo "<td class='alignLeft quantity'>{$row['quantity']}</td>";
					echo "<td class='alignCenter fillDate'>{$row['fillDate']}</td>";
					echo "</tr>";
				}
				
				?>
			</table>
		</div>
	</div>

</div>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.schedule_open,
	.schedule_pour {
		float: left;
		height: 320px;
	}
	
	.schedule_open {
		width: 55%;
		margin-left: 2%;
	}
	
	.schedule_pour {
		width: 40%;
	}
	
	.schedule_open {
		border-right: 1px solid #ccc;
	}
	
	.transaction_transaction_container h5 {
		color: #333;
		font-size: 14pt;
	}
	
	.alignLeft {
		text-align: left;
	}
	
	.alignRight {
		text-align: right;
	}
	
	.alignCenter {
		text-align: center;
	}
	
	td.product {
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		max-width: 150px;
	}
	
	.product_container {
		height: 320px;
		overflow: scroll;
	}
	
	.product_container table {
		border-spacing: 5px;
		border-collapse: separate;
	}
	
	.hover {
		position: relative;
	}
	
	td.product:hover ~ .hover span:after {
		position: absolute;
		display: inline-block;
		top: 20px;
		left: -158px;
		background: #333;
		background: rgba(0,0,0,1);
		border-radius: 5px;
		color: #fff;
		white-space: nowrap;
		content: attr(data-title);
		padding: 5px 15px;
		z-index: 9999;
		width: 230px;
	}
	
	.product_container tr:hover td.product {
		background: #ddd;
		cursor: pointer;
	}
	
	.ui-dialog {
	    z-index: 9999 !important;
	}
	
	.schedule_pour .hover,
	.schedule_pour .fillDate {
		display: none;
	}
	
	.mainButton {
		background: #4387fd !important;
		color: white !important;
	}

	
	
</style>

<script>

	if( typeof overlay_schedule_pour_validation != 'function' )
	{	
		
		var keyupString = '';
		var changeString = '';
		
		$(document).on("keyup", keyupString, function () {
			if (typeof window.overlay_schedule_pour_validation == 'function') { 
			  window.overlay_schedule_pour_validation(); 
			}
		});
	
		$(document).on("change", changeString, function () {
			if (typeof window.overlay_schedule_pour_validation == 'function') { 
			  window.overlay_schedule_pour_validation(); 
			}
		});
	
		window.overlay_schedule_pour_validation = function ()
		{
						
			if ( $('.schedule_pour .product_container table tbody tr').length > 1 )
			{
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		$(document).on("click", '.schedule_open td.product', function () {
			
			var target = $(this)
			
			if ( $('#dialog-confirm').length !== 0 )
			{
				$('#dialog-confirm').remove();
			}
			
			$("body").append( '<div id="dialog-confirm" title="Number of Pieces"><p><table><tr><td><label>Shape:</label></td><td>' + $(this).text() + '</td></tr><tr><td><label>Pieces:</label></td><td><input id="modalValue" type="number" min="1" value="1" style="text-align:right;"></td></tr></table></p></div>' );
		
			$( "#dialog-confirm" ).dialog({
				autoResize: true,
		      	modal: true,
		      	buttons: [{
						text: "Add",
						"class": "mainButton",
						click: function() {
							
							var quantity = 	parseInt( $("#modalValue").val() );
							var openOrders = parseInt( $(target).parent().find('.quantity').text() );
							
							if ( $('.schedule_pour td.product[data-productionorder="' + $(target).data('productionorder') + '"]').length == 0 )
							{
								var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
										"quantity=" + quantity + '&' +
										"pourDate=" + $("#schedule_pour_date").val();
																
								request = $.ajax({
									url: "ajax/schedule_add_pour.php",
									type: "post",
									data: ajaxData,
									global: false
								}).done( function ( response, textStatus, jqXHR) {
									
									var duplicate = $(target).parent().clone();
									$(duplicate).appendTo(".schedule_pour .product_container table tbody");
									$(".schedule_pour td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( quantity );
									
									$("div[data-date='" + $("#schedule_pour_date").val() + "'] .pour .product_scroll").append( $('<div/>',{"class":'productLine',"data-productionorder":$(target).data('productionorder'),"data-pourdate":$("#schedule_pour_date").val()}) );
									$("div[data-date='" + $("#schedule_pour_date").val() + "'] .pour .product_scroll .productLine[data-productionorder='" + $(target).data('productionorder') + "'][data-pourdate='" + $("#schedule_pour_date").val() + "']").text( $(target).text() );
									
									if ( quantity >= openOrders )
									{
										$(target).parent().remove();
									}
									else
									{
										$(target).parent().find('.quantity').text( $(target).parent().find('.quantity').text() - quantity );
									}
									
									window.overlay_schedule_pour_validation();
								});	
							}
							else
							{
								var currentVal = parseInt( $(".schedule_pour td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text() );
								var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
										"quantity=" + (quantity + currentVal) + '&' +
										"pourDate=" + $("#schedule_pour_date").val();
								
								request = $.ajax({
									url: "ajax/schedule_update_pour.php",
									type: "post",
									data: ajaxData,
									global: false
								}).done( function ( response, textStatus, jqXHR) {
									$(".schedule_pour td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( currentVal + quantity );
									if ( quantity >= openOrders )
									{
										$(target).parent().remove();
									}
									else
									{
										$(target).parent().find('.quantity').text( $(target).parent().find('.quantity').text() - quantity );
									}
									
									window.overlay_schedule_pour_validation();
								});
								
							}
							
							request = $.ajax({
								url: "ajax/schedule_auto_batching.php",
								type: "post",
								data: 'pourDate=' + $("#schedule_pour_date").val(),
								global: false
							});
							
			          	  	$( this ).dialog( "close" );
						 	$("#dialog-confirm").remove();
						}
		        	},
					{
						text: "Cancel",
						click: function() {
			          	  	$( this ).dialog( "close" );
						 	$("#dialog-confirm").remove();
		        	}
		      }]
		    });
	
			$('div#dialog-confirm').on( 'dialogclose', function(event) {
			     $("#dialog-confirm").remove();
			});
		});
		
		
		$(document).on("click", '.schedule_pour td.product', function () {
			
			var target = $(this);
			var currentVal = parseInt( $(".schedule_pour td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text() );
			
			if ( $('#dialog-confirm').length !== 0 )
			{
				$('#dialog-confirm').remove();
			}
			
			$("body").append( '<div id="dialog-confirm" title="Update Value"><p><table><tr><td><label>Shape:</label></td><td>' + $(this).text() + '</td></tr><tr><td><label>Pieces:</label></td><td><input id="modalValue" type="number" min="0" value="' + currentVal + '" style="text-align:right;"></td></tr></table></p></div>' );
		
			$( "#dialog-confirm" ).dialog({
				autoResize: true,
		      	modal: true,
				width: 350,
		      	buttons: [
					{
						text: "Remove",
						"class": "mainButton",
						click: function() {
							
							var quantity = 0;
							var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
									"quantity=" + quantity + '&' +
									"pourDate=" + $("#schedule_pour_date").val();
					
							request = $.ajax({
								url: "ajax/schedule_delete_pour.php",
								type: "post",
								data: ajaxData,
								global: false
							}).done( function ( response, textStatus, jqXHR) {
						
								// Open Order Exists
								if ( $('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').length != 0 )
								{
									$('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text( parseInt($('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text()) + currentVal );
								}
								else
								{
									var duplicate = $(target).parent().clone();
									$(duplicate).appendTo(".schedule_open .product_container table tbody");
									$(".schedule_open td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( currentVal - quantity );
								}
						
								$(target).parent().remove();
								$("div[data-date='" + $("#schedule_pour_date").val() + "'] .pour .product_scroll .productLine[data-productionorder='" + $(target).data('productionorder') + "'][data-pourdate='" + $("#schedule_pour_date").val() + "']").remove();
								
								window.overlay_schedule_pour_validation();
							});
							
							request = $.ajax({
								url: "ajax/schedule_auto_batching.php",
								type: "post",
								data: 'pourDate=' + $("#schedule_pour_date").val(),
								global: false
							});
												
			          	  	$( this ).dialog( "close" );
						 	$("#dialog-confirm").remove();
						}
		        	},
					{
						text: "Update",
						click: function() {
														
							var quantity = 	parseInt( $("#modalValue").val() );
							var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
									"quantity=" + quantity + '&' +
									"pourDate=" + $("#schedule_pour_date").val();
							
							//console.log( "quantity: " + quantity );
							//console.log( "currentVal: " + currentVal );
							
							if ( 
								quantity != 0 &&
								currentVal != quantity
							) {
							
								request = $.ajax({
									url: "ajax/schedule_update_pour.php",
									type: "post",
									data: ajaxData,
									global: false
								}).done( function ( response, textStatus, jqXHR) {
									$(".schedule_pour td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( quantity );
								
									if ( currentVal > quantity )
									{
									
										// Open Order Exists
										if ( $('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').length != 0 )
										{
											$('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text( parseInt($('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text()) + currentVal - quantity );
										}
										else
										{
											var duplicate = $(target).parent().clone();
											$(duplicate).appendTo(".schedule_open .product_container table tbody");
											$(".schedule_open td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( currentVal - quantity );
										}
									
									}
									else
									{
										
										if ( $('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').length != 0 )
										{
											$('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text( parseInt($('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text()) + (currentVal - quantity) );
											
											if ( parseInt($('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text()) == 0 )
											{
												$('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().remove();
											}
										}
										
									}
									
									window.overlay_schedule_pour_validation();
								});
								
							}
							else if ( quantity == 0 )
							{
								
								var ajaxData = "productionOrderID=" + $(target).data('productionorder') + '&' +
										"quantity=" + quantity + '&' +
										"pourDate=" + $("#schedule_pour_date").val();
								
								request = $.ajax({
									url: "ajax/schedule_delete_pour.php",
									type: "post",
									data: ajaxData,
									global: false
								}).done( function ( response, textStatus, jqXHR) {
									
									// Open Order Exists
									if ( $('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').length != 0 )
									{
										$('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text( parseInt($('.schedule_open td.product[data-productionorder="' + $(target).data('productionorder') + '"]').parent().find('.quantity').text()) + currentVal );
									}
									else
									{
										var duplicate = $(target).parent().clone();
										$(duplicate).appendTo(".schedule_open .product_container table tbody");
										$(".schedule_open td.product[data-productionorder='" + $(target).data('productionorder') + "']").parent().find('.quantity').text( currentVal - quantity );
									}
									
									$(target).parent().remove();
									$("div[data-date='" + $("#schedule_pour_date").val() + "'] .pour .product_scroll .productLine[data-productionorder='" + $(target).data('productionorder') + "'][data-pourdate='" + $("#schedule_pour_date").val() + "']").remove();
									
									window.overlay_schedule_pour_validation();
								});
								
							}
							
							request = $.ajax({
								url: "ajax/schedule_auto_batching.php",
								type: "post",
								data: 'pourDate=' + $("#schedule_pour_date").val(),
								global: false
							});
														
			          	  	$( this ).dialog( "close" );
						 	$("#dialog-confirm").remove();
						}
		        	},
					{
						text: "Cancel",
						click: function() {
			          	  	$( this ).dialog( "close" );
						 	$("#dialog-confirm").remove();
						}
		        	}
		      ]
		    });
				
			$('div#dialog-confirm').on( 'dialogclose', function(event) {
			     $("#dialog-confirm").remove();
			});
		});
		
	
	}
	
	window.overlay_schedule_pour_validation();

</script>