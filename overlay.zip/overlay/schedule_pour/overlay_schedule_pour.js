( function ($) {
	
	overlay_setup['schedule_pour'] = {
		"title": "Pour Schedule",
		"width": "600",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_date"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/schedule_pour/screens/schedule_pour.php",
				"validation": "overlay_schedule_pour_validation",
				"toSend": {
					0: "#overlay_date"
				},
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/schedule_pour/screens/schedule_order.php",
				"validation": "overlay_schedule_pour_order_validation",
				"toSend": {
					0: "#overlay_date"
				},
				"closeDelay": 0,
				"pageRefresh": true
			}, { 
				"id" : 3, 
				"url": "overlay/schedule_pour/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".schedule_trigger", function () {
			
			trigger = $(this)
			
			if ( $(trigger).parent().attr('class') == 'pour' )
			{
				
				if ( $("#overlay_date").length == 0 )
				{
					$("body").append( $('<input/>',{type:'hidden',id:'overlay_date'}) );
				}
			 
				$("#overlay_date").val( $(trigger).parent().parent().data('date') );
			
				overlay_open = 'schedule_pour';
				overlay_create( overlay_setup[overlay_open] );
				
			}
			
		});
		
	});
	
})(jQuery);