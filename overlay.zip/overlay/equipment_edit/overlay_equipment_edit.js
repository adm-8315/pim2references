( function ($) {
	
	overlay_setup['equipment_edit'] = {
		"title": "Edit Equipment",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_equipment"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/equipment_edit/screens/equipment_edit.php",
				"validation": "overlay_edit_equipment_validation",
				"toSend": {
					0: "#overlay_equipment",
					1: "#edit_equipment_name",
					2: "#edit_equipment_type",
					3: "#edit_equipment_identifier",
					4: "#edit_equipment_status",
					5: "#edit_equipment_location"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/equipment_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".equipment_edit", function () {
			overlay_open = 'equipment_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);