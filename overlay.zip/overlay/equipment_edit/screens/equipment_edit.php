<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Equipment
	
	$query = "
		SELECT
			*
		FROM
			equipment e
		WHERE
			e.equipmentID = ?
	";
	
	$values = array(
		$_POST['overlay_equipment']
	);
	
	$result['equipment'] = dbquery( $query, $values );
	
	
	// Equipment Type
	
	$query = "
		SELECT
			*
		FROM
			equipmentType et
		ORDER BY
			et.equipmentType 
	";
	
	$values = array();
	
	$result['equipmentType'] = dbquery( $query, $values );
	
	
	// Equipment Status
	
	$query = "
		SELECT
			*
		FROM
			equipmentStatus es
		ORDER BY
			es.equipmentStatus 
	";
	
	$values = array();
	
	$result['equipmentStatus'] = dbquery( $query, $values );
	
	
	// Location
	
	$query = "
		SELECT
			*
		FROM
			location l
		WHERE
			l.active = 1
		ORDER BY
			l.location
	";
	
	$values = array();
	
	$result['location'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>

<table id="edit_equipment_table">
	
	<tr>
		<td class="left">Name</td>
		<td class="right"><input type="text" id="edit_equipment_name" value="<?php echo $result['equipment'][0]['equipment'] ?>"></td>
	</tr>
	
	<tr>
		<td class="left">Type</td>
		<td class="right">
			<select id="edit_equipment_type">
				<?php
				
				foreach ( $result['equipmentType'] as $row )
				{
					if ( $row['equipmentTypeID'] == $result['equipment'][0]['equipmentType'] )
					{
						echo "<option value='" . $row['equipmentTypeID'] . "' selected='selected'>" . $row['equipmentType'] . "</option>";
					}
					else
					{
						echo "<option value='" . $row['equipmentTypeID'] . "'>" . $row['equipmentType'] . "</option>";
					}
				}
					
				?>
				
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Identifier</td>
		<td class="right"><input type="text" id="edit_equipment_identifier" value="<?php echo $result['equipment'][0]['identifier'] ?>"></td>
	</tr>
	
	<tr>
		<td class="left">Status</td>
		<td class="right">
			<select id="edit_equipment_status">
				<?php
				
				foreach ( $result['equipmentStatus'] as $row )
				{
					if ( $row['equipmentStatusID'] == $result['equipment'][0]['equipmentStatus'] )
					{
						echo "<option value='" . $row['equipmentStatusID'] . "' selected='selected'>" . $row['equipmentStatus'] . "</option>";
					}
					else
					{
						echo "<option value='" . $row['equipmentStatusID'] . "'>" . $row['equipmentStatus'] . "</option>";
					}
				}
					
				?>
				
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="left">Location</td>
		<td class="right">
			<select id="edit_equipment_location">
				<?php
				
				foreach ( $result['location'] as $row )
				{
					if ( $row['locationID'] == $result['equipment'][0]['location'] )
					{
						echo "<option value='" . $row['locationID'] . "' selected='selected'>" . $row['location'] . "</option>";
					}
					else
					{
						echo "<option value='" . $row['locationID'] . "'>" . $row['location'] . "</option>";
					}
				}
					
				?>
			</select>
		</td>
	</tr>
	
</table>

<style>

#edit_equipment_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_edit_equipment_validation != 'function' )
	{
	
		var keyupString = '';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_edit_equipment_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_edit_equipment_validation();
		});
	
		window.overlay_edit_equipment_validation = function ()
		{
			overlay_valid(true);
		}
		
		window.overlay_edit_equipment_validation();
	
	}

</script>