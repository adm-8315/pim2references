<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE equipment e
		SET
			e.equipment = ?,
			e.equipmentType = ?,
			e.identifier = ?,
			e.equipmentStatus = ?,
			e.location = ?
		WHERE
			e.equipmentID = ?
	";
	
	$values = array(
		$_POST['edit_equipment_name'],
		$_POST['edit_equipment_type'],
		$_POST['edit_equipment_identifier'],
		$_POST['edit_equipment_status'],
		$_POST['edit_equipment_location'],
		$_POST['overlay_equipment']
	);
	
	$result['equipmentUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	if ( $result['equipmentUpdate'] )
	{
		echo "The equipment details were updated.";
	}
	else
	{
		echo "There was a problem updating the equipment.";
	}

?>