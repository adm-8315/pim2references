( function ($) {
	
	overlay_setup['company_edit'] = {
		"title": "",
		"width": "400",
		"height": "500",
		"progress": false,
		"pages": [
			{ 
				"id" : 0,
				"toSend": {
					0: "#overlay_company"
				}
			}, { 
				"id" : 1, 
				"url": "overlay/company_edit/screens/company_edit.php",
				"toSend": {
					0: "#overlay_company",
					1: "#transaction_transaction_form_name",
					2: "#transaction_transaction_form_companyType"
				},
				"closeDelay": 2000,
				"pageRefresh": true
			}, { 
				"id" : 2, 
				"url": "overlay/company_edit/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", "#company_edit", function () {
			overlay_open = 'company_edit';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);