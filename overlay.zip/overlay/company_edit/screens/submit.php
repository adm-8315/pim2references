<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Material Update
	
	$query = "
		UPDATE
			company
		SET
			company = ?
		WHERE
			companyID = ?
	";
	
	$values = array(
		$_POST['transaction_transaction_form_name'],
		intval( $_POST['overlay_company'] )
	);
	
	$result['companyUpdate'] = dbquery( $query, $values );
	
	// Remove Company Type
	
	$query = "
		DELETE FROM
			companyCompanyTypeLink
		WHERE
			company = ?
	";
	
	$values = array(
		intval( $_POST['overlay_company'] )
	);
	
	$result['delete'] = dbquery( $query, $values );
	
	// Insert
	
	if ( $_POST['transaction_transaction_form_companyType'] != '-1' )
	{
		
		$query = "
			INSERT INTO
				companyCompanyTypeLink
				( company, companyType )
				VALUES
				( ?, ? )
		";
		
		$values = array(
			intval( $_POST['overlay_company'] ),
			$_POST['transaction_transaction_form_companyType']
		);
		
		$result['insert'] = dbquery( $query, $values );
		
	}
	
	
	/**
	 * Display
	 */
	
	echo "<div class='transaction_transactionSubmit_complete'>Company Updated</div>";

?>

<style>
	.transaction_transactionSubmit_complete {
		text-align: center;
		
		font-size: 26px;
		leter-spacing: 2px;
	}
</style>