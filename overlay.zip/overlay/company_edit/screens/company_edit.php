<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Company
	
	$query = "
		SELECT
			c.company,
			cctl.companyType
		FROM
			company c
		LEFT JOIN
			companyCompanyTypeLink cctl
			ON cctl.company = c.companyID
		WHERE
			c.companyID = ?
	";
	
	$values = array(
		$_POST['overlay_company']
	);
	
	$result['company'] = dbquery( $query, $values );
	
	// Company Type
	
	$query = "
		SELECT
			*
		FROM
			companyType
		ORDER BY
			companyType ASC
	";
	
	$values = array();
	
	$result['companyType'] = dbquery( $query, $values );

?>
<div class='transaction_transaction_container'>
	
	<h4>Company</h4>
	
	<div id='transaction_transaction_form_transationType'>Edit</div>
	<div id="transaction_transaction_form_materialDisplay" data-material="<?php echo $_POST['overlay_company']; ?>"><?php echo $result['company'][0]['company']; ?></div>
	
	<div id="transaction_transaction_container">
		
		<label>Company Type</label>
		<div class='field'>
			<select id ="transaction_transaction_form_companyType">
				<option value='-1'>Choose...</option>
				<?php
					
				foreach ( $result['companyType'] as $row )
				{
					
					echo "<option value='{$row['companyTypeID']}' ";
					
					if ( $result['company'][0]['companyType'] == $row['companyTypeID'] )
					{
						echo "selected='selected'";
					}
					
					echo ">{$row['companyType']}</option>";
					
				}
					
				?>
			</select>
		</div>
		<div class='clearMe'></div>

		<label>Name</label>
		<div class='field'><input type='text' id ="transaction_transaction_form_name" value="<?php echo htmlspecialchars( $result['company'][0]['company'] ); ?>" /></div>
		<div class='clearMe'></div>
		
	</div>

</div>

<script>
	
	if( typeof overlay_transaction_transaction_validation != 'function' )
	{
		
		var keyupString = '#transaction_transaction_form_name';
		var changeString = '#transaction_transaction_form_companyType';
		
		$(document).on("keyup", keyupString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		$(document).on("change", changeString, function () {
			window.overlay_transaction_transaction_validation();
		});
		
		window.overlay_transaction_transaction_validation = function ()
		{
			
			// Validation Final	
			if (
				(
					(
						$("#transaction_transaction_form_name").val() != "<?php echo $result['company'][0]['company']; ?>" ||
						$("#transaction_transaction_form_companyType").val() != "<?php echo $result['company'][0]['companyType']; ?>"
					) && 
					$("#transaction_transaction_form_name").val() != ""
				)
			) {
			    overlay_valid(true);
			} else {
			    overlay_valid(false);
			}

		}
		
	}


</script>

<style>
	
	.transaction_transaction_container {
		text-align: center;
	}
	
	.transaction_transaction_container #transaction_transaction_container {
		width: 300px;
		
		margin: 0 auto;
	}
	
	#transaction_transaction_form_transationType {
		margin-bottom: 35px;
		
		font-size: 18px;
	}
	
	#transaction_transaction_form_materialDisplay {
		margin-bottom: 15px;
		
		font-size: 16px;
	}
	
	.transaction_transaction_container div label {
		display: block;
		
		float: left;
		
		height: 20px;
		
		line-height: 20px;
		font-size: 14px;
		color: #555;
		font-weight: bold;
	}
	
	.transaction_transaction_container div.field {
		float: right;
		
		height: 20px;
		width: 160px;
		
		margin-bottom: 10px;
		
		text-align: left;
		line-height: 20px;
	}
	
	.transaction_transaction_container div select,
	.transaction_transaction_container div button {
		height: 30px;
		width: 200px;
	}
	
	.transaction_transaction_container div button {
		width: 76px;
		
		background: #f1f1f1;
		
		border: 1px solid #ddd;
		border-radius: 3px;
		
		font-size: 12px;
		color: #555;
	}
	
	#transaction_transaction_form_name {
		width: 170px !important;
		
		margin-right: 10px;
		margin-top: 5px;
	}
	
	#transaction_transaction_form_companyType {
		width: 184px !important;
	}

	
	.clearMe {
		height: 0px;
		
		clear: both;
	}
	
</style>

