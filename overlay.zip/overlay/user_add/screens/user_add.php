<?php

	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Users
	
	$query = "
		SELECT
			username
		FROM
			user u
	";
	
	$values = array();
	
	$result['users'] = dbquery( $query, $values );
	
	
	
	/**
	 * Process
	 */
	
	$temp = array();
	
	foreach( $result['users'] as $row )
	{
		$temp[] = $row['username'];
	}
	
	$result['users'] = $temp;
	unset($temp);
	
	
	/**
	 * Display
	 */

?>

<div id='overlay_add_user_container'>

	<table id='user_add_table'>

		<tr>
			<td class='left'>Username</td>
			<td class='right'><input type='text' id='username' class='form_input' name='username' value='' placeholder='Username' /></td>
		</tr>
	
		<tr>
			<td class="left">First Name</td>
			<td class="right"><input type='text' id='firstname' class='form_input' name='firstname' value='' placeholder='First Name' /></td>
		</tr>
	
		<tr>
			<td class="left">Last Name</td>
			<td class="right"><input type='text' id='lastname' class='form_input' name='lastname' value='' placeholder='Last Name' /></td>
		</tr>

	</table>

</div>

<style>

#user_add_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>
	
	<?php 

		if ( isset( $result['users'] ) )
		{
			echo "var userString = " . json_encode($result['users']) . "; ";
			//echo "userString = $.parseJSON(userString); ";
		}
		else
		{
			echo "var userString = null; ";
		}
	
	?>

	if( typeof overlay_user_add_validation != 'function' )
	{
	
		var keyupString = '#username, #firstname, #lastname';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_user_add_validation();
		});
	
		window.overlay_user_add_validation = function ()
		{
			
			if (
				$("#username").val() != "" &&
				$.inArray( $("#username").val(), userString ) < 0 &&
				$("#firstname").val() != "" &&
				$("#lastname").val() != ""
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_user_add_validation();
	
	}

</script>