<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset($_POST['username']) && $_POST['username'] != '' )
	{	
		
		$query = "
			INSERT INTO
				person
			SET
				firstName = ?,
				lastName = ?
		";
		
		$values = array(
			$_POST['firstname'],
			$_POST['lastname']
		);
		
		$result['personInsert'] = dbquery( $query, $values );
		
		
		
		$query = "
			INSERT INTO
				user
			SET
				active = 1,
				person = ?,
				username = ?,
				passwordHash = ?,
				defaultLocation = ?,
				defaultOwner = ?
		";
		
		$values = array(
			$result['personInsert'],
			$_POST['username'],
			'124d8ca50944d7e7c6304628d64485ea5a5b3489',
			1,
			47
		);
		
		$result['userInsert'] = dbquery( $query, $values );
		
	}
	
	
	
	
	
	/**
	 * Display
	 */
	
	if ( $result['userInsert'] )
	{
		echo $_POST['username'] . " was added successfully with the password 'changeMe!'";
	}
	else
	{
		echo "There was a problem adding the user.";
	}

?>