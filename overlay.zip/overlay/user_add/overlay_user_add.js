( function ($) {
	
	overlay_setup['user_add'] = {
		"title": "Add User",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/user_add/screens/user_add.php",
				"validation": "overlay_user_add_validation",
				"toSend": {
					0: "#username",
					1: "#firstname",
					2: "#lastname"
				},
				"closeDelay": 20000,
				"pageRefresh": false,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/user_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_user']", function () {
			overlay_open = 'user_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);