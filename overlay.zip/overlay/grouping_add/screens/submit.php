<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( isset($_POST['add_grouping_name']) && $_POST['add_grouping_name'] != '' )
	{	
		
		// Item
		
		$query = "
			INSERT
				INTO grouping
				( grouping )
				VALUES
				( ? )
		";
		
		$values = array(
			$_POST['add_grouping_name']	
		);
		
		$result['grouping'] = dbquery( $query, $values );
		
	}
	
	
	/**
	 * Display
	 */
	
	if ( $result['grouping'] )
	{
		echo $_POST['add_grouping_name'] . " was added successfully.";
	}
	else
	{
		echo "There was a problem adding the grouping.";
	}

?>