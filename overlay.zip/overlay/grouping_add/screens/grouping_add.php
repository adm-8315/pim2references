<?php

	/**
	 * Display
	 */

?>

<table id="add_grouping_table">
	
	<tr>
		<td class="left">Name</td>
		<td class="right"><input type="text" id="add_grouping_name" value="" /></td>
	</tr>
	
</table>

<style>

#add_grouping_table {
	margin: 0 auto;
}

.left {
	font-weight: bold;
}

</style>

<script>

	if( typeof overlay_add_grouping_validation != 'function' )
	{
	
		var keyupString = '#add_grouping_name';
		var changeString = '';
	
		$(document).on("keyup", keyupString, function () {
			window.overlay_add_grouping_validation();
		});
	
		$(document).on("change", changeString, function () {
			window.overlay_add_grouping_validation();
		});
	
		window.overlay_add_grouping_validation = function ()
		{
			if ( 
				$("#add_grouping_name").val() != ""
			) {
				overlay_valid(true);
			}
			else
			{
				overlay_valid(false);
			}
			
		}
		
		window.overlay_add_grouping_validation();
	
	}

</script>