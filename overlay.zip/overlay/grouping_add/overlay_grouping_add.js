( function ($) {
	
	overlay_setup['grouping_add'] = {
		"title": "Add Grouping",
		"width": "400",
		"height": "500",
		"progress": true,
		"pages": [
			{ 
				"id" : 1, 
				"url": "overlay/grouping_add/screens/grouping_add.php",
				"validation": "overlay_grouping_add_validation",
				"toSend": {
					0: "#add_grouping_name"
				},
				"closeDelay": 2000,
				"pageRefresh": true,
				"disableBack": true
			}, { 
				"id" : 2, 
				"url": "overlay/grouping_add/screens/submit.php"
			}
		]
	};
	
	// Triggers
	$(document).ready( function () {
		
		$(document).on("click", ".toolbar_button_options .option[data-nav='add_grouping']", function () {
			overlay_open = 'grouping_add';
			overlay_create( overlay_setup[overlay_open] );
		});
		
	});
	
})(jQuery);