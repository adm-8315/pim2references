<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			productionOrderSchedule
		SET
			stripDate = '0000-00-00'
		WHERE
			productionOrder = ?
		AND
			pourDate = ?
	";
	
	$values = array(
		$_POST['productionOrderID'],
		$_POST['pourDate']
	);
	
	$result['schedule_delete_strip'] = dbquery( $query, $values );
	
?>