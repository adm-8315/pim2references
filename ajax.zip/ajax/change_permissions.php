<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/session.php" );
	

	/**
	 * Variables
	 */
	
	$result = array();
	$error = false;
	

	/**
	 * Change Permissions
	 */
	
	// User
	
	$query = "
		SELECT
			*
		FROM
			user
		WHERE
			userID = ?
	";
	
	$values = array(
		$_POST['userID']
	);
	
	$result['user'] = dbquery( $query, $values );
	
	
	// Delete Permissions
		
	$query = "
		DELETE 
			permissionLink
		FROM
			permissionLink
		LEFT JOIN
			permissionBlock
			ON permissionLink.permissionBlock = permissionBlock.permissionBlockID
		LEFT JOIN
			permissionApplication
			ON permissionBlock.permissionApplication = permissionApplication.permissionApplicationID
		WHERE
			user = ?
		AND
			permissionApplication.permissionApplication = ?
			
	";

	$values = array(
		$_POST['userID'],
		$_SESSION['application']
	);

	$result['permissionDelete'] = dbquery( $query, $values );
	
	
	// Insert Permissions
	
	$query = "
		INSERT 
			INTO permissionLink
			( user, permissionBlock, location )
			VALUES
	";

	$values = array();

	foreach ( $_POST as $key => $value )
	{

		if ( $key != "userID" )
		{

			$query .= "( ?, ?, ? ),";

			$values[] = $_POST['userID'];
			
			$keyExplode = explode( ",", $key );
			
			$values[] = $keyExplode[0];
			$values[] = $keyExplode[1];

		}

	}

	$query = substr( $query, 0, -1 );

	$result['permissionInsert'] = dbquery( $query, $values );


	echo "Permissions Updated for " . $result['user'][0]['username'];
	
?>