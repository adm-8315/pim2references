<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			productionOrderSchedule
		SET
			fireDate = '0000-00-00'
		WHERE
			productionOrder = ?
		AND
			pourDate = ?
	";
	
	$values = array(
		$_POST['productionOrderID'],
		$_POST['pourDate']
	);
	
	$result['schedule_delete_fire'] = dbquery( $query, $values );
	
?>