<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			productionOrderSchedule
		SET
			quantity = ?
		WHERE
			productionOrder = ?
		AND
			pourDate = ?
	";
	
	$values = array(
		$_POST['quantity'],
		$_POST['productionOrderID'],
		$_POST['pourDate']
	);
	
	$result['schedule_add_pour'] = dbquery( $query, $values );
	
?>