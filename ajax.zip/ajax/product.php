<?

	/**
	 * Includes
	 */

	require_once("../inc/dbfunc.php");
	require_once("../inc/functions/update_productInventory.php");
	require_once("../inc/functions/update_productCost.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();


	/**
	 * MySQL
	 */
	
	// Transaction
	
	$query = "
		SELECT
			t.productInventory,
			i.product
		FROM
			productTransaction t
		LEFT JOIN
			productInventory i
			ON t.productInventory = i.productInventoryID
		WHERE
			t.productTransactionID = ?
	";
	
	$values = array(
		$_POST['transactionID']
	);

	$result['transaction'] = dbquery( $query, $values );
	$productID = $result['transaction'][0]['product'];
	$productInventoryID = $result['transaction'][0]['productInventory'];

	$query = "
		DELETE FROM
			productTransaction
		WHERE
			productTransactionID = ?
	";

	$values = array(
		$_POST['transactionID']
	);

	$result['transactionDelete'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	update_productInventory();
	update_productCost( $productID );

?>