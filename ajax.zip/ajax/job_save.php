<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	require_once("../inc/functions/normalizeItemInventory.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$json = json_decode( $_POST['json'], true );
	$run = false;


	/**
	 * MySQL
	 */
	
	// Delete Equipment List
	
	$query = "
		DELETE FROM equipmentList
			WHERE
				job = ?
	";
	
	$values = array(
		$_POST['job']
	);
	
	$result['equipmentListDelete'] = dbquery( $query, $values );
	
	
	// Delete Grouping List
	
	$query = "
		DELETE FROM groupingList
			WHERE
				job = ?
	";
	
	$result['groupingListDelete'] = dbquery( $query, $values );
	
	
	// Delete Item List
	
	$query = "
		DELETE FROM itemList
			WHERE
				job = ?
	";
	
	$result['itemListDelete'] = dbquery( $query, $values );
	
	// Item Inventory Insert Ignore ( Make sure all Inventory IDs Exist )
	
	normalizeItemInventory( $json );
	
	
	// Equipment List Insert
	
	$values = array();
	$run = false;
	
	$query = "
		INSERT 
			INTO equipmentList
				( job, equipment )
			VALUES		
	";
	
	foreach ( $json as $row )
	{
		
		if ( $row['type'] == 'equipment' )
		{
			
			$query .= "( ?, ? ),";
			$values[] = $_POST['job'];
			$values[] = $row['id'];
			$run = true;
			
		}
		
	}
	
	if ( $run )
	{
		
		$query = substr( $query, 0, -1 );
		$result['equipmentListInsert'] = dbquery( $query, $values );
	
	}
	
	
	// Grouping List Insert
	
	$values = array();
	$run = false;
	
	$query = "
		INSERT 
			INTO groupingList
				( job, grouping )
			VALUES		
	";
	
	foreach ( $json as $row )
	{
		
		if ( $row['type'] == 'grouping' )
		{
			
			$query .= "( ?, ? ),";
			$values[] = $_POST['job'];
			$values[] = $row['id'];
			$run = true;
			
		}
		
	}
	
	if ( $run )
	{
		
		$query = substr( $query, 0, -1 );
		$result['groupingListInsert'] = dbquery( $query, $values );
	
	}
	
	
	// Item List Insert
	
	$values = array();
	$run = false;
	
	$query = "
		INSERT 
			INTO itemList
				( job, itemInventory, value )
			VALUES		
	";
	
	foreach ( $json as $row )
	{
		
		if ( $row['type'] == 'item' )
		{
			
			$query .= "( ?, (SELECT itemInventoryID FROM itemInventory WHERE item = ? AND location = 1 LIMIT 1 ), ?),";
			$values[] = $_POST['job'];
			$values[] = $row['id'];
			$values[] = $row['value'];
			$run = true;
			
		}
		
	}
	
	if ( $run )
	{
		
		$query = substr( $query, 0, -1 );
		$result['itemListInsert'] = dbquery( $query, $values );
	
	}
	
	echo "Job list has been updated.";

?>