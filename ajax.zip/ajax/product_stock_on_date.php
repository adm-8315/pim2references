<?php

	/**
	 * Includes
	 */
	
	require_once("../../inc/dbfunc.php");
	require_once("../../inc/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();

	
	/**
	 * MySQL
	 */
	
	// Stock
	
	$query = "
		SELECT
			temp.stock
		FROM
			(
				SELECT
					*
				FROM
					(
						SELECT
							CASE
								WHEN @prev_id != temp.productInventory
								THEN @totalStock := 0
								ELSE null
							END as 'resetTotalStock',

							CASE
								WHEN temp.transactionType <= 2
								THEN @totalStock := @totalStock + temp.value
								WHEN temp.transactionType > 2 && temp.transactionType != 7
								THEN @totalStock := @totalStock - temp.value
								ELSE @totalStock := temp.value
							END as 'stock',
							temp.productTransactionID,
							temp.product,
							temp.timestamp,
							@prev_id := temp.productInventory as 'productInventory'
						FROM
							(
								SELECT
									@prev_id := 0,
									@row := 0,
									@total_stock := 0
							) vars
						JOIN
							(
								(
									SELECT
										t.productTransactionID,
										i.product,
										t.productInventory,
										t.transactionType,
										t.value,
										t.cost,
										t.timestamp
									FROM
										productInventory i
									LEFT JOIN
										productTransaction t
										ON i.productInventoryID = t.productInventory
									LEFT JOIN
										companyLocationLink cll
										ON i.companyLocationLink = cll.companyLocationLinkID
									WHERE
										i.product = ?
									AND														
										t.timestamp <= ?
									AND
										cll.location = ?
									AND
										cll.company = ?
									ORDER BY
										i.product,
										t.timestamp,
										t.productTransactionID
								)
							UNION
								(
									SELECT
										t.productTransactionID,
										i.product,
										i2.productInventoryID as productInventory,
										t.transactionType,
										t.value * -1 as value,
										t.cost,
										t.timestamp
									FROM
										productTransaction t
									LEFT JOIN
										productInventory i
										ON t.productInventory = i.productInventoryID
									LEFT JOIN
										productInventory i2
										ON i2.product = i.product
										AND i2.companyLocationLink = t.companyLocationLink
									LEFT JOIN
										companyLocationLink cll
										ON cll.companyLocationLinkID = t.companyLocationLink
									WHERE
										t.transactionType = 3
									AND
										t.companyLocationLink is not null
									AND
										i.product = ?
									AND														
										t.timestamp <= ?
									AND
										cll.location = ?
									AND
										cll.company = ?
								)
							) temp
						ORDER BY
							temp.productInventory ASC,
							temp.timestamp ASC,
							temp.productTransactionID ASC
					) temp
				ORDER BY
					temp.productInventory ASC,
					temp.timestamp DESC,
					temp.productTransactionID DESC
			) temp
		GROUP BY
			temp.productInventory
	";
	
	$values = array(
		$_POST['dataMaterial'],
		date_to_mysql( $_POST['dataDate']),
		$_POST['dataLocation'],
		$_POST['dataOwner'],
		$_POST['dataMaterial'],
		date_to_mysql( $_POST['dataDate']),
		$_POST['dataLocation'],
		$_POST['dataOwner']
	);
	
	$result['stock'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo $result['stock'][0]['stock'];
	
?>