<?php
	
	/**
	 * Includes
	 */
	
	require_once("../../inc/dbfunc.php");
	require_once("../inc/normalizeItemInventory.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$json = $_POST['dataJSON'];
	
	
	/**
	 * MySQL
	 */
	
	normalizeItemInventory( $json );
	
	$values = array();
	
	$query = "
		UPDATE
			itemInventory
			SET stock = CASE
	";
	
	foreach ( $json as $row )
	{
		$query .= " WHEN location = ? THEN ? ";
		$values[] = $row['location'];
		$values[] = $row['stock'];
	}
				
	$query .= "			
			END
		WHERE
			item = ?
		AND
			location in (
	";
	
	foreach ( $json as $row )
	{
		$query .= " ?,";
		$values[] = $row['location'];
	}
	
	$query = substr( $query, 0, -1);
	
	$query .= ")";
	
	$values[] = $json[0]['id'];
	
	$result['itemInventoryUpdate'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */

?>