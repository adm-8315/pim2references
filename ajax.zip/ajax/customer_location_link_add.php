<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	if ( $_POST['companyID'] != -1 )
	{
		
		// Location
		
		$query = "
			SELECT
				l.locationID,
				l.location
			FROM
				location l
			WHERE NOT EXISTS 
			(
				SELECT
					cll.location
				FROM
					companyLocationLink cll
				WHERE
					cll.location = l.locationID
				AND
					cll.company = ?
			)
			AND
				l.locationID != 22
			ORDER BY
				l.location ASC
		";

		$values = array(
			$_POST['companyID']
		);

		$result['location'] = dbquery( $query, $values );
	
	}
	
	
	/**
	 * Display
	 */
	
	echo "<option value='-1'>Choose...</option>";
	
	if ( $_POST['companyID'] != -1 )
	{
		
		foreach ( $result['location'] as $row )
		{
			echo "<option value='{$row['locationID']}'>{$row['location']}</option>";
		}
		
	}
	
?>