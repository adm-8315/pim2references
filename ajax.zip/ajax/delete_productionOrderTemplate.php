<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Remove Options
	
	$query = "
		DELETE FROM
			productionOrderTemplateProductionOrderOptionLink
		WHERE
			productionOrderTemplate = ?
	";
	
	$values = array( $_POST['productionOrderTemplateID'] );
	
	$result['removeOptions'] = dbquery( $query, $values );
	
	
	// Remove Material Link
	
	$query = "
		DELETE FROM
			productionOrderTemplateMaterialLink
		WHERE
			productionOrderTemplate = ?
	";
	
	$result['removeMaterials'] = dbquery( $query, $values );
	
	// Remove Production Order
	
	$query = "
		DELETE FROM
			productionOrderTemplate
		WHERE
			productionOrderTemplateID = ?
	";
	
	$result['removeProductionOrder'] = dbquery( $query, $values );
	

?>