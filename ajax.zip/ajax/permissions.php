<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/dev_tools/print_dev.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$JSON = json_decode( $_POST['JSON'], true );
	
	
	/**
	 * MySQL
	 */
	
	// Active
	
	$query = "
		UPDATE
			user
		SET
			active = ?
		WHERE
			userID = ?
	";
	
	$values = array(
		$JSON['active'],
		$JSON['user']
	);
	
	$result['user'] = dbquery( $query, $values );
	
	// Remove Links
	
	$query = "
		DELETE FROM
			permissionLink
		WHERE
			user = ?
	";
	
	$values = array(
		$JSON['user']
	);
		
	$result['permissionLinkDelete'] = dbquery( $query, $values );
		
		
	// Add Links
	
	$values = array();
	
	$query = "
		INSERT INTO
			permissionLink
			( user, permissionBlock, allLocation, location )
			VALUES
	";
	
	foreach ( $JSON['permissions'] as $block => $blockValues )
	{
		
		if ( $block == 1 )
		{
			$query .= "( ?, ?, ?, ? ),";
			$values[] = $JSON['user'];
			$values[] = $block;
			$values[] = 0;
			$values[] = null;
		}
		else
		{
			
			if ( isset( $blockValues[-1] ) )
			{
				$query .= "( ?, ?, ?, ? ),";
				$values[] = $JSON['user'];
				$values[] = $block;
				$values[] = 1;
				$values[] = null;
			}
			else
			{
								
				foreach( $blockValues as $location => $temp )
				{
					$query .= "( ?, ?, ?, ? ),";
					$values[] = $JSON['user'];
					$values[] = $block;
					$values[] = 0;
					$values[] = $location;
				}
				
			}
			
		}
		
	}
	
	$query = substr( $query, 0, -1 );
		
	$result['permissions'] = dbquery( $query, $values );
		
	
	/**
	 * Display
	 */
	
	
	echo "Permissions were updated.";
	
?>