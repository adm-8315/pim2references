<?php

	/**
	 * Includes
	 */
	
	require_once('../inc/dbfunc.php');

	
	/**
	 * Variables
	 */

	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			qcTest
		SET
			stopTime = NOW()
		WHERE
			slot = ?
		AND
			(
				stopTime is null
			OR
				stopTime > NOW()
			)
			
	";
	
	$values = array(
		$_GET['id']
	);
	
	$result['series'] = dbquery( $query, $values );
	
?>