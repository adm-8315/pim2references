<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Location
	
	$query = "
		SELECT
			l.locationID,
			l.location
		FROM
			companyLocationLink cll
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		WHERE
			cll.company = ?
		ORDER BY
			l.location ASC
	";
	
	$values = array(
		$_POST['new_job_customer']
	);
	
	$result['location'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo "<option value='-1'>Choose...</option>";
	
	foreach ( $result['location'] as $location )
	{
		echo "<option value='{$location['locationID']}'>{$location['location']}</option>";
	}
	

?>