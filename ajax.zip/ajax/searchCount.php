<?php

	/**
	 * Includes
	 */

	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Search
	
	switch ( $_POST['searchType'] )
	{
		
		case 1:
			$query = "
				UPDATE 
					material 
				SET 
					searchCount = searchCount + 1 
				WHERE 
					materialID = ?
			";
			break;
			
		case 2:
			$query = "
				UPDATE 
					product 
				SET 
					searchCount = searchCount + 1 
				WHERE 
					productID = ?
			";
			break;
			
		case 3:
			$query = "
				UPDATE 
					company 
				SET 
					searchCount = searchCount + 1 
				WHERE 
					companyID = ?
			";
			break;
		
	}
	
	$values = array(
		$_POST['id']
	);
	
	$result['searchCount'] = dbquery( $query, $values );
	
?>