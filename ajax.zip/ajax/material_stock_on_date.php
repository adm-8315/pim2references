<?php

	/**
	 * Includes
	 */
	
	require_once("../../inc/dbfunc.php");
	require_once("../../inc/date_conversion.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();

	
	/**
	 * MySQL
	 */
	
	// Stock
	
	$query = "
		SELECT
			temp.stock
		FROM
			(
				SELECT
					*
				FROM
					(
						SELECT
							CASE
								WHEN @prev_id != temp.materialInventory
								THEN @totalStock := 0
								ELSE null
							END as 'resetTotalStock',

							CASE
								WHEN temp.transactionType <= 2
								THEN @totalStock := @totalStock + temp.value
								WHEN temp.transactionType > 2 && temp.transactionType != 7
								THEN @totalStock := @totalStock - temp.value
								ELSE @totalStock := temp.value
							END as 'stock',
							temp.materialTransactionID,
							temp.material,
							temp.timestamp,
							@prev_id := temp.materialInventory as 'materialInventory'
						FROM
							(
								SELECT
									@prev_id := 0,
									@row := 0,
									@total_stock := 0
							) vars
						JOIN
							(
								(
									SELECT
										t.materialTransactionID,
										i.material,
										t.materialInventory,
										t.transactionType,
										t.value,
										t.cost,
										t.timestamp
									FROM
										materialInventory i
									LEFT JOIN
										materialTransaction t
										ON i.materialInventoryID = t.materialInventory
									LEFT JOIN
										companyLocationLink cll
										ON i.companyLocationLink = cll.companyLocationLinkID
									WHERE
										i.material = ?
									AND														
										t.timestamp <= ?
									AND
										cll.location = ?
									AND
										cll.company = ?
									ORDER BY
										i.material,
										t.timestamp,
										t.materialTransactionID
								)
							UNION
								(
									SELECT
										t.materialTransactionID,
										i.material,
										i2.materialInventoryID as materialInventory,
										t.transactionType,
										t.value * -1 as value,
										t.cost,
										t.timestamp
									FROM
										materialTransaction t
									LEFT JOIN
										materialInventory i
										ON t.materialInventory = i.materialInventoryID
									LEFT JOIN
										materialInventory i2
										ON i2.material = i.material
										AND i2.companyLocationLink = t.companyLocationLink
									LEFT JOIN
										companyLocationLink cll
										ON cll.companyLocationLinkID = t.companyLocationLink
									WHERE
										t.transactionType = 3
									AND
										t.companyLocationLink is not null
									AND
										i.material = ?
									AND														
										t.timestamp <= ?
									AND
										cll.location = ?
									AND
										cll.company = ?
								)
							) temp
						ORDER BY
							temp.materialInventory ASC,
							temp.timestamp ASC,
							temp.materialTransactionID ASC
					) temp
				ORDER BY
					temp.materialInventory ASC,
					temp.timestamp DESC,
					temp.materialTransactionID DESC
			) temp
		GROUP BY
			temp.materialInventory
	";
	
	$values = array(
		$_POST['dataMaterial'],
		date_to_mysql( $_POST['dataDate']),
		$_POST['dataLocation'],
		$_POST['dataOwner'],
		$_POST['dataMaterial'],
		date_to_mysql( $_POST['dataDate']),
		$_POST['dataLocation'],
		$_POST['dataOwner']
	);
	
	$result['stock'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo $result['stock'][0]['stock'];
	
?>