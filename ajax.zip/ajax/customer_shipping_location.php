<?php

	/**
	 * Includes
	 */

	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Company Location Link

	$query = "
		SELECT
			cll.companyLocationLinkID as 'companyLocationLink',
			l.location as 'location'
		FROM
			companyLocationLink cll
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		WHERE
			cll.company = ?
		AND
			cll.location != 22
		ORDER BY
			l.location ASC
	";
	
	$values = array(
		$_POST['customerID']
	);
	
	$result['companyLocationLink'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo "<option data-customer='-1' value='-1'>Choose...</option>";
	
	foreach ( $result['companyLocationLink'] as $row )
	{
		echo "<option data-customerlocation='{$row['companyLocationLink']}' value='{$row['companyLocationLink']}'>{$row['location']}</option>";
	}
	
	echo "<option data-customerlocation='22' value='22'>Customer Pick Up</option>";

?>