<?

	/**
	 * Includes
	 */

	require_once("../inc/dbfunc.php");
	require_once("../inc/functions/update_materialInventory.php");
	require_once("../inc/functions/update_materialCost.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();


	/**
	 * MySQL
	 */
	
	// Transaction
	
	$query = "
		SELECT
			t.materialInventory,
			i.material
		FROM
			materialTransaction t
		LEFT JOIN
			materialInventory i
			ON t.materialInventory = i.materialInventoryID
		WHERE
			t.materialTransactionID = ?
	";
	
	$values = array(
		$_POST['transactionID']
	);

	$result['transaction'] = dbquery( $query, $values );
	$materialID = $result['transaction'][0]['material'];
	$materialInventoryID = $result['transaction'][0]['materialInventory'];

	$query = "
		DELETE FROM
			materialTransaction
		WHERE
			materialTransactionID = ?
	";

	$values = array(
		$_POST['transactionID']
	);

	$result['transactionDelete'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	update_materialInventory();
	update_materialCost( $materialID );

?>