<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		INSERT INTO
			productionOrderSchedule
			( productionOrder, pourDate, quantity, active )
		VALUES
			( ?, ?, ?, ? )
	";
	
	$values = array(
		$_POST['productionOrderID'],
		$_POST['pourDate'],
		$_POST['quantity'],
		1
	);
	
	$result['schedule_add_pour'] = dbquery( $query, $values );
	
?>