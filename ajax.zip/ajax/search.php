<?php

	/**
	 * Includes
	 */

	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Search

	$query = "
		SELECT
			temp.id,
			temp.name,
			temp.type,
			temp.category
		FROM
			(
				(
					SELECT
						c.companyID as 'id',
						c.company as 'name',
						2 as 'type',
						1 as 'category',
						c.searchCount
					FROM	
						company c
					WHERE
						c.company like ?
					AND
						c.active = 1
					ORDER BY
						c.company ASC
					LIMIT
						2
				)
				UNION
				(
					SELECT
						ma.materialID as 'id',
						ma.material as 'name',
						1 as 'type',
						1 as 'category',
						ma.searchCount
					FROM
						material ma
					WHERE
						ma.material like ?
					ORDER BY
						ma.material ASC
					LIMIT 8
				)
				UNION
				(		
					SELECT
						p.productID as 'id',
						IF(
							c.company is null,
							p.product,
							CONCAT( c.company, ' ', p.product)
						) as 'name',
						1 as 'type',
						2 as 'category',
						p.searchCount
					FROM
						product p
					LEFT JOIN
						productConsumerLink pcl
						ON p.productID = pcl.product
					LEFT JOIN	
						companyLocationLink cll
						ON pcl.companyLocationLink = cll.companyLocationLinkID
					LEFT JOIN
						company c
						ON cll.company = c.companyID
					WHERE
						p.product like ?
					OR
						CONCAT( c.company, ' ', p.product ) like ?
					ORDER BY
						p.product ASC
					LIMIT 8
				)
			) as temp
		ORDER BY
			temp.searchCount DESC
		LIMIT
			8
	";
	
	$values = array(
		'%' . $_POST['jssearch_search'] . '%',
		'%' . $_POST['jssearch_search'] . '%',
		'%' . $_POST['jssearch_search'] . '%',
		'%' . $_POST['jssearch_search'] . '%'
	);
	
	$result['search'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo json_encode( $result['search'] );
?>