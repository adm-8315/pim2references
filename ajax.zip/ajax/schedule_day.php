<?php
	
	/**
	 * Includes
	 */
	
	require_once( "inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
				pos.productionOrder as 'id',
				'overlay' as 'nav',
				'schedule_edit' as 'overlay',
				IF(
					c.company is null,
					p.product,
					CONCAT( c.company, ' ', p.product)
				) as 'product',
				m.material as 'mainMaterial',
				pos.quantity
			FROM
				productionOrder po
			LEFT JOIN
				productionOrderSchedule pos
				ON po.productionOrderID = pos.productionOrder
			LEFT JOIN
				productConsumerLink pcl
				ON po.product = pcl.product
			LEFT JOIN
				product p
				ON po.product = p.productID
			LEFT JOIN
				companyLocationLink cll
				ON pcl.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				(
					SELECT
						poml.productionOrder, 
						poml.material,
						poml.quantity
					FROM 
						productionOrderMaterialLink poml
					LEFT JOIN
						(
							SELECT
								poml.*,
								max(poml.quantity) as max
							FROM
								productionOrderMaterialLink poml
							LEFT JOIN
								material m
								ON poml.material = m.materialID
							WHERE
								m.materialType = 11
							OR
								m.materialType = 12
							OR
								m.materialType = 13
							OR
								m.materialType = 18
							OR
								m.materialType = 34
							GROUP BY
								poml.productionOrder
						) max
						ON max.productionOrder = poml.productionOrder
						AND max.max = poml.quantity
					WHERE
						max.max is not null
				) poml
				ON poml.productionOrder = po.productionOrderID
			LEFT JOIN
				material m
				ON poml.material = m.materialID
			WHERE
				pos.active = 1
			AND
				pos.productionOrder is not null
			AND
				pourDate = ?
	";
	
	$values = array(
		$_POST['date']
	);
	
	$result['scheduleDay'] = dbquery( $query, $values );
	
	if ( 
		isset( $_POST['ajaxCall'] ) &&
		$_POST['ajaxCall'] == true
	) {
		echo json_encode( $result['scheduleDay'] );
		$_POST['ajaxCall'] = false;
	}
	
?>