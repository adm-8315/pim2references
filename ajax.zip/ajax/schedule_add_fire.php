<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		UPDATE
			productionOrderSchedule
		SET
			fireDate = ?
		WHERE
			productionOrder = ?
		AND
			pourDate = ?
	";
	
	$values = array(
		$_POST['fireDate'],
		$_POST['productionOrderID'],
		$_POST['pourDate']
	);
	
	$result['schedule_add_fire'] = dbquery( $query, $values );
	
?>