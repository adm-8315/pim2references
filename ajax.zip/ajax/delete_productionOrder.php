<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	$values = array( $_POST['productionOrder'] );
	
	
	
	// Remove Scheduled
	
	$query = "
		DELETE FROM
			productionOrderSchedule
		WHERE
			productionOrder = ?
	";
	
	$result['removeSchedule'] = dbquery( $query, $values );
	
	// Remove Options
	
	$query = "
		DELETE FROM
			productionOrderProductionOrderOptionLink
		WHERE
			productionOrder = ?
	";
	
	$result['removeOptions'] = dbquery( $query, $values );
	
	
	// Remove Material Link
	
	$query = "
		DELETE FROM
			productionOrderMaterialLink
		WHERE
			productionOrder = ?
	";
	
	$result['removeMaterials'] = dbquery( $query, $values );
	
	// Remove Production Order
	
	$query = "
		DELETE FROM
			productionOrder
		WHERE
			productionOrderID = ?
	";
	
	$result['removeProductionOrder'] = dbquery( $query, $values );
	
?>