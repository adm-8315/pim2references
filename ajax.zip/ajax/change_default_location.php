<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/session.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$error = false;
	

	/**
	 * Change Default Location
	 */

		
	$query = "
		UPDATE
			user u
		SET
			u.defaultLocation = ?
		WHERE
			u.userID = ?
	";
	
	$values = array(
		$_POST['defaultLocation'],
		$_SESSION['user_id']
	);
	
	$result['userUpdate'] = dbquery( $query, $values );

	$_SESSION['default_location'] = $_POST['defaultLocation'];

	echo "Default Location Changed";
	
?>