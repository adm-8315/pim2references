<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/session.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$error = false;
	

	/**
	 * Change Password
	 */

	if ( 
		$_POST['passwordNew'] == $_POST['passwordRepeat'] &&
		! empty( $_POST['passwordNew'] )
	) {
		
		$query = "
			SELECT
				u.userID
			FROM
				user u
			WHERE
				u.userID = ?
			AND
				u.active = 1
			AND
				u.passwordHash = ?
		";
		
		$values = array(
			$_SESSION['user_id'],
			sha1( $_POST['passwordCurrent'] )
		);
		
		$result['user'] = dbquery( $query, $values );
		
		if ( $result['user'] )
		{
			
			$query = "
				UPDATE
					user u
				SET
					u.passwordHash = ?
				WHERE
					u.userID = ?
			";
			
			$values = array(
				sha1( $_POST['passwordNew'] ),
				$_SESSION['user_id']
			);
			
			$result['userUpdate'] = dbquery( $query, $values );
			
		}
		else
		{
			$error = true;
		}
		
	} else {
		$error = true;
	}
	
	if ( ! $error )
	{
		echo "Your Password was Changed";
	}
	else
	{
		echo "There was an error";
	}
	
?>