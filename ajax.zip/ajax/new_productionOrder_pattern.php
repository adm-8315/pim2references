<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Location
	
	$query = "
		SELECT
			*
		FROM
			furnacePattern fp
		WHERE
			fp.furnace = ?
	";
	
	$values = array(
		$_POST['new_productionOrder_furnace']
	);
	
	$result['furnacePattern'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo "<option value='-1'>Choose...</option>";
	
	foreach ( $result['furnacePattern'] as $furnacePattern )
	{
		echo "<option value='{$furnacePattern['furnacePatternID']}'>";
		echo $furnacePattern['furnacePattern'] . ": ";
		echo $furnacePattern['patternDescription'] . " - ";
		echo $furnacePattern['patternTemperature'] . "°F for ";
		echo $furnacePattern['patternTime'] . "hr";
		echo "</option>";
	}
	

?>