<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */

	$query = "
		SELECT
			l.locationID,
			l.location
		FROM
			companyLocationLink cll
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		WHERE
			cll.company = ?
		AND
			l.active = 1
		AND
			l.locationID != 22
		ORDER BY
			l.location ASC
	";

	$values = array(
		$_POST['companyID']
	);

	$result['location'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo "<option value='-1'>Choose...</option>";
	
	foreach ( $result['location'] as $row )
	{
		echo "<option value='{$row['locationID']}'>{$row['location']}</option>";
	}

?>