<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/session.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$error = false;
	

	/**
	 * Change Default Owner
	 */

	$query = "
		SELECT
			u.userID
		FROM
			user u
		WHERE
			u.userID = ?
		AND
			u.active = 1
	";
	
	$values = array(
		$_SESSION['user_id']
	);
	
	$result['user'] = dbquery( $query, $values );
	
	$query = "
		SELECT
			c.companyID
		FROM
			company c
		WHERE
			c.companyID = ?
		AND
			c.active = 1
	";
	
	$values = array(
		$_POST['defaultOwner']
	);
	
	$result['company'] = dbquery( $query, $values );
	
	if ( $result['user'] && $result['company'] )
	{
		
		$query = "
			UPDATE
				user u
			SET
				u.defaultOwner = ?
			WHERE
				u.userID = ?
		";
		
		$values = array(
			$_POST['defaultOwner'],
			$_SESSION['user_id']
		);
		
		$result['updateUser'] = dbquery( $query, $values );
		
	}
	else
	{
		$error = true;
	}

	
	if ( ! $error )
	{
		echo "Default Owner Changed";
	}
	else
	{
		echo "There was an error";
	}
	
?>