<?php

	/**
	 * Includes
	 */
	
	require_once('../inc/dbfunc.php');

	
	/**
	 * Variables
	 */

	$csv = "";
	$series = array();
	$seriesSlot = array();
	$rowCount = array();
	$data = array();
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			qct.qcTestID,
			qct.slot,
			UNIX_TIMESTAMP(qct.startTime) as 'startTime'
		FROM
			qcTest qct
		WHERE
			stopTime is null
		OR
			stopTime > NOW()
	";
	
	$values = array(
	);
	
	$result['series'] = dbquery( $query, $values );
	
	foreach( $result['series'] as $row )
	{
		$series[$row['qcTestID']] = $row['startTime'];
		$seriesSlot[$row['qcTestID']] = $row['slot'];
	}
	
	foreach ( $series as $id => $startTime )
	{
		
		$query = "
			SELECT
				UNIX_TIMESTAMP(timestamp) as 'timestamp',
				temperature
			FROM
				qcTestData qctd
			LEFT JOIN
				qcTest qct
				ON qctd.qcTest = qct.qcTestID
			WHERE
				qctd.qcTest = ?
			AND
				qctd.timestamp >= qct.startTime
			AND
				if(
					qct.stopTime is null,
					1,
					qctd.timestamp <= qct.stopTime
				)
		";

		$values = array(
			$id
		);
		
		$result['series'.$id] = dbquery( $query, $values );
		
	}
	

	/**
	 * Process
	 */
	
	foreach ( $series as $id => $startTime )
	{
	
		foreach ( $result['series'.$id] as $row )
		{
		
			$time = ($row['timestamp'] - $startTime);
		
			if ( empty( $data[$time] ) )
			{
				$data[$time] = array();
				for( $i = 1; $i <= 7; $i++ )
				{
					$data[$time][$i] = null;
				}
			}
			
			$data[$time][0] = $time;
			$data[$time][$seriesSlot[$id]] = $row['temperature'];
		
		}
	
	}
	
	ksort( $data );
	
	echo json_encode( $data );
?>