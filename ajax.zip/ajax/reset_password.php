<?php

	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/session.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$error = false;
	

	/**
	 * Change Password
	 */
			
	$query = "
		UPDATE
			user u
		SET
			u.passwordHash = ?
		WHERE
			u.userID = ?
	";
	
	$values = array(
		'124d8ca50944d7e7c6304628d64485ea5a5b3489',
		$_POST['userID']
	);
	
	$result['userUpdate'] = dbquery( $query, $values );
	
	if ( ! $error )
	{
		echo "Password Reset: temporary password is 'changeMe!'";
	}
	else
	{
		echo "There was an error";
	}
	
?>