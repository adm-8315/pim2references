<?php
	
	/**
	 * Includes
	 */
	
	require_once( "../inc/dbfunc.php" );
	require_once( "../inc/dev_tools/print_dev.php" );
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	$processing = array();
	$orderedArray = array();
	$condensedArray = array();
	$outstring = "";
	
	
	/**
	 * MySQL
	 */
	
	// Schedule Load
	
	$query = "
		SELECT
			pos.productionOrder,
			SUM(poml.quantity) as 'materialSum'
		FROM
			productionOrderSchedule pos
		LEFT JOIN
			productionOrder po
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productionOrderMaterialLink poml
			ON po.productionOrderID = poml.productionOrder
		LEFT JOIN
			material m
			ON poml.material = m.materialID
		WHERE
			pourDate = ?
		AND
			(
				m.materialType = 11
				OR m.materialType = 12
				OR m.materialType = 13
				OR m.materialType = 20
				OR m.materialType = 32
				OR m.materialType = 34
			)
		GROUP BY
			pos.productionOrder
	";
	
	$values = array(
		$_POST['pourDate']
	);
	
	$result['schedule_load'] = dbquery( $query, $values );
	
	
	// Batching Load
	
	$query = "
		SELECT
			*
		FROM
			productionOrderScheduleBatching posb
		WHERE
			pourDate = ?
	";
	
	$values = array(
		$_POST['pourDate']
	);
	
	$result['schedule_batching'] = dbquery( $query, $values );
	
	if ( count( $result['schedule_batching'] ) > 0 )
	{
		$pour = json_decode( $result['schedule_batching'][0]['batchingString'], true );
	}
	else
	{
		$pour = null;
	}
	
	// Mixers
	
	$query = "
		SELECT
			*
		FROM
			mixer mix
		WHERE
			mix.active = 1
		ORDER BY
			mix.mixerMax DESC
	";
	
	$values = array();
	
	$result['schedule_mixers'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	
	// Default
	
	foreach( $result['schedule_load'] as $row )
	{
		
		$selected_mixer = $result['schedule_mixers'][0]['mixerID'];
		
		foreach( $result['schedule_mixers'] as $mixer )
		{
			if ( $mixer['mixerMax'] > $row['materialSum'] )
			{
				$selected_mixer = $mixer['mixerID'];
			}
		}
		
		$processing[] = array(
			"mixer" => $selected_mixer,
			"materialSum" => $row['materialSum'],
			"productionOrder" => array(
				$row['productionOrder'] => $row['materialSum']
			)
		);
		
	}
	
	// Merge Production Orders
	
	if ( $pour != null )
	{
		
		foreach ( $pour as $entry )
		{
			
			if ( count( $entry['productionOrder' ] > 1) )
			{
				
				$first = true;
				$poTarget = null;
				$targetIndex = null;
				
				foreach ( $entry['productionOrder'] as $po => $value )
				{
					
					if ( $first )
					{
						
						// select target
						$poTarget = $po;
						
						// find target index
						foreach ( $processing as $index => $row )
						{
						
							foreach ( $row['productionOrder'] as $id => $value )
							{
								if ( $id == $poTarget )
								{
									$targetIndex = $index;
									break;
								}
							}
						
							if ( $targetIndex != null )
							{
								break;
							}
						
						}
						
						$first = false;
						continue;
					}
					
					// look for thing to move
					foreach ( $processing as $index => $row )
					{
						
						foreach ( $row['productionOrder'] as $id => $value )
						{
							if ( $id == $po )
							{
								$processing[$targetIndex]['productionOrder'][$po] = $value;
								$processing[$targetIndex]['materialSum'] += $value;
								unset( $processing[$index]['productionOrder'][$id] );
							}
						}
						
						if ( count( $processing[$index]['productionOrder'] ) == 0 )
						{
							unset( $processing[$index] );
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	
	// Order
	
	if ( $pour != null )
	{
		
		foreach ( $pour as $batchingIndex => $entry )
		{
			reset( $entry['productionOrder'] );
			$targetKey = key( $entry['productionOrder'] );
			
			foreach ( $processing as $index => $row )
			{
				
				reset( $row['productionOrder'] );
				if ( $targetKey == key( $row['productionOrder'] ) )
				{
					
					// add batching
					if ( isset( $entry['batching'] ) )
					{
						$row['batching'] = $entry['batching'];
					}
					
					$orderedArray[$batchingIndex] = $row;
					unset( $processing[$index] );
					
				}
				
			}
		}
		
		if ( ! empty( $processing ) )
		{
			
			foreach ( $processing as $index => $row )
			{
				$orderedArray[] = $row;
				unset( $processing[$index] );
			}
			
		}
		
	}
	else
	{
		$orderedArray = $processing;
	}
	
	// Condense 
	
	ksort( $orderedArray );
	
	$i = 0;
	foreach( $orderedArray as $index => $data )
	{
		$condensedArray[$i] = $data;
		unset( $orderedArray[$index] );
		$i++;
	}
	
	
	
	
	
	//print_dev( $processing );
	
	//print_dev( $condensedArray );
	
	$outstring = json_encode ( $condensedArray, JSON_FORCE_OBJECT );
	
	//print_dev( $outstring );
	
	
	
	/**
	 * Submit
	 */
	
	if ( count( $result['schedule_batching'] ) == 0 )
	{
		
		// Fresh
		
		$query = "
			INSERT INTO
				productionOrderScheduleBatching
				( pourDate, batchingString )
			VALUES
				( ?, ? )
		";
		
		$values = array(
			$_POST['pourDate'],
			$outstring
		);
	
		$result['schedule_auto_batching'] = dbquery( $query, $values );
		
	}
	else
	{
		
		// Update
		
		$query = "
			UPDATE
				productionOrderScheduleBatching
			SET
				batchingString = ?
			WHERE
				pourDate = ?
		";
		
		$values = array(
			$outstring,
			$_POST['pourDate']
		);
	
		$result['schedule_auto_batching'] = dbquery( $query, $values );
		
	}
	
	
	
?>