<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Location
	
	$query = "
		SELECT
			*
		FROM
			material m
		WHERE
			m.materialID = ?
	";
	
	$values = array(
		$_POST['materialID']
	);
	
	$result['material'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	echo json_encode( $result['material'][0] );

?>