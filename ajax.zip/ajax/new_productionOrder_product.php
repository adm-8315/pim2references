<?php

	/**
	 * Includes
	 */
	
	require_once("../inc/dbfunc.php");
	
	
	/**
	 * Variables
	 */
	
	$result = array();
	
	
	/**
	 * MySQL
	 */
	
	// Location
	
	$query = "
		SELECT
			p.productID,
			p.product
		FROM
			product p
		LEFT JOIN
			productConsumerLink pcl
			ON p.productID = pcl.product
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		WHERE
			cll.company = ?
		ORDER BY
			p.product ASC
	";
	
	$values = array(
		$_POST['new_productionOrder_customer']
	);
	
	$result['product'] = dbquery( $query, $values );
	
	
	/**
	 * Display
	 */
	
	foreach ( $result['product'] as $product )
	{
		echo "<option value='{$product['productID']}'>{$product['product']}</option>";
	}
	
?>