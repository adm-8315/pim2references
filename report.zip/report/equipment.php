<?php

	/**
	 * Includes
	 */

	require_once("inc/session.php");


	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 31;
	$headerArray = array(
		"Equipment Type",
		"Equipment",
		"Identifier",
		"Equipment Status"
	);
	
	if ( isset( $_GET['location'] ) )
	{
		$location = $_GET['location'];
	}
	else
	{
		$location = $_SESSION['default_location'];
	}
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			e.equipmentID as 'id',
			'equipment' as 'nav',
			et.equipmentType,
			e.equipment,
			e.identifier,
			es.equipmentStatus
		FROM
			equipment e
		LEFT JOIN
			equipmentType et
			ON e.equipmentType = et.equipmentTypeID
		LEFT JOIN	
			equipmentStatus es
			ON e.equipmentStatus = es.equipmentStatusID
		WHERE
			e.location = ?
		ORDER BY
			et.equipmentType ASC,
			e.equipment ASC
	";
	
	$values = array(
		$location
	);
	
	$result['report'] = dbquery( $query, $values );

?>