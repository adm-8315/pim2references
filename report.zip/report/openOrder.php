<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 42;
	$headerArray = array();
	
	$headerArray = array(
		"Precast Product",
		"Main Material",
		"Open Orders",
		"Date Required"
	);
	
	
	/**
	 * MySQL
	 */
	
	// Queue
	
	$query = "
		SELECT
			po.productionOrderID as 'id',
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			m.material,
			'productionOrder' as 'nav',
			po.quantityOrdered - IFNULL( SUM(pos.quantity), 0 ) as 'quantitySchedule',
			CONCAT(MONTH(po.fillDate),' / ',DAY(po.fillDate),' / ',YEAR(po.fillDate)) as 'fillDate'
		FROM
			productionOrder po
		LEFT JOIN
			productionOrderSchedule pos
			ON pos.productionOrder = po.productionOrderID
		LEFT JOIN
			productConsumerLink pcl
			ON po.product = pcl.product
		LEFT JOIN
			product p
			ON po.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			(
				SELECT
					poml.productionOrder, 
					poml.material,
					poml.quantity
				FROM 
					productionOrderMaterialLink poml
				LEFT JOIN
					(
						SELECT
							poml.*,
							max(poml.quantity) as max
						FROM
							productionOrderMaterialLink poml
						LEFT JOIN
							material m
							ON poml.material = m.materialID
						WHERE
							m.materialType = 11
						OR
							m.materialType = 12
						OR
							m.materialType = 13
						OR
							m.materialType = 18
						OR
							m.materialType = 34
						GROUP BY
							poml.productionOrder
					) max
					ON max.productionOrder = poml.productionOrder
					AND max.max = poml.quantity
				WHERE
					max.max is not null
			) poml
			ON poml.productionOrder = po.productionOrderID
		LEFT JOIN
			material m
			ON poml.material = m.materialID
		WHERE
			po.active = 1
		GROUP BY
			po.productionOrderID
		HAVING
			quantitySchedule > 0
		ORDER BY
			po.fillDate ASC
	";
	
	$values = array();
	
	$result['report'] = dbquery( $query, $values );

?>