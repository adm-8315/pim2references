<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 29;
	$headerArray = array(
		"Job Number",
		"Customer",
		"Location",
		"Description"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			j.jobID as 'id',
			'job' as 'nav',
			j.jobNumber,
			c.company,
			l.location,
			j.description
		FROM
			job j
		LEFT JOIN
			companyLocationLink cll
			ON j.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		WHERE
			j.active = 1
		ORDER BY
			c.company ASC,
			j.jobNumber ASC
	";
	
	$values = array();
	
	$result['report'] = dbquery( $query, $values );

?>