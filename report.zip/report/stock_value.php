<?php

	/**
	 * Variables
	 */
	
	$result['report'] = array();
	$permissionBlock = 5;
	$total = array();
	$headerArray = array(
		"Material",
		"Stock",
		"Inv. Value",
		"Avg. Cost"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			t.productTransactionID,
			i.product,
			t.productInventory,
			t.transactionType,
			t.value,
			t.cost,
			t.timestamp,
			cll.company,
			cll.location
		FROM
			productInventory i
		LEFT JOIN
			productTransaction t
			ON i.productInventoryID = t.productInventory
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		WHERE
			t.timestamp <= ?
		AND
			cll.company = ?
		AND
			t.transactionType != 3
		ORDER BY
			i.product,
			cll.location,
			t.timestamp,
			t.productTransactionID
	";
	
	$values = array(
		$date['end'],
		$owner['id']
	);
	
	$result['temp'] = dbquery( $query, $values );
	
	//print_dev( $result['temp'] );
	
	$query = "
		(
			SELECT
				ma.materialID as 'id',
				'material' as 'nav',
				IF(
					i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
					1,
					0
				) as 'warning',
				mt.materialType as 'materialType',
				ma.material as 'Material',
				IF(
					temp.stock is not null,
					IF(
						temp.stock > 1,
						CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measurePlural ),
						CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measureSingular )
					),
					IF(
						i.stock > 1,
						CONCAT( FORMAT( i.stock, 0 ), ' ', me.measurePlural ),
						CONCAT( FORMAT( i.stock, 0 ), ' ', me.measureSingular )
					)
				) as 'Stock',
				CONCAT(
					'$',
					FORMAT(
						IF(
							temp.avgCost is null,
							temp.stock * ma.cost,
							temp.stock * temp.avgCost
						)
					, 2)
				) as 'Inv. Value',
				CONCAT(
					'$',
					FORMAT( 
						IF(
							temp.avgCost is null,
							ma.cost,
							temp.avgCost
						)
					, 2 )
				) as 'Avg. Cost'
			FROM
				materialInventory i
			LEFT JOIN
				material ma
				ON i.material = ma.materialID
			LEFT JOIN
				materialType mt
				ON ma.materialType = mt.materialTypeID
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				measure me
				ON ma.measure = me.measureID
			LEFT JOIN
				(
					SELECT
						temp.materialInventory,
						temp.stock,
						temp.avgCost,
						temp.company
					FROM
						(
							SELECT
								*
							FROM
								(
									SELECT
										CASE
											WHEN @prev_id != temp.material
											THEN @totalStock := 0
											ELSE null
										END as 'resetTotalStock',
										CASE
											WHEN @prev_id != temp.material
											THEN @averageCost := 0
											ELSE null
										END as 'resetAverageCost',

										IF(
											temp.cost is not null AND @totalStock >= 0,
											@averageCost := ( ( @totalStock * @averageCost ) + ( temp.value * temp.cost ) ) / ( @totalStock + temp.value ),
											@averageCost
										) as 'avgCost',
										CASE
											WHEN temp.transactionType <= 2
											THEN @totalStock := @totalStock + temp.value
											WHEN temp.transactionType > 2 && temp.transactionType != 7
											THEN @totalStock := @totalStock - temp.value
											ELSE @totalStock := temp.value
										END as 'stock',
										temp.materialTransactionID,
										temp.materialInventory,
										temp.timestamp,
										temp.company,
										temp.location,
										@prev_id := temp.material as 'material'
									FROM
										(
											SELECT
												@prev_id := 0,
												@row := 0,
												@total_stock := 0,
												@average_cost := 0.0
										) vars
									JOIN
										(
											SELECT
												mt.materialTransactionID,
												mi.material,
												mi.materialInventoryID as materialInventory,
												mt.transactionType,
												CASE
													WHEN cll2.company is null
													THEN mt.value
													WHEN cll2.company is not null AND cll2.company = ? AND cll2.location = ?
													THEN mt.value * -1
													ELSE mt.value
												END as 'value',
												mt.cost,
												mt.timestamp,
												cll.company,
												cll.location
											FROM
												materialInventory mi
											LEFT JOIN
												materialTransaction mt
												ON mt.materialInventory = mi.materialInventoryID
											LEFT JOIN
												companyLocationLink cll
												ON mi.companyLocationLink = cll.companyLocationLinkID
											LEFT JOIN
												companyLocationLink cll2
												ON mt.companyLocationLink = cll2.companyLocationLinkID
											WHERE
												mt.timestamp <= ?
											AND
												(
													(
														cll.company = ?
													AND
														cll.location = ?
													)
													OR
													(
														cll2.company = ?
													AND
														cll2.location = ?
													)
												)
											ORDER BY
												mt.timestamp,
												mt.materialTransactionID
										) temp
									ORDER BY
										temp.material ASC,
										temp.timestamp ASC,
										temp.materialTransactionID ASC
								) temp
							WHERE
								temp.company = ?
							AND
								temp.location = ?
							ORDER BY
								temp.materialInventory ASC,
								temp.timestamp DESC,
								temp.materialTransactionID DESC
						) temp
					GROUP BY
						temp.material
				) temp
				ON temp.materialInventory = i.materialInventoryID
			WHERE
				temp.stock != 0
			AND
				(
					temp.company = 0
				OR
					FORMAT( temp.avgCost, 2) != 0
				)
			GROUP BY
				i.materialInventoryID
		)
		UNION
		(
			SELECT
				ma.productID as 'id',
				'product' as 'nav',
				IF(
					i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
					1,
					0
				) as 'warning',
				mt.productType as 'productType',
				IF(
					c2.company is null,
					ma.product,
					CONCAT( c2.company, ' ', ma.product)
				) as 'product',
				IF(
					stockCalc.stock is not null,
					IF(
						stockCalc.stock > 1,
						CONCAT( FORMAT( stockCalc.stock, 0 ), ' ', me.measurePlural ),
						CONCAT( FORMAT( stockCalc.stock, 0 ), ' ', me.measureSingular )
					),
					IF(
						i.stock > 1,
						CONCAT( FORMAT( i.stock, 0 ), ' ', me.measurePlural ),
						CONCAT( FORMAT( i.stock, 0 ), ' ', me.measureSingular )
					)
				) as 'Stock',
				CONCAT(
					'$',
					FORMAT(
						IF(
							costCalc.avgCost is null,
							stockCalc.stock * ma.cost,
							stockCalc.stock * costCalc.avgCost
						)
					, 2)
				) as 'Inv. Value',
				CONCAT(
					'$',
					FORMAT( 
						IF(
							costCalc.avgCost is null,
							ma.cost,
							costCalc.avgCost
						)
					, 2 )
				) as 'Avg. Cost'
			FROM
				productInventory i
			LEFT JOIN
				productConsumerLink pcl
				ON i.product = pcl.product
			LEFT JOIN
				product ma
				ON i.product = ma.productID
			LEFT JOIN
				companyLocationLink cll2
				ON pcl.companyLocationLink = cll2.companyLocationLinkID
			LEFT JOIN
				company c2
				ON cll2.company = c2.companyID
			LEFT JOIN
				productType mt
				ON ma.productType = mt.productTypeID
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				measure me
				ON ma.measure = me.measureID
			LEFT JOIN
				(
					SELECT
						temp.product,
						ROUND(temp.avgCost, 2) as 'avgCost'
					FROM
						(
							SELECT
								temp.product,
								temp.avgCost
							FROM
								(
									SELECT
										CASE
											WHEN @prev_id != temp.product
											THEN @totalStock := 0
											ELSE null
										END as 'resetTotalStock',
										CASE
											WHEN @prev_id != temp.product
											THEN @averageCost := 0
											ELSE null
										END as 'resetAverageCost',
				
										IF(
											temp.cost is not null AND @totalStock >= 0,
											@averageCost := ( ( @totalStock * @averageCost ) + ( temp.value * temp.cost ) ) / ( @totalStock + temp.value ),
											@averageCost
										) as 'avgCost',
										CASE
											WHEN temp.transactionType <= 2
											THEN @totalStock := @totalStock + temp.value
											WHEN temp.transactionType > 2 && temp.transactionType != 7
											THEN @totalStock := @totalStock - temp.value
											ELSE @totalStock := temp.value
										END as 'stock',
										temp.productTransactionID,
										temp.productInventory,
										temp.timestamp,
										@prev_id := temp.product as 'product'
									FROM
										(
											SELECT
												@prev_id := 0,
												@total_stock := 0,
												@average_cost := 0.0
										) vars
									JOIN
										(
											SELECT
												pt.productTransactionID,
												pi.product,
												pt.productInventory,
												pt.transactionType,
												pt.value,
												pt.cost,
												pt.timestamp
											FROM
												productTransaction pt
											LEFT JOIN
												productInventory pi
												ON pt.productInventory = pi.productInventoryID
											LEFT JOIN
												product p
												ON pi.product = p.productID
											LEFT JOIN
												companyLocationLink cll
												ON pi.companyLocationLink = cll.companyLocationLinkID
											WHERE
												pt.transactionType != 3
											AND
												pt.timestamp <= ?
											AND
												cll.company = ?
											ORDER BY
												pi.product,
												pt.timestamp,
												pt.productTransactionID
										) temp
								) temp
							ORDER BY
								temp.product,
								temp.timestamp DESC,
								temp.productTransactionID DESC
						) temp
					GROUP BY
						temp.product
				) costCalc
				ON costCalc.product = i.product
			LEFT JOIN
				(
				SELECT
					temp.product,
					temp.stock
				FROM
					(
						SELECT
							*
						FROM
							(
								SELECT
									CASE
										WHEN @prev_id != temp.product
										THEN @totalStock := 0
										ELSE null
									END as 'resetTotalStock',
				
									CASE
										WHEN temp.transactionType <= 2
										THEN @totalStock := @totalStock + temp.value
										WHEN temp.transactionType > 2 && temp.transactionType != 7
										THEN @totalStock := @totalStock - temp.value
										ELSE @totalStock := temp.value
									END as 'stock',
									temp.productTransactionID,
									temp.productInventory,
									temp.timestamp,
									temp.company,
									temp.location,
									@prev_id := temp.product as 'product'
								FROM
									(
										SELECT
											@prev_id := 0,
											@row := 0,
											@total_stock := 0,
											@average_cost := 0.0
									) vars
								JOIN
									(
										SELECT
											pt.productTransactionID,
											pi.product,
											pi.productInventoryID as productInventory,
											pt.transactionType,
											CASE
												WHEN cll2.company is null
												THEN pt.value
												WHEN cll2.company is not null AND cll2.company = ? AND cll2.location = ?
												THEN pt.value * -1
												ELSE pt.value
											END as 'value',
											pt.cost,
											pt.timestamp,
											cll.company,
											cll.location
										FROM
											productInventory pi
										LEFT JOIN
											productTransaction pt
											ON pt.productInventory = pi.productInventoryID
										LEFT JOIN
											companyLocationLink cll
											ON pi.companyLocationLink = cll.companyLocationLinkID
										LEFT JOIN
											companyLocationLink cll2
											ON pt.companyLocationLink = cll2.companyLocationLinkID
										WHERE
											pt.timestamp <= ?
										AND
											(
												(
													cll.company = ?
												AND
													cll.location = ?
												)
												OR
												(
													cll2.company = ?
												AND
													cll2.location = ?
												)
											)
										ORDER BY
											timestamp,
											productTransactionID
									) temp
	
								ORDER BY
									temp.product ASC,
									temp.timestamp ASC,
									temp.productTransactionID ASC
							) temp
						WHERE
							temp.company = ?
						AND
							temp.location = ?
						ORDER BY
							temp.product ASC,
							temp.timestamp DESC,
							temp.productTransactionID DESC
					) temp
				GROUP BY
					temp.product
				) stockCalc
				ON stockCalc.product = i.product
			WHERE
				stockCalc.stock != 0
			AND
				costCalc.avgCost != 0
			GROUP BY
				i.product
		)
		ORDER BY
			materialType ASC,
			material ASC
	";

	$values = array(
		$owner['id'],
		$location['id'],
		
		$date['end'],
		$owner['id'],
		$location['id'],
		$owner['id'],
		$location['id'],
		
		$owner['id'],
		$location['id'],
		
		$date['end'],
		$owner['id'],

		$owner['id'],
		$location['id'],
		
		$date['end'],
		$owner['id'],
		$location['id'],
		$owner['id'],
		$location['id'],
		
		$owner['id'],
		$location['id']
	);

	$result['temp'] = dbquery ( $query, $values );
	
	
	/**
	 * Process
	 */
	
	foreach( $result['temp'] as $row )
	{
		
		$materialType = $row['materialType'];
		unset( $row['materialType'] );
		
		if ( ! isset( $result['report'][$materialType] ) )
		{
			$result['report'][$materialType] = array();
		}
		
		if ( ! isset( $total[$materialType] ) )
		{
			$total[$materialType] = 0;
		}
		
		$result['report'][ $materialType ][] = $row;
		$rowAmount = floatval( str_replace( ",", "", substr( $row['Inv. Value'], 1 ) ) );
		$total[$materialType] += $rowAmount;
		$valueTotal += $rowAmount;
		
	}
	
	foreach ( $result['report'] as $key => $value )
	{
		
		$result['report'][ $key . " ( $" .  number_format( $total[$key], 2 ) . " )"] = $value;
		unset( $result['report'][$key] );
		
	}
	
?>