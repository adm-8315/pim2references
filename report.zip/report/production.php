<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 8;
	$precastResult = array();
	$tundishResult = array();
	$headerArray = array(
		"Product",
		"Quantity Produced"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			p.productID as 'id',
			'product' as 'nav',
			p.productType as 'Material Type',
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'material',
			IF(
				SUM( t.value ) > 1,
				CONCAT( FORMAT( SUM( t.value ), 0 ), ' ', me.measurePlural ),
				CONCAT( FORMAT( SUM( t.value ), 0 ), ' ', me.measureSingular )
			) as 'Used'
		FROM
			productTransaction t
		LEFT JOIN
			productInventory i
			ON t.productInventory = i.productInventoryID
		LEFT JOIN
			productConsumerLink pcl
			ON i.product = pcl.product
		LEFT JOIN
			product p
			ON i.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			companyLocationLink cll2
			ON i.companyLocationLink = cll2.companyLocationLinkID
		LEFT JOIN
			measure me
			ON p.measure = me.measureID
		WHERE
			t.transactionType = 2
		AND
			(
				p.productType = 16
			||
				p.productType = 26
			)
		AND
			cll2.location = ?
		AND
			cll2.company = ?
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		GROUP BY
			t.productInventory
		ORDER BY
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			)
	";

	$values = array(
		$location['id'],
		$owner['id'],
		$date['end'],
		$date['begin']	
	);

	$result['temp'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	foreach ( $result['temp'] as $row )
	{
		
		$materialType = $row['Material Type'];
		unset( $row['Material Type'] );
		
		if ( $materialType == 16 )
		{
			$precastResult[] = $row;
		}
		else if ( $materialType == 26 )
		{
			$tundishResult[] = $row;
		}
		
	}
	
	
	/**
	 * Return
	 */
	
	$result['report']['Precast Products'] = $precastResult;
	$result['report']['Tundishes'] = $tundishResult;
	
?>