<?php

	switch ( $_GET['report'] )
	{

		case 'raw_material_stock':
			$permissionBlock = 2;
			break;
		
		case 'finished_product_stock':
			$permissionBlock = 3;
			break;
		
		case 'tools_accessories_stock':
			$permissionBlock = 4;
			break;
		
		case 'stock_value':
			$permissionBlock = 5;
			break;
		
		case 'tools_accessories_value':
			$permissionBlock = 6;
			break;
		
		case 'material_usage':
			$permissionBlock = 7;
			break;
		
		case 'production':
			$permissionBlock = 8;
			break;
		
		case 'finished_product_sales':
			$permissionBlock = 9;
			break;
		
		case 'scrap':
			$permissionBlock = 10;
			break;
		
		case 'inventory_adjustment':
			$permissionBlock = 11;
			break;
			
		case 'job':
			$permissionBlock = 41;
			break;
		
	}

?>