<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 10;
	$headerArray = array(
		"Material Type",
		"Material",
		"Quantity Scrapped"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			ma.materialID as 'id',
			'material' as 'nav',
			IF(
				i.stockLevelWarning <= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			mt.materialType as 'Material Type',
			ma.material as 'Material',
			IF(
				SUM(t.value) > 1,
				CONCAT(FORMAT(SUM(t.value),0), ' ', me.measurePlural),
				CONCAT(FORMAT(SUM(t.value),0), ' ', me.measureSingular)
			) as 'Scrapped'
		FROM
			materialTransaction t
		LEFT JOIN
			materialInventory i
			ON t.materialInventory = i.materialInventoryID
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			material ma
			ON i.material = ma.materialID
		LEFT JOIN
			materialType mt
			ON ma.materialType = mt.materialTypeID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		WHERE
			t.transactionType = 5
		AND
			cll.location = ?
		AND
			cll.company = ?
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		GROUP BY
			t.materialInventory
		ORDER BY
			mt.materialType ASC,
			ma.material ASC
	";

	$values = array(
		$location['id'],
		$owner['id'],
		$date['end'],
		$date['begin']	
	);

	$result['report']['Material'] = dbquery( $query, $values );
	
	$query = "
		SELECT
			ma.productID as 'id',
			'product' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			mt.productType as 'Material Type',
			ma.product as 'material',
			IF(
				SUM(t.value) > 1,
				CONCAT(FORMAT(SUM(t.value),0), ' ', me.measurePlural),
				CONCAT(FORMAT(SUM(t.value),0), ' ', me.measureSingular)
			) as 'Scrapped'
		FROM
			productTransaction t
		LEFT JOIN
			productInventory i
			ON t.productInventory = i.productInventoryID
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			product ma
			ON i.product = ma.productID
		LEFT JOIN
			productType mt
			ON ma.productType = mt.productTypeID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		WHERE
			t.transactionType = 5
		AND
			cll.location = ?
		AND
			cll.company = ?
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		GROUP BY
			t.productInventory
		ORDER BY
			mt.productType ASC,
			ma.product ASC
	";
	
	$result['report']['Product'] = dbquery( $query, $values );
	
	
?>