<?php

	/**
	 * Variables
	 */
	
	$result['report'] = array();
	$permissionBlock = 11;
	$headerArray = array(
		"Date",
		"Material Type",
		"Material",
		"Owner",
		"Location",
		"Adjustment",
		"Notes"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			ma.materialID as 'id',
			'material' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			t.timestamp as 'Date',
			mt.materialType as 'Material Type',
			ma.material as 'Material',
			c.company as 'Owner',
			l.location as 'Location',
			FORMAT( IF(
				SUM(t.value) > 1,
				CONCAT(SUM(t.value), ' ', me.measurePlural),
				CONCAT(SUM(t.value), ' ', me.measureSingular)
			), 0) as 'Adjustment',
			t.notes
		FROM
			materialTransaction t
		LEFT JOIN
			materialInventory i
			ON t.materialInventory = i.materialInventoryID
		LEFT JOIN
			material ma
			ON i.material = ma.materialID
		LEFT JOIN
			materialType mt
			ON ma.materialType = mt.materialTypeID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		WHERE
			t.transactionType = 7
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		AND
			cll.location = ?
		GROUP BY
			t.materialInventory
		ORDER BY
			mt.materialType, ma.material ASC
	";

	$values = array(
		$date['end'],
		$date['begin'],
		$location['id']	
	);

	$result['report']['Material'] = dbquery( $query, $values );
	
	
	$query = "
		SELECT
			ma.productID as 'id',
			'product' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			t.timestamp as 'Date',
			mt.productType as 'product Type',
			ma.product as 'product',
			c.company as 'Owner',
			l.location as 'Location',
			FORMAT( IF(
				SUM(t.value) > 1,
				CONCAT(SUM(t.value), ' ', me.measurePlural),
				CONCAT(SUM(t.value), ' ', me.measureSingular)
			), 0) as 'Adjustment',
			t.notes
		FROM
			productTransaction t
		LEFT JOIN
			productInventory i
			ON t.productInventory = i.productInventoryID
		LEFT JOIN
			product ma
			ON i.product = ma.productID
		LEFT JOIN
			productType mt
			ON ma.productType = mt.productTypeID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			location l
			ON cll.location = l.locationID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		WHERE
			t.transactionType = 7
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		AND
			cll.location = ?
		GROUP BY
			t.productInventory
		ORDER BY
			mt.productType, ma.product ASC
	";
	
	$result['report']['Product'] = dbquery( $query, $values );
	
	
?>