<?php
	
	/**
	 * Variables
	 */
	
	$result['report'] = array();
	$permissionBlock = 7;
	$headerArray = array(
		"Material Type",
		"Material",
		"Quantity Used"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			ma.materialID as 'id',
			'material' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			mt.materialType as 'Material Type',
			ma.material as 'Material',
			IF(
				SUM(t.value) > 1,
				CONCAT( FORMAT( SUM( t.value ), 0 ), ' ', me.measurePlural ),
				CONCAT( FORMAT( SUM( t.value ), 0 ), ' ', me.measureSingular )
			) as 'Used'
		FROM
			materialTransaction t
		LEFT JOIN
			materialInventory i
			ON t.materialInventory = i.materialInventoryID
		LEFT JOIN
			companyLocationLink cll
			ON i.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			material ma
			ON i.material = ma.materialID
		LEFT JOIN
			materialType mt
			ON ma.materialType = mt.materialTypeID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		WHERE
			t.transactionType = 6
		AND
			cll.location = ?
		AND
			cll.company = ?
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		GROUP BY
			t.materialInventory
		ORDER BY
			mt.materialType ASC,
			ma.material ASC
	";
	
	$values = array(
		$location['id'],
		$owner['id'],
		$date['end'],
		$date['begin']	
	);
	
	$result['report'] = dbquery( $query, $values );
	
	
?>