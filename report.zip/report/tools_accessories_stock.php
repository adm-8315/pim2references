<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 4;
	$headerArray = array(
		"Owner",
		"Material",
		"Stock"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			ma.materialID as 'id',
			'material' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			c.company as 'Owner',
			ma.material as 'Material',
			IF(
				temp.stock is not null,
				IF(
					temp.stock > 1,
					CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measurePlural ),
					CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measureSingular )
				),
				IF(
					i.stock > 1,
					CONCAT( FORMAT( i.stock, 0 ), ' ', me.measurePlural ),
					CONCAT( FORMAT( i.stock, 0 ), ' ', me.measureSingular )
				)
			) as 'Stock'
			FROM
				materialInventory i
			LEFT JOIN
				material ma
				ON i.material = ma.materialID
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				materialType mt
				ON ma.materialType = mt.materialTypeID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				measure me
				ON ma.measure = me.measureID
			LEFT JOIN
				(
					SELECT
						temp.materialInventory,
						temp.stock
					FROM
						(
							SELECT
								*
							FROM
								(
									SELECT
										CASE
											WHEN @prev_id != temp.materialInventory
											THEN @totalStock := 0
											ELSE null
										END as 'resetTotalStock',

										CASE
											WHEN temp.transactionType <= 2
											THEN @totalStock := @totalStock + temp.value
											WHEN temp.transactionType > 2 && temp.transactionType != 7
											THEN @totalStock := @totalStock - temp.value
											ELSE @totalStock := temp.value
										END as 'stock',
										temp.materialTransactionID,
										temp.material,
										temp.timestamp,
										@prev_id := temp.materialInventory as 'materialInventory'
									FROM
										(
											SELECT
												@prev_id := 0,
												@row := 0,
												@total_stock := 0
										) vars
									JOIN
										(
											(
												SELECT
													t.materialTransactionID,
													i.material,
													t.materialInventory,
													t.transactionType,
													t.value,
													t.cost,
													t.timestamp
												FROM
													materialInventory i
												LEFT JOIN
													materialTransaction t
													ON i.materialInventoryID = t.materialInventory
												LEFT JOIN
													companyLocationLink cll
													ON i.companyLocationLink = cll.companyLocationLinkID
												WHERE
													t.timestamp <= ?
												AND
													cll.location = ?
												ORDER BY
													i.material,
													t.timestamp,
													t.materialTransactionID
											)
										UNION
											(
												SELECT
													t.materialTransactionID,
													i.material,
													i2.materialInventoryID as materialInventory,
													t.transactionType,
													t.value * -1 as value,
													t.cost,
													t.timestamp
												FROM
													materialTransaction t
												LEFT JOIN
													materialInventory i
													ON t.materialInventory = i.materialInventoryID
												LEFT JOIN
													materialInventory i2
													ON i2.material = i.material
													AND i2.companyLocationLink = t.companyLocationLink
												LEFT JOIN
													companyLocationLink cll
													ON cll.companyLocationLinkID = t.companyLocationLink
												WHERE
													t.transactionType = 3
												AND
													t.companyLocationLink is not null
												AND														
													t.timestamp <= ?
												AND
													cll.location = ?
											)
										) temp
									ORDER BY
										temp.materialInventory ASC,
										temp.timestamp ASC,
										temp.materialTransactionID ASC
								) temp
							ORDER BY
								temp.materialInventory ASC,
								temp.timestamp DESC,
								temp.materialTransactionID DESC
						) temp
					GROUP BY
						temp.materialInventory
				) temp
				ON temp.materialInventory = i.materialInventoryID
			WHERE
				ma.materialType = 24
			AND
				temp.stock != 0
			GROUP BY
				i.materialInventoryID
			ORDER BY
				mt.materialType,
				ma.material,
				c.company
	";

	$values = array(
		$date['end'],
		$location['id'],
		$date['end'],
		$location['id']
	);
	
	$result['report'] = dbquery( $query, $values );
	
	
?>