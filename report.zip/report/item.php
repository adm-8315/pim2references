<?php

	/**
	 * Includes
	 */
	
	require_once("inc/session.php");
	

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 33;
	$headerArray = array(
		"Item Type",
		"Item",
		"Amount"
	);
	
	if ( isset( $_GET['location'] ) )
	{
		$location = $_GET['location'];
	}
	else
	{
		$location = $_SESSION['default_location'];
	}
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			i.itemID as 'id',
			'item' as 'nav',
			it.itemType,
			i.item,
			IF(
				ii.stock is null,
				0,
				ii.stock
			) as 'amount'
		FROM
			item i
		LEFT JOIN
			itemType it
			ON i.itemType = it.itemTypeID
		LEFT JOIN
			itemInventory ii
			ON i.itemID = ii.item
			AND ii.location = ?
		ORDER BY
			it.itemType,
			i.item
	";
	
	$values = array(
		$location
	);
	
	$result['report'] = dbquery( $query, $values );

?>