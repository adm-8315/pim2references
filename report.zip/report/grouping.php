<?php
	
	/**
	 * Includes
	 */

	require_once("inc/session.php");


	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 32;
	$headerArray = array(
		"Grouping"
	);
	
	if ( isset( $_GET['location'] ) )
	{
		$location = $_GET['location'];
	}
	else
	{
		$location = $_SESSION['default_location'];
	}
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			g.groupingID as 'id',
			'grouping' as 'nav',
			g.grouping
		FROM
			grouping g
		WHERE
			g.location = ?
	";
	
	$values = array(
		$location
	);
	
	$result['report'] = dbquery( $query, $values );

?>