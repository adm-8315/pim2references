<?php

	/**
	 * Variables
	 */
	
	$result['report'] = array();
	$permissionBlock = 3;
	$precastResult = array();
	$tundishResult = array();
	$headerArray = array(
		"Owner",
		"Material",
		"Stock"
	);
	
	
	/**
	 * MySQL
	 */
	
	$query = "
		SELECT
			p.productID as 'id',
			'product' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			c2.company as 'owner',
			p.productType as 'Material Type',
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			) as 'product',
			IF(
				temp.stock is not null,
				IF(
					temp.stock > 1,
					CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measurePlural ),
					CONCAT( FORMAT( temp.stock, 0 ), ' ', me.measureSingular )
				),
				IF(
					i.stock > 1,
					CONCAT( FORMAT( i.stock, 0 ), ' ', me.measurePlural ),
					CONCAT( FORMAT( i.stock, 0 ), ' ', me.measureSingular )
				)
			) as 'Stock'
		FROM
			productInventory i
		LEFT JOIN
			productConsumerLink pcl
			ON i.product = pcl.product
		LEFT JOIN
			product p
			ON i.product = p.productID
		LEFT JOIN
			companyLocationLink cll
			ON pcl.companyLocationLink = cll.companyLocationLinkID
		LEFT JOIN
			company c
			ON cll.company = c.companyID
		LEFT JOIN
			companyLocationLink cll2
			ON i.companyLocationLink = cll2.companyLocationLinkID
		LEFT JOIN
			company c2
			ON cll2.company = c2.companyID
		LEFT JOIN
			measure me
			ON p.measure = me.measureID
		LEFT JOIN
			(
				SELECT
					temp.productInventory,
					temp.stock
				FROM
					(
						SELECT
							*
						FROM
							(
								SELECT
									CASE
										WHEN @prev_id != temp.productInventory
										THEN @totalStock := 0
										ELSE null
									END as 'resetTotalStock',

									CASE
										WHEN temp.transactionType <= 2
										THEN @totalStock := @totalStock + temp.value
										WHEN temp.transactionType > 2 && temp.transactionType != 7
										THEN @totalStock := @totalStock - temp.value
										ELSE @totalStock := temp.value
									END as 'stock',
									temp.productTransactionID,
									temp.product,
									temp.timestamp,
									@prev_id := temp.productInventory as 'productInventory'
								FROM
									(
										SELECT
											@prev_id := 0,
											@row := 0,
											@total_stock := 0
									) vars
								JOIN
									(
										(
											SELECT
												t.productTransactionID,
												i.product,
												t.productInventory,
												t.transactionType,
												t.value,
												t.cost,
												t.timestamp
											FROM
												productInventory i
											LEFT JOIN
												productTransaction t
												ON i.productInventoryID = t.productInventory
											LEFT JOIN
												companyLocationLink cll
												ON i.companyLocationLink = cll.companyLocationLinkID
											WHERE
												t.timestamp <= ?
											AND
												cll.location = ?
											ORDER BY
												i.product,
												t.timestamp,
												t.productTransactionID
										)
									UNION
										(
											SELECT
												t.productTransactionID,
												i.product,
												i2.productInventoryID as productInventory,
												t.transactionType,
												t.value * -1 as value,
												t.cost,
												t.timestamp
											FROM
												productTransaction t
											LEFT JOIN
												productInventory i
												ON t.productInventory = i.productInventoryID
											LEFT JOIN
												productInventory i2
												ON i2.product = i.product
												AND i2.companyLocationLink = t.companyLocationLink
											LEFT JOIN
												companyLocationLink cll
												ON cll.companyLocationLinkID = t.companyLocationLink
											WHERE
												t.transactionType = 3
											AND
												t.companyLocationLink is not null
											AND														
												t.timestamp <= ?
											AND
												cll.location = ?
									
										)
									) temp
								ORDER BY
									temp.productInventory ASC,
									temp.timestamp ASC,
									temp.productTransactionID ASC
							) temp
						ORDER BY
							temp.productInventory ASC,
							temp.timestamp DESC,
							temp.productTransactionID DESC
					) temp
				GROUP BY
					temp.productInventory
			) temp
			ON temp.productInventory = i.productInventoryID
		WHERE
			(
				p.productType = 16
			OR
				p.productType = 26
			)
		AND
			temp.stock != 0
		GROUP BY
			i.productInventoryID
		ORDER BY
			c2.company,
			IF(
				c.company is null,
				p.product,
				CONCAT( c.company, ' ', p.product)
			)
	";
	
	
	
	$values = array(
		$date['end'],
		$location['id'],
		$date['end'],
		$location['id']
	);
	
	$result['temp'] = dbquery( $query, $values );
	
	
	/**
	 * Process
	 */
	
	foreach ( $result['temp'] as $row )
	{
		
		$materialType = $row['Material Type'];
		unset( $row['Material Type'] );
		
		if ( $materialType == 16 )
		{
			$precastResult[] = $row;
		}
		else if ( $materialType == 26 )
		{
			$tundishResult[] = $row;
		}
		
	}
	
	
	/**
	 * Return
	 */
	
	$result['report']['Precast Products'] = $precastResult;
	$result['report']['Tundishes'] = $tundishResult;
	
?>