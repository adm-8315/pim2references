<?php

	/**
	 * Variables
	 */

	$result['report'] = array();
	$permissionBlock = 9;
	$precastResult = array();
	$tundishResult = array();
	$headerArray = array(
		"Date",
		"Customer",
		"Shipping Location",
		"Material",
		"Sold"
	);
	
	
	/**
	 * MySQL
	 */

	$query = "
		SELECT
			ma.productID as 'id',
			'product' as 'nav',
			IF(
				i.stockLevelWarning >= i.stock && i.stockLevelWarning > 0,
				1,
				0
			) as 'warning',
			ma.productType as 'Product Type',
			t.timestamp as 'Date',
			c1.company as 'Customer',
			l1.location 'Shipping Location',	
			ma.product as 'product',
			FORMAT( IF(
				t.value > 1,
				CONCAT( t.value, ' ', me.measurePlural ),
				CONCAT( t.value, ' ', me.measureSingular )
			), 0) as 'Sold'
		FROM
			productTransaction t
		LEFT JOIN
			productInventory i
			ON t.productInventory = i.productInventoryID
		LEFT JOIN
			product ma
			ON i.product = ma.productID
		LEFT JOIN
			measure me
			ON ma.measure = me.measureID
		LEFT JOIN
			companyLocationLink cll1
			ON t.companyLocationLink = cll1.companyLocationLinkID
		LEFT JOIN
			company c1
			ON cll1.company = c1.companyID
		LEFT JOIN
			location l1
			ON cll1.location = l1.locationID
		LEFT JOIN
			companyLocationLink cll2
			ON i.companyLocationLink = cll2.companyLocationLinkID
		LEFT JOIN
			company c2
			ON cll2.company = c2.companyID
		LEFT JOIN
			location l2
			ON cll2.location = l2.locationID
		WHERE
			t.transactionType = 4
		AND
			(
				ma.productType = 16
				OR
				ma.productType = 26
			)
		AND
			cll2.location = ?
		AND
			cll2.company = ?	
		AND
			t.timestamp <= ?
		AND
			t.timestamp >= ?
		ORDER BY
			ma.product ASC
	";

	$values = array(
		$location['id'],
		$owner['id'],
		$date['end'],
		$date['begin']	
	);

	$result['temp'] = dbquery ( $query, $values );
	
	
	/**
	 * Process
	 */
	
	foreach ( $result['temp'] as $row )
	{
		
		$materialType = $row['Product Type'];
		unset( $row['Product Type'] );
		
		if ( $materialType == 16 )
		{
			$precastResult[] = $row;
		}
		else if ( $materialType == 26 )
		{
			$tundishResult[] = $row;
		}
		
	}
	
	
	/**
	 * Return
	 */
	
	$result['report']['Precast Products'] = $precastResult;
	$result['report']['Tundishes'] = $tundishResult;
	
?>