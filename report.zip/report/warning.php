<?php
	
	/**
	 * Variables
	 */

	$result = array();
	$result['report'] = array();
	
	$result['report']['Material'] = array();
	$result['report']['Product'] = array();
	
	$headerArray = array();
	
	$headerArray['Material'] = array(
		"Material",
		"Company",
		"Location",
		"Stock",
		"Warning Level"
	);
	
	$headerArray['Product'] = array(
		"Product",
		"Company",
		"Location",
		"Stock",
		"Warning Level"
	);


	/**
	 * MySQL
	 */

	$query = "
		(
			SELECT
				m.materialID as 'id',
				'material' as 'nav',
				m.material,
				c.company,
				l.location,
				i.stock,
				i.stockLevelWarning,
				'Material' as 'category'
			FROM
				materialInventory i
			LEFT JOIN
				material m
				ON i.material = m.materialID
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				location l
				ON cll.location = l.locationID
			WHERE
				i.stock <= i.stockLevelWarning
			AND
				i.stockLevelWarning != 0
		)
		UNION
		(
			SELECT
				m.productID as 'id',
				'product' as 'nav',
				m.product,
				c.company,
				l.location,
				i.stock,
				i.stockLevelWarning,
				'Product' as 'category'
			FROM
				productInventory i
			LEFT JOIN
				product m
				ON i.product = m.productID
			LEFT JOIN
				companyLocationLink cll
				ON i.companyLocationLink = cll.companyLocationLinkID
			LEFT JOIN
				company c
				ON cll.company = c.companyID
			LEFT JOIN
				location l
				ON cll.location = l.locationID
			WHERE
				i.stock <= i.stockLevelWarning
			AND
				i.stockLevelWarning != 0
		)
	";

	$values = array();

	$result['stockLevelWarning'] = dbquery( $query, $values );


	/**
	 * Process
	 */

	foreach( $result['stockLevelWarning'] as $row )
	{
	
		$category = $row['category'];
		unset( $row['category'] );
	
		$result['report'][ $category ][] = $row;
	
	}

?>