if( typeof overlay_productionOrder_material_filter != 'function' )
{
	
	window.overlay_productionOrder_material_json = function ()
	{
				
		var out = {};
		
		$(".edit_material").each( function () {
			
			out[$(this).attr("data-material")] = {
				"quantity": $(".quantity[data-material='" + $(this).attr("data-material") + "']").val(),
				"material": $(this).val(),
				"water": 	$(".water[data-material='" + $(this).attr("data-material") + "']").val(), 
				"mix": 		$(".mix[data-material='" + $(this).attr("data-material") + "']").val(),
				"vibType": 	$(".vibType[data-material='" + $(this).attr("data-material") + "']").val(),
				"vibTime": 	$(".vibTime[data-material='" + $(this).attr("data-material") + "']").val()
			};
			
		});
		
		out["notes"] = $("#material_notes").val();
		
		$("#productionOrder_material_values").val( JSON.stringify(out) );
		
	}
	
	window.overlay_productionOrder_material_filter = function ( trigger )
	{
		
		var index = trigger.data("material");
		var selected = $(".edit_material[data-material='" + index + "'] option:selected").val();
		var material = $(".edit_material[data-material='" + index + "']");
		var manufacturer = $(".manufacturer[data-material='" + index + "']");
		var materialType = $(".materialType[data-material='" + index + "']");
		
		if ( $(trigger).hasClass( "materialType" ) )
		{
			$(manufacturer).find("option[value='-1']").attr( "selected", "selected" );
		}
		
		var filter = "";
		
		if ( materialType.val() != -1 )
		{
			filter += "[data-type='" + materialType.val() + "']";
		}
		
		if ( manufacturer.val() != -1 )
		{
			filter += "[data-man='" + manufacturer.val() + "']";
		}
		
		//console.log( "index: " + index );
		//console.log( "material: " + material.data("material") );
		//console.log( "selected: " + selected );
		//console.log( "manufacturer: " + manufacturer.data("material") );
		//console.log( "materialType: " + materialType.data("material") );
		
		
		$(material).children("option").remove();
		
		if ( filter != "" )
		{
			$(materialListing).filter(filter + ", [value='-1']").each( function () {
				$(material).append( $(this).clone() );		            
	        });
		}
		else
		{
			$(material).append( materialListing );
		}
		
		$(material).find("option[value='-1']").attr("selected", "selected");
		$(material).find("option[value='" + selected + "']").attr("selected", "selected");
		
	}
		
		
	window.overlay_productionOrder_material_stds = function ( trigger )
	{
		
		var triggerMaterial = trigger.data("material");
		
		$(".water[data-material='" + triggerMaterial + "']").val( "" );
		$(".mix[data-material='" + triggerMaterial + "']").val( "" );
		
		if ( 
			trigger.val() != '-1' &&
			trigger.find("option:selected").data("type") == '11' 
		) {
			$("#material_" + triggerMaterial + "_mfgWater").addClass("material_water_hook");
			$("#material_" + triggerMaterial + "_mfgMix").addClass("material_mix_hook");
			
			request = $.ajax({
				url: "ajax/material_standards.php",
				type: "post",
				data: "materialID=" +
					trigger.val()
			}).done( function ( response, textStatus, jqXHR) {
				
				var jsonVars = JSON.parse( response );
				
				var waterString = "";
				
				if ( jsonVars['stdWater'] != null )
				{
					waterString = waterString + "Std. " + jsonVars['stdWater'] + "% | ";
				}
				else
				{
					waterString = waterString + "Std. Not Set | ";
				}
				
				if ( jsonVars['waterLow'] != null || jsonVars['waterHigh'] != null )
				{
					waterString = waterString + "Mfg. Rec. " + jsonVars['waterLow'] + "% - " + jsonVars['waterHigh'] + "%";
				}
				else
				{
					waterString = waterString + "Mfg. Rec. Not Recorded";
				}
				
				var mixString = "";
				
				if ( jsonVars['stdMix'] != null )
				{
					mixString = mixString + "Std. " + jsonVars['stdMix'] + "min | ";
				}
				else
				{
					mixString = mixString + "Std. Not Set | ";
				}
				
				if ( jsonVars['mixLow'] != null || jsonVars['mixHigh'] != null )
				{
					mixString = mixString + "Mfg. Rec. " + jsonVars['mixLow'] + "min - " + jsonVars['mixHigh'] + "min";
				}
				else
				{
					mixString = mixString + "Mfg. Rec. Not Recorded";
				}
				
				$(".water[data-material='" + triggerMaterial + "']").val( jsonVars['stdWater'] );
				$(".mix[data-material='" + triggerMaterial + "']").val( jsonVars['stdMix'] );
				$("#material_" + triggerMaterial + "_mfgWater").attr( "data-title", ( waterString ) );
				$("#material_" + triggerMaterial + "_mfgMix").attr( "data-title", ( mixString ) );
				
			});
		}
		else
		{
			$("#material_" + triggerMaterial + "_mfgWater").removeClass("material_water_hook");
			$("#material_" + triggerMaterial + "_mfgMix").removeClass("material_mix_hook");
		}
		
		var nonEmptyMaterials = 0;
		var maxMaterial = -1;
		
		$("#edit_material_table .quantity").each( function () {
							
			if ( 
				$(this).val() != "" && 
				$(this).val() > 0 &&
				$("#edit_material_table .edit_material[data-material='" + $(this).data("material") + "']").data("type") == '34'
			) {
				nonEmptyMaterials += 1;
				
				if ( maxMaterial == -1 ) 
				{
					maxMaterial = $(this).data("material");
				}
				else if ( $("#edit_material_table .quantity[data-material='" + maxMaterial + "']").val() < $(this).val() )
				{
					maxMaterial = $(this).data("material");
				}
				
			}
			
		});
		
		if (
			trigger.val() != '-1' &&
			trigger.find("option:selected").data("type") == '34' &&
			nonEmptyMaterials > 0
		) {
			console.log("go");
		}

		$(".measure[data-material='" + triggerMaterial + "']").html( trigger.find("option:selected").data("measure") );
					
	}
	
}