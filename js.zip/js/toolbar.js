(function($) {
	
	/**
	 * Variables
	 */

	var request;
	
	
	/**
	 * Triggers
	 */

	$(document).on("click", ".toolbar_button", function() {
		$(this).parent().children(".toolbar_button_options").toggle();
	});

	$(document).on("mouseleave", ".toolbar_container", function() {
		$(this).children(".toolbar_button_options").hide();
	});



	$(document).on("click", "#toolbar_application_button", function() {
		$(this).parent().children(".toolbar_button_options").toggle();
	});

	$(document).on( "click", "#toolbar_location .toolbar_button_options .option, #toolbar_owner .toolbar_button_options .option", function() {
		
		$(this).parent().children().each(function() {
			$(this).removeClass("selected");
		});

		$(this).addClass("selected");
		
		generateURL( );
		
	});

	$(document).on("click touchstart", ".toolbar_button_options .option[data-nav='user_profile']", function() {
		generateURL( $(this) );
	});
	
	$(document).on("click touchstart", ".toolbar_button_options .option[data-nav='permissions']", function() {
		generateURL( $(this) );
	});

	$(document).on("click", "#toolbar_datepicker_begin .toolbar_button", function(e) {

		if ($dpb.datepicker("widget").is(":hidden")) {

			$(".ui-datepicker-trigger").show();

			$dpb.datepicker("show").datepicker("widget").show().position({
				my: "left top",
				at: "left bottom",
				of: this
			});

			$(".ui-datepicker-trigger").hide();

		} else {
			$dpb.hide();
		}

		e.preventDefault();

	});

	$(document).on("click", "#toolbar_datepicker_end .toolbar_button", function(e) {

		if ($dpe.datepicker("widget").is(":hidden")) {

			$(".ui-datepicker-trigger").show();

			$dpe.datepicker("show").datepicker("widget").show().position({
				my: "left top",
				at: "left bottom",
				of: this
			});

			$(".ui-datepicker-trigger").hide();

		} else {
			$dpe.hide();
		}

		e.preventDefault();

	});

	$(document).on("click", "#toolbar_company", function(e) {

		var url_split = document.URL.split("?");

		window.location.href = url_split[0] + "?nav=add_customer";

	});

	$(document).on("click", "#toolbar_warning", function(e) {

		var url_split = document.URL.split("?");

		window.location.href = url_split[0] + "?nav=report&report=warning";

	});

	$(document).on("click", "#toolbar_edit", function (e) {

		var url_split = document.URL.split("?");

		window.location.href = url_split[0] + "?nav=editor";

	});
	
	$(document).on("click", "#toolbar_left", function() {
		
		var url_split = document.URL.split("?");
		var get_split = url_split[1].split("&");
		var week = 0;
		var found = false;
		
		$.each( get_split, function ( index, value ) {
			
			var value_split = value.split("=");
			
			if ( value_split[0] == 'week' )
			{
				week = parseInt( value_split[1] ) - 1;
				found = true;
			}
			
		});
		
		if ( ! found )
		{
			week = -1;
		}

		window.location.href = url_split[0] + "?nav=schedule&week=" + week;
		
	});
	
	$(document).on("click", "#toolbar_right", function() {
		
		var url_split = document.URL.split("?");
		var get_split = url_split[1].split("&");
		var week = 0;
		var found = false;
		
		$.each( get_split, function ( index, value ) {
			
			var value_split = value.split("=");
			
			if ( value_split[0] == 'week' )
			{
				week = parseInt( value_split[1] ) + 1;
				found = true;
			}
			
		});
		
		if ( ! found )
		{
			week = 1;
		}

		window.location.href = url_split[0] + "?nav=schedule&week=" + week;
		
	});
	
	
	/**
	 * Toolbar
	 */
	
	$(document).ready(function() {

		/**
		 * Begin Date Picker
		 */

		var defaultDate = "";
		var maxDate = "";

		if ($("#datepicker_begin").val() != "") {
			defaultDate = $("#datepicker_begin").val();
		} else {
			defaultDate = new Date();
			defaultDate.setMonth(defaultDate.getMonth(), 1);
			defaultDate = (defaultDate.getMonth() + 1) + '/' + defaultDate.getDate() + '/' + defaultDate.getFullYear();
		}

		if ($("#datepicker_end").val() != "") {
			maxDate = $("#datepicker_end").val();
		} else {
			maxDate = '0';
		}


		$dpb = $("#datepicker_begin").datepicker({
			beforeShow: function(input, inst) {
				var offset = $("#toolbar_datepicker_begin .toolbar_button").offset();
				var height = $("#toolbar_datepicker_begin .toolbar_button").height();
				window.setTimeout(function() {
					inst.dpDiv.css({
						top: (offset.top + height - 10) + 'px',
						left: offset.left + 'px'
					})
				}, 1);
			},
			defaultDate: defaultDate,
			maxDate: maxDate,
			showOn: "button",
			buttonImage: "img/calendar.png",
			buttonImageOnly: true,
			onSelect: function(dateText, inst) {
				generateURL();
			}
		});

		/**
		 * End Date Picker
		 */

		var defaultDate = "";
		var minDate = "";

		if ($("#datepicker_end").val() != "") {
			defaultDate = $("#datepicker_end").val();
		} else {
			defaultDate = new Date();
			defaultDate = (defaultDate.getMonth() + 1) + '/' + defaultDate.getDate() + '/' + defaultDate.getFullYear();
		}


		if ($("#datepicker_begin").length != 0) {

			if ($("#datepicker_begin").datepicker("getDate") == null) {
				minDate = $("#datepicker_begin").datepicker("option", "defaultDate");
			} else {
				minDate = $("#datepicker_begin").datepicker("getDate");
			}

		} else {
			minDate = null;
		}

		var maxDate = new Date();

		$dpe = $("#datepicker_end").datepicker({
			beforeShow: function(input, inst) {
				var offset = $("#toolbar_datepicker_end .toolbar_button").offset();
				var height = $("#toolbar_datepicker_end .toolbar_button").height();
				window.setTimeout(function() {
					inst.dpDiv.css({
						top: (offset.top + height - 10) + 'px',
						left: offset.left + 'px'
					})
				}, 1);
			},
			defaultDate: defaultDate,
			minDate: minDate,
			showOn: "button",
			buttonImage: "img/calendar.png",
			buttonImageOnly: true,
			maxDate: maxDate,
			onSelect: function(dateText, inst) {
				generateURL();
			}
		});

		$(".ui-datepicker-trigger").hide();

	});
	
})(jQuery);