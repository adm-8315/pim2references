/**
 * Overlay v2.0
 */

// Variables
var init = true;
var refresh = true;
var overlay;
var request;
var current_page_index = 0;
var overlay_setup = new Array();
var overlay_open;

// Triggers
$(document).on("ready", function () {
	
	$(document).on('click', '#screen_overlay', function (e) {
	
		if ( $(e.target).attr("id") == "screen_overlay" )
		{	
		    overlay_show( false );
		}
		
		$(".ui-dialog-titlebar-close").trigger('click');

	});

	$(document).on("click", ".overlay_button.forward.active.valid", function () {
		overlay_update( overlay, true );
	});

	$(document).on("click", ".overlay_button.back.active:not(.overlaySwitch)", function () {
		overlay_update( overlay, false );
	});

	$(document).ajaxStart( function () {
		$("#spinner").show();
	}).ajaxStop( function () {
		$("#spinner").hide();
	});

});

// Functions
function overlay_create ( input )
{
		
	overlay = input;
	
	// Dynamic DIVs
	if ( $("#spinner").length === 0 ) 
	{
		$("body").prepend("<p id='spinner' style='display: none;'>Please wait while we do what we do best.</p>");
	}
	
	if ( $("#screen_overlay").length === 0 ) 
	{
		$("body").prepend("<div id='screen_overlay'></div>");
	}

	if ( $("#screen_overlay_content").length === 0 ) 
	{
		$("#screen_overlay").prepend("<div id='screen_overlay_content'></div>");
	} 
	
	current_page_index = 0;
	
	$("#screen_overlay_content").html("");
	
		
	// Title
	
	if ( overlay.title )
	{
		$("#screen_overlay_content").append( "<h4>" + overlay.title + "</h4>" );
	}
	
	
	// Update
	
	overlay_update( overlay, true );
	
	
	// Show
	
    $('body').css('overflow', 'hidden');
	
	$("#screen_overlay").addClass("active");
	$("#screen_overlay_content").addClass("active");
	
	
	// CSS
	
	$("#screen_overlay_content").css({
		"width": overlay.width,
		"height": overlay.height,
		"left": "calc( 50% - " + overlay.width / 2 + "px - " + $("#screen_overlay_content").css("padding-left") + " - " + $("#screen_overlay_content").css("padding-right") + " )",
		"top": "calc( 50% - " + overlay.height / 2 + "px - " + $("#screen_overlay_content").css("padding-top") + " - " + $("#screen_overlay_content").css("padding-bottom") + " )",
	});
	
	$("#screen_overlay_content .overlay_page[data-index]").css({
		"height": $("#screen_overlay_content").height() - 
			Math.ceil( $("#screen_overlay_content h4").outerHeight(true) ) -
			$("#screen_overlay_content .progress_container").outerHeight(true) -
			$(".overlay_button").outerHeight(true) - 
			$(".overlay_button").css("bottom").replace(/[^-\d\.]/g, '') + 
			"px"
	});
	
}

function overlay_create_skip ( input, index )
{
		
	overlay = input;
	
	// Dynamic DIVs
	if ( $("#spinner").length === 0 ) 
	{
		$("body").prepend("<p id='spinner' style='display: none;'>Please wait while we do what we do best.</p>");
	}
	
	if ( $("#screen_overlay").length === 0 ) 
	{
		$("body").prepend("<div id='screen_overlay'></div>");
	}

	if ( $("#screen_overlay_content").length === 0 ) 
	{
		$("#screen_overlay").prepend("<div id='screen_overlay_content'></div>");
	} 
	
	current_page_index = 0;
	
	$("#screen_overlay_content").html("");
	
		
	// Title
	
	if ( overlay.title )
	{
		$("#screen_overlay_content").append( "<h4>" + overlay.title + "</h4>" );
	}
	
	
	// Update
	
	overlay_set_index( overlay, index );
	
	
	// Show
	
    $('body').css('overflow', 'hidden');
	
	$("#screen_overlay").addClass("active");
	$("#screen_overlay_content").addClass("active");
	
	
	// CSS
	
	$("#screen_overlay_content").css({
		"width": overlay.width,
		"height": overlay.height,
		"left": "calc( 50% - " + overlay.width / 2 + "px - " + $("#screen_overlay_content").css("padding-left") + " - " + $("#screen_overlay_content").css("padding-right") + " )",
		"top": "calc( 50% - " + overlay.height / 2 + "px - " + $("#screen_overlay_content").css("padding-top") + " - " + $("#screen_overlay_content").css("padding-bottom") + " )",
	});
	
	$("#screen_overlay_content .overlay_page[data-index]").css({
		"height": $("#screen_overlay_content").height() - 
			Math.ceil( $("#screen_overlay_content h4").outerHeight(true) ) -
			$("#screen_overlay_content .progress_container").outerHeight(true) -
			$(".overlay_button").outerHeight(true) - 
			$(".overlay_button").css("bottom").replace(/[^-\d\.]/g, '') + 
			"px"
	});
	
}

function overlay_update ( overlay, forward ) 
{
			
	if ( forward )
	{
		current_page_index = current_page_index + 1;
	}
	else 
	{
		if ( current_page_index > 1 )
		{
			current_page_index = current_page_index - 1;
		}
	}
		
	// Progress
	
	if ( overlay.progress )
	{
		overlay_progress( overlay.pages, current_page_index );
	}
	
	
	// Navigation
	
	overlay_navigation( overlay.pages, current_page_index );
	
	
	// Pages
	
	overlay_pages( overlay.pages, current_page_index, forward );
	
}


function overlay_set_index ( overlay, index )
{
		
	for ( var i = 0; i < index; i++ )
	{
		overlay_update( overlay, true );
	}
	
}


function overlay_progress ( pages, index ) 
{
	
	if ( $("#screen_overlay_content .progress_container").length === 0 )
	{
		
		// Create
		$("#screen_overlay_content").append("<div class='progress_container'></div>");

		for ( var i = 1; i <= pages.length - 1; i++ ) {
			
			if ( i < index ) 
			{
				
				$("#screen_overlay_content")
					.find(".progress_container")
					.append("<div class='progress progress_complete' data-index='" + i + "'></div>");
					
			} 
			else if ( i == index ) 
			{
				
				$("#screen_overlay_content")
					.find(".progress_container")
					.append("<div class='progress progress_current' data-index='" + i + "'></div>");
					
			} 
			else 
			{
				
				$("#screen_overlay_content")
					.find(".progress_container")
					.append("<div class='progress progress_empty' data-index='" + i + "'></div>");
					
			}

		}
		
	}
	else
	{
		
		// Update
		
		$(".progress_container .progress").each( function () {
			
			if ( $(this).data("index") < index )
			{
				$(this).removeClass("progress_current progress_empty").addClass("progress_complete");
			}
			else if ( $(this).data("index") == index )
			{
				$(this).removeClass("progress_complete progress_empty").addClass("progress_current");
			}
			else
			{
				$(this).removeClass("progress_current progress_complete").addClass("progress_empty");
			}
			
		});
		
	}

}

function overlay_pages ( pages, index, forward )
{
		
	if ( $("#screen_overlay_content .overlay_page").length === 0 )
	{
		
		var count = 0;

		 $.each( pages, function () {
			if ( $(this)[0]['id'] > 0 )
			{
				count++;
			}
		});
		
		for ( var i = 1; i <= count; i++ ) 
		{
		
			$("#screen_overlay_content").append("<div class='overlay_page' data-index='" + i + "'></div>");
			$("#screen_overlay_content")
				.find(".overlay_page[data-index='" + i + "']")
				.css({
					"z-index": function() {
						return 100 - i
					}
				});
		}
	}
		
	if ( forward )
	{
		overlay_load_page( pages, index );
		
	} else {
		
		if ( 
			pages[index-1] !== undefined &&
			pages[index-1].hasOwnProperty("validation") 
		) {
			 window[ pages[index-1]["validation"] ]();
		} 
		else if (
			pages[index-1] == undefined
		) {
			index += 1;
		}
		
	}
	
	$(".overlay_page").each( function () {
		$(this).css({
			"left": ( $(this).data("index") - index ) * overlay.width
		});
	});
	
}

function overlay_load_page ( pages, index )
{
		
	var pageURL;
	var myData = "";
	var closeAuto = false;
	var closeDelay = 0;
	var pageRefresh = false;
	var noAJAX = false;
	var form = $("<form/>", { id: "noAJAXForm", method: "POST"});
	
	if ( request ) 
	{
		//request.abort();
	}
	
	$.each( pages, function () {
				
		if ( $(this)[0]['id'] == index )
		{
			pageURL = $(this)[0]['url'];
			form.attr('action', pageURL );
		}
		
		if ( $(this)[0]['id'] == index - 1 && $(this)[0].hasOwnProperty("toSend") )
		{
			
			$.each( $(this)[0]["toSend"], function ( index, value ) {
				
				if ( $(value).val() != undefined )
				{
					myData += value.substring(1) + "=" + $(value).val() + "&";
					form.append( 
					    $("<input/>", { 
							type:'hidden', 
							name: value.substring(1, value.length),
							value: $(value).val()
						})
					);
				}
				
			});
			
			if ( myData != undefined && myData.length > 0 )
			{
				myData = myData.slice(0,-1);
			}
			
		}
		
		if ( $(this)[0]['id'] == index - 1 && $(this)[0].hasOwnProperty("closeDelay") )
		{
			closeAuto = true;
			closeDelay = $(this)[0].closeDelay;
		}
		
		if ( $(this)[0]['id'] == index - 1 && $(this)[0].hasOwnProperty("noAJAX") )
		{
			noAJAX = true;
		}
		
		if ( $(this)[0]['id'] == index - 1 && $(this)[0].hasOwnProperty("pageRefresh") )
		{
			pageRefresh = $(this)[0].pageRefresh;
		}
		
	});
	
	//console.log( pages[index - 1].url + " : " + myData );
	
	if ( noAJAX )
	{
		
		$("body").append( form );
		$("#noAJAXForm").submit();
		
	}
	else
	{
	
		request = $.ajax({
			url: pageURL,
			type: "post",
			data: myData
		}).done( function( response, textStatus, jqXHR ) {
		
			$("#screen_overlay_content")
				.find(".overlay_page[data-index='" + index + "']")
				.html(response)
				.find("script")
				.each( function () {
					//eval( $(this).text() );
				});
		
		
			$("#screen_overlay_content")
				.find(".overlay_date")
				.each( function () {
			
					if ( $(this).val() == "" && $(this).attr("data-allowblank") == undefined )
					{
						$(this)
						.datepicker({
							showOn: 'button',
							setDate: 0,
							dateFormat: 'mm-dd-yy',
							prevText: '',
							nextText: '',
						})
						.datepicker('setDate', new Date());
					}
					else
					{
						$(this)
						.datepicker({
							showOn: 'button',
							dateFormat: 'mm-dd-yy',
							prevText: '',
							nextText: '',
						});
					}
			
				});
		
			$('#ui-datepicker-div').removeClass('ui-helper-hidden-accessible');
			$('#ui-datepicker-div').css('z-index', '11000');

			$("#screen_overlay_content")
				.find(".trigger")
				.click( function() {
			
					if ( $(this).attr("data-date") == undefined )
					{
						$("#screen_overlay_content")
							.find(".overlay_date")
							.datepicker( $('#ui-datepicker-div').is(':visible') ? 'hide' : 'show' );
					}
					else
					{
						$("#screen_overlay_content")
							.find(".overlay_date[data-date=" + $(this).attr("data-date") + "]")
							.datepicker($ ('#ui-datepicker-div').is(':visible') ? 'hide' : 'show' );
					}
			
			
					$('#ui-datepicker-div').css('z-index', '11000');
				});
		
			if ( closeAuto )
			{
		
				$("#screen_overlay").delay( closeDelay ).queue( function () {
			
					$(this).removeClass("active");
					$("#screen_overlay_content").removeClass("active");
			
					if ( pageRefresh )
					{
				
						generateURL();
				
					}
			
					$(this).dequeue();
			
				});
		
			}
			
		});
		
	}
	
}

function overlay_navigation ( pages, index ) 
{	
	
	var count = 0;
	var disableBack = false;
	
	 $.each( pages, function () {
		 
		if ( $(this)[0]['id'] > 0 )
		{
			count++;
		}
		
		if ( $(this)[0]['id'] == index && $(this)[0].hasOwnProperty("disableBack") )
		{
			disableBack = $(this)[0].disableBack;
		}
		
	});
	
	if ( $("#screen_overlay_content .overlay_button.back").length === 0 ) 
	{
		$("#screen_overlay_content").append("<div class='overlay_button back'><span></span></div>");
	}
	
	if ( $("#screen_overlay_content .overlay_button.forward").length === 0 ) 
	{
		$("#screen_overlay_content").append("<div class='overlay_button forward active valid'><span></span></div>");
	}
	
	
	if ( index == count - 1 ) 
	{
		$(".overlay_button.back").addClass("active");
		$(".overlay_button.forward").addClass("active").addClass("complete").removeClass("valid");
	}
	else if ( index == 1 ) 
	{
		$(".overlay_button.back").removeClass("active");
		$(".overlay_button.forward").addClass("active").addClass("valid");
	}
	else if ( index == count )
	{
		$(".overlay_button.back").removeClass("active");
		$(".overlay_button.forward").removeClass("active").removeClass("valid");
	}
	else
	{
		$(".overlay_button.back").addClass("active");
		$(".overlay_button.forward").addClass("active").removeClass("valid");
	}
	
	if ( index != count - 1 )
	{
		$(".overlay_button.forward").removeClass("complete");
	}
	
 	if ( disableBack )
	{
		$(".overlay_button.back").removeClass("active");
	}
	
}

function overlay_valid ( toggle )
{
	
	if ( toggle )
	{
		$(".overlay_button.forward").addClass("valid");
	}
	else
	{
		$(".overlay_button.forward").removeClass("valid");
	}
	
}

function overlay_show ( toggle, persist )
{
	
	if (typeof persist === "undefined" || persist === null) { 
		persist = false; 
	}
	
	if ( toggle )
	{
		
        $('body').css('overflow', 'hidden');

		$('#screen_overlay').addClass("active");
		$('#screen_overlay_content').addClass("active");
		
	}
	else
	{
		
		$('#screen_overlay').removeClass("active");
		$('#screen_overlay_content').removeClass("active");
		
        $('body').css('overflow', 'auto');
		
		if ( ! persist )
		{
			$('#screen_overlay_content .overlay_button').removeClass("active");
			$('#screen_overlay_content').children().remove();
		}

	}
	
}

function getUrlParameter ( sParam ) 
{
	
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	
	for ( var i = 0; i < sURLVariables.length; i++ ) 
	{
		
		var sParameterName = sURLVariables[i].split('=');
		
		if ( sParameterName[0] == sParam ) 
		{
			return sParameterName[1];
		}
		
	}
}