/**
 * Search v1.0
 */
(function($) {

	// Variables

	var request;


	// Dynamic DIVs

	if ($("#screen_overlay").length === 0) {
		$("body").prepend("<div id='screen_overlay'></div>");
	}


	// CSS

	$(document).ready(function() {
		$(".jssearch_result_container")
			.css({
				"display": "none",
				"position": "absolute",
				"left": function() {
					return $(".jssearch_search_input").offset().left;
				},
				"top": function() {
					return $(".jssearch_search_input").offset().top + $(".jssearch_search_input").outerHeight();
				},
				"min-width": function() {
					return $(".jssearch_search_input").outerWidth();
				},
				"background": "#ffffff",
				"padding": "0px 0px 5px 0px",
				"border": "1px solid #d5d5d5",
				"border-top": "none",
				"z-index": "9998"
			});
	});


	// Triggers

	$(document).on("keyup", ".jssearch_search_input", function() {

		if ($(this).val().length >= 1) {
			searchResult($(this));
		} else {
			$(this).add("#header_search_button")
				.css({
					"z-index": "1"
				});

			$(this).parent().children(".jssearch_result_container").hide();
			$("#screen_overlay").removeClass("active");
		}

	});

	$(document).on("click", ".jssearch_search_input", function() {

		if ($(this).val().length >= 1) {
			$(this).add("#header_search_button")
				.css({
					"z-index": "9998"
				});
			$(this).parent().children(".jssearch_result_container").show();

			$("#screen_overlay")
				.css({
					"background": "none"
				});
			$("#screen_overlay").addClass("active");
		}

	});

	$(document).on("click", "#screen_overlay", function() {

		$("#header_search").add("#header_search_button")
			.css({
				"z-index": "1"
			});
		$("#screen_overlay").removeClass("active");
		$(".jssearch_result_container").hide();

	});

	$(document).on("click touchstart", ".jssearch_type_material", function() {

		var url_split = document.URL.split("?");
		var get_string = "?nav=material&id=" + $(this).attr("data-id");
		
		request = $.ajax({
			url: "ajax/searchCount.php",
			type: "post",
			data: "searchType=1&id=" + $(this).attr("data-id"),
			global: false
		});

		window.location.href = url_split[0] + get_string;

	});
	
	$(document).on("click touchstart", ".jssearch_type_product", function() {

		var url_split = document.URL.split("?");
		var get_string = "?nav=product&id=" + $(this).attr("data-id");
		
		request = $.ajax({
			url: "ajax/searchCount.php",
			type: "post",
			data: "searchType=2&id=" + $(this).attr("data-id"),
			global: false
		});

		window.location.href = url_split[0] + get_string;

	});

	$(document).on("click touchstart", ".jssearch_type_customer", function() {

		var url_split = document.URL.split("?");
		var get_string = "?nav=customer&id=" + $(this).attr("data-id");
		
		request = $.ajax({
			url: "ajax/searchCount.php",
			type: "post",
			data: "searchType=3&id=" + $(this).attr("data-id"),
			global: false
		});

		window.location.href = url_split[0] + get_string;

	});


	// Functions

	function searchResult(target) {

		if (request) {
			request.abort();
		}

		var serializedData = $(target).serialize();
		$(".jssearch_result_container").html("");

		//$(".jssearch_search_input").prop( "disabled", true );

		request = $.ajax({
			url: "ajax/search.php",
			type: "post",
			data: serializedData,
			dataType: 'json',
			global: false
		}).done(
			function(response, textStatus, jqXHR) {

				$(target).add("#header_search_button")
					.css({
						"z-index": "9998"
					});
				$(target).parent().children(".jssearch_result_container").show();

				$("#screen_overlay")
					.css({
						"background": "none"
					});
				$("#screen_overlay").addClass("active");

				if (response != "") {

					$.each(response, function(index, row) {

						var id = "";
						var name = "";
						var type = "";
						var category = "";

						$.each(row, function(key, value) {

							switch (key) {

								case 'id':
									id = value;
									break;

								case 'name':
									name = value;
									break;

								case 'type':
									type = value;
									break;
									
								case 'category':
									category = value;
									break;

							}

						});

						var outstring = "<div class='jssearch_result_option ";

						if (type == "1") // Material
						{
							
							if (category == 1)
							{
								outstring += "jssearch_type_material";
							}
							else if (category == 2)
							{
								outstring += "jssearch_type_product";
							}
							
						} else if (type == "2") // Customer
						{
							outstring += "jssearch_type_customer";
						}

						outstring += "' data-type='" + type + "' data-id='" + id + "'><div class='icon'></div>" + name + "</div>";

						$(".jssearch_result_container").append(outstring);

					});

				} else {
					$(".jssearch_result_container").append("<div class='jssearch_result_option empty'>No Results Found.</div>");
				}

				$(".jssearch_type_customer").first().addClass("first");

			}
		).fail(
			function(jqXHR, textStatus, errorThrown) {
				if (errorThrown != "abort") {
					console.error("The following error occured: " + textStatus, errorThrown);
				}
			}
		).always(
			function() {
				//$(".jssearch_search_input").prop( "disabled", false );
			}
		);

	}

})(jQuery);