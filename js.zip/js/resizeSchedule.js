(function($) {

	$(document).ready(function() {

		var $window = $(window);
		var boxWidthExtra = (
			parseFloat($('.content').css("padding-left").replace("px", "")) +
			parseFloat($('.content').css("padding-right").replace("px", ""))
		) - (
			parseFloat($('.content').css("margin-left").replace("px", "")) +
			parseFloat($('.content').css("margin-right").replace("px", ""))
		);

		function resizeSchedule() {

			var scheduleWidth = ($window.width() - $("#menu").outerWidth() + boxWidthExtra);
			
			$('.scheduleColumn').width(Math.floor((scheduleWidth-7)/7))
			$('.schedule_trigger').width(Math.floor((scheduleWidth-7)/7) - 10)

			$(".content").css({
				"width": scheduleWidth,
				"max-width": scheduleWidth
			});

		}

		$(window).resize(function() {
			resizeSchedule();
		});

		resizeSchedule();

	});

})(jQuery);