(function($) {

	$(document).ready(function() {

		var $window = $(window);
		var boxWidthExtra = (
			parseFloat($('.content').css("padding-left").replace("px", "")) +
			parseFloat($('.content').css("padding-right").replace("px", ""))
		) - (
			parseFloat($('.content').css("margin-left").replace("px", "")) +
			parseFloat($('.content').css("margin-right").replace("px", ""))
		);

		function resizeTable() {

			if ($window.width() > 667) {
				var tableWidth = ($window.width() - $("#menu").outerWidth() + boxWidthExtra);
			} else {
				var tableWidth = $(".app_report_table").width();
			}

			$(".content").css({
				"width": tableWidth,
				"max-width": tableWidth
			});

			if ($window.width() <= 667) {

				$("#toolbar").css({
					"width": tableWidth,
					"max-width": tableWidth
				});
				$("#footer").css({
					"width": tableWidth,
					"max-width": tableWidth
				});

				var scaleX = $window.width() / $(".content").width();

				$("body").css("transformOrigin", "0 0");
				$("body").css("transform", "scale(" + scaleX + ")");
			}

		}

		$(window).resize(function() {
			resizeTable();
		});

		resizeTable();

	});

})(jQuery);