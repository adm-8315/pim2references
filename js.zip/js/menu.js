(function($) {
	
	/**
	 * Triggers
	 */
	
	$(document).on("click", "#menu .clickable", function() {
		generateURL($(this));
	});
	
	
	/**
	 * Menu
	 */

	$(document).ready(function() {

		var defaultMargin = parseInt($('#content, .content').css('margin-left'), 10);

		$(window).scroll(function() {

			if ($(window).width() > 667) {

				if ($(window).scrollTop() >= 137) {
					$("#menu").addClass("static");
					$("#content, .content").css("margin-left", $("#menu").outerWidth() + defaultMargin);
				} else {
					$("#menu").removeClass("static");
					$("#content, .content").css("margin-left", '');
				}

			}

		});

	});

})(jQuery);