
	/**
	 * URL Proccessor
	 */

	function generateURL(target) {

		target = typeof target !== 'undefined' ? target : null;
		
	    var regexParse = new RegExp('[a-z\-0-9]{2,63}\.[a-z\.]{2,5}$');
	    var urlParts = regexParse.exec(window.location.hostname);
	    var subdomain = window.location.hostname.replace(urlParts[0],'').slice(0, -1);

		var url_in_split = document.URL.split("?");
		var url_in_get = url_in_split[1].split("&");
		var url_out_string = "?";
		var url_out_array = new Object();

		url_out_array['nav'] = null;
		url_out_array['report'] = null;
		url_out_array['id'] = null;
		url_out_array['date_begin'] = null;
		url_out_array['date_end'] = null;
		url_out_array['location'] = null;
		url_out_array['owner'] = null;
		url_out_array['transactionType'] = null;

		url_in_get.forEach(function(token) {

			var temp = token.split("=");
			url_out_array[temp[0]] = temp[1];

		});
		
		if (target != null) {

			url_out_array['nav'] = target.attr("data-nav");
			url_out_array['report'] = target.attr("data-report");
			url_out_array['id'] = target.attr("data-id");
			url_out_array['date_begin'] = null;
			url_out_array['date_end'] = null;
			url_out_array['location'] = null;
			url_out_array['owner'] = null;

		} else {

			// Date Picker Begin
			if ($("#datepicker_begin").length != 0) {
				if ($("#datepicker_begin").datepicker("getDate") == null) {
					url_out_array['date_begin'] = $("#datepicker_begin").datepicker("option", "defaultDate");
				} else {
					var outDate = $("#datepicker_begin").datepicker("getDate");
					url_out_array['date_begin'] =
						((outDate.getMonth() + 1) < 10 ? "0" + (outDate.getMonth() + 1) : (outDate.getMonth() + 1)) +
						"/" +
						(outDate.getDate() < 10 ? "0" + outDate.getDate() : outDate.getDate()) +
						"/" +
						outDate.getFullYear();
				}
			}

			// Date Picker End
			if ($("#datepicker_end").length != 0) {
				if ($("#datepicker_end").datepicker("getDate") == null) {
					url_out_array['date_end'] = $("#datepicker_end").datepicker("option", "defaultDate");
				} else {
					var outDate = $("#datepicker_end").datepicker("getDate");
					url_out_array['date_end'] =
						((outDate.getMonth() + 1) < 10 ? "0" + (outDate.getMonth() + 1) : (outDate.getMonth() + 1)) +
						"/" +
						(outDate.getDate() < 10 ? "0" + outDate.getDate() : outDate.getDate()) +
						"/" +
						outDate.getFullYear();
				}
			}

			// Location	
			if (
				(
					subdomain == 'inventory'
				) && (
					url_out_array['nav'] == 'material' ||
					url_out_array['nav'] == 'product'
				)
			) {
				url_out_array['location'] = $(".inventory_tab.selected").data("id");
			}
			else
			{
				url_out_array['location'] = $("#toolbar_location").children(".toolbar_button_options").children(".selected").attr("data-id");
			}

			// Owner
			if ($("#toolbar_owner").length != 0) {
				url_out_array['owner'] = $("#toolbar_owner").children(".toolbar_button_options").children(".selected").attr("data-id");
			}
			
			//Transaction Type
			if ( 
				(
					subdomain == 'inventory'
				) && (
					url_out_array['nav'] == 'material' ||
					url_out_array['nav'] == 'product'
				)
			) {
				url_out_array['transactionType'] = $(".transaction_tab.selected").data("id");
			}

		}

		$.each(url_out_array, function(key, value) {

			if (value != null) {
				url_out_string += key + "=" + value + "&";
			}

		});

		url_out_string = url_out_string.substring(0, url_out_string.length - 1);
		window.location.href = url_in_split[0] + url_out_string;
		
		//console.log(url_in_split[0] + url_out_string);

	}