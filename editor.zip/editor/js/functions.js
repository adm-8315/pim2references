function openEditor(evt, component) {
    var i, tabcontent, tablinks;

    tablinks = document.getElementsByClassName("tablinks");
    
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    $.ajax({ url: "/editor/inc/functions.php?module=" + component }).done(function (html) {
        $("#editorContent").html(html);
    });
}

function resetFilter() {
    document.getElementById('editorSearchFilter').value = "";
    document.getElementById('showInactiveCheckbox').checked = 0;
    doFilter();
}

function doFilter() {
    filter = document.getElementById('editorSearchFilter').value.toString().toUpperCase();
    table = document.getElementById("editorDataTabe");
    tr = table.getElementsByTagName("tr");
    showinactive = document.getElementById('showInactiveCheckbox').checked;

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[2];
        active = tr[i].getElementsByTagName("td")[1];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (!showinactive) { if (active = "no") { tr[i].style.display = "none"; } }
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

function openCompany(id) {
    $.ajax({ url: "/editor/inc/company_view.php?id=" + id }).done(function (html) {
        document.body.innerHTML += '<div id=CompanyViewOverlay>' + html + '</div>';
    });
}

function openLocation(id) {
    $.ajax({ url: "/editor/inc/location_view.php?id=" + id }).done(function (html) {
        document.body.innerHTML += '<div id=LocationViewOverlay>' + html + '</div>';
    });
}

function doEditCompany(id) {
    $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) {
        $('#CompanyViewOverlay').html(html);
    });
}

function doEditLocation(id) {
    $.ajax({ url: "/editor/inc/location_edit.php?id=" + id }).done(function (html) {
        $('#LocationViewOverlay').html(html);
    });
}

function clearErrors() {
    $("#typeError").html("");
    $("#propertyError").html("");
    $("#locationError").html("");
    $("#personError").html("");
    $("#deleteError").html("");
}

function toggleCompanyActive(id, toggleto) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "setstatus",
        companyid : id,
        status : toggleto,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else { $("#statusError").html("error toggling company status<br>"); }
    });
}

function addCompanyType(id) {
    clearErrors()
    if (document.getElementById("companyAddTypeSelect").value == -1) { return; }
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "addtype",
        companyid : id,
        typeid : document.getElementById("companyAddTypeSelect").value,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#typeError").html("error adding company type<br>"); }
    });
}

function removeCompanyType(id, typeid) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "removetype",
        companyid : id,
        typeid : typeid,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#typeError").html("error removing company type<br>"); }
    });
}

function addCompanyProperty(id) {
    clearErrors()
    if (document.getElementById("companyAddPropertySelect").value == -1) { return; }
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "addproperty",
        companyid : id,
        propertyid : document.getElementById("companyAddPropertySelect").value,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#propertyError").html("error removing company property<br>"); }
    });
}

function removeCompanyProperty(id, propertyid) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "removeproperty",
        companyid : id,
        propertyid : propertyid,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#propertyError").html("error removing company property<br>"); }
    });
}

function removeCompanyLocation(id, locid) {
    clearErrors()
    if (locid == -1) { return; }
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "removelocation",
        companyid : id,
        locationid : locid,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#locationError").html("error removing company location, there are likely associated resources<br>"); }
    });
}

function addCompanyLocation(id) {
    clearErrors()
    if (document.getElementById("companyAddLocationSelect").value == -1) { return; }
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "addlocation",
        companyid : id,
        locationid : document.getElementById("companyAddLocationSelect").value,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#locationError").html("error adding company location<br>"); }
    });
}

function updateCompanyWebsite(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "company",
        action : "updatewebsite",
        companyid : id,
        website : document.getElementById("companyWebsite").value.trim(),
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/company_edit.php?id=" + id }).done(function (html) { $('#CompanyViewOverlay').html(html); });
        } else {  $("#locationError").html("error adding company website<br>"); }
    }); 
}

function deleteCompany(id) {
    clearErrors()

    $.ajax({ url: "/editor/inc/actions.php?target=company&action=delete&companyid=" + id }).done(function (actionresult) {
        if (actionresult == "true") { $('#CompanyViewOverlay').remove();
        } else { $("#deleteError").html("Unable to delete company, there are likely associated resources"); }
    });
}

function openPerson(id) {
    $.ajax({ url: "/editor/inc/person_view.php?id=" + id }).done(function (html) {
        document.body.innerHTML += '<div id=PersonViewOverlay>' + html + '</div>';
    });
}

function doEditPerson(id) {
    $.ajax({ url: "/editor/inc/person_edit.php?id=" + id }).done(function (html) {
        $('#PersonViewOverlay').html(html);
    });
}

function editAddress () {
    document.getElementById("addressView").style.visibility = "hidden";
    document.getElementById("addressView").style.height = "0";
    document.getElementById("addressEdit").style.height = "";
    document.getElementById("addressEdit").style.display = "inline";
    document.getElementById("addressEdit").style.visibility = "visible";
}

function cancelAddressEdit() {
    document.getElementById("addressEdit").removeAttribute('style');
    document.getElementById("addressView").removeAttribute('style');

    document.getElementById("addrLineOne").value =  document.getElementById("defaultLineOne").innerHTML;
    document.getElementById("addrLineTwo").value =  document.getElementById("defaultLineTwo").innerHTML;
    document.getElementById("addrLineThree").value =  document.getElementById("defaultLineThree").innerHTML;
    document.getElementById("addrCity").value =  document.getElementById("defaultCity").innerHTML;
    document.getElementById("addrState").value =  document.getElementById("defaultState").innerHTML;
    document.getElementById("addrZip").value =  document.getElementById("defaultZip").innerHTML;
}

function saveRegion(id) {
    clearErrors()    
    $.post("/editor/inc/actions.php", {
        target : "location",
        action : "saveregion",
        targetid : id,
        region : document.getElementById("locationRegion").value,
    },
    function(data) {
        if (data == "true") { 
            $('#LocationViewOverlay').remove();
            openEditor(event, 'locations');
            doEditLocation(id);
        } else { $("#addressError").html("error updating region"); }   
    });
}

function saveAddress(id, target) {
    clearErrors()
    loadURL = "";
    overlayDIV = "";
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "location") { loadURL = "location_edit"; overlayDIV = "#LocationViewOverlay"; }
    
    $.post("/editor/inc/actions.php", {
        target : target,
        action : "updateaddress",
        targetid : id,
        lineOne : document.getElementById("addrLineOne").value,
        lineTwo : document.getElementById("addrLineTwo").value,
        lineThree : document.getElementById("addrLineThree").value,
        city : document.getElementById("addrCity").value,
        state : document.getElementById("addrState").value,
        zip : document.getElementById("addrZip").value,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + id }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#addressError").html("error updating address"); }   
    });
}

function removeAddress(id, target) {
    clearErrors()
    loadURL = "";
    overlayDIV = "";
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "location") { loadURL = "location_edit"; overlayDIV = "#LocationViewOverlay"; }
    
    $.post("/editor/inc/actions.php", {
        target : target,
        action : "removeaddress",
        targetid : id,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + id }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#addressError").html("error updating address"); }   
    });
}

function removeEMail(mailid, id, target) {
    clearErrors()
    loadURL = "";
    overlayDIV = "";
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "location") { loadURL = "location_edit"; overlayDIV = "#LocationViewOverlay"; }
    
    $.post("/editor/inc/actions.php", {
        target : target,
        action : "removeemail",
        targetid : id,
        mailid: mailid
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + id }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#addressError").html("error updating address"); }   
    });
}

function addEMail(target,id){
    clearErrors()
    email = document.getElementById("newEmail").value;

    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!re.test(String(email).toLowerCase())) { $("#emailerror").html("Error adding email address - improper format"); return; }

    loadURL = "";
    overlayDIV = "";
    
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "company") { loadURL = "company_edit"; overlayDIV = "#CompanyViewOverlay"; }

    $.post("/editor/inc/actions.php", {
        target : target,
        action : "addmail",
        targetid : id,
        newmail: email,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + id }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#emailerror").html("Error adding email address"); }   
    });
}

function toggleMailFav(target, targetid, mailid, fav) {
    clearErrors()
    loadURL = "";
    overlayDIV = "";
    
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "company") { loadURL = "company_edit"; overlayDIV = "#CompanyViewOverlay"; }

    $.post("/editor/inc/actions.php", {
        target : target,
        action : "togglemailfav",
        targetid : targetid,
        mailid: mailid,
        fav: fav,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + targetid }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#emailerror").html("Error toggling mail favorite"); }   
    });

}

function addPhone(target, targetid) {
    clearErrors()
    loadURL = "";
    overlayDIV = "";

    type = document.getElementById("phoneType").value;
    phone = document.getElementById("newPhone").value;
    ext = document.getElementById("newExt").value;

    if (phone === "") { $("#phoneError").html("Error adding phone - no phone number entered"); }
    
    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "company") { loadURL = "company_edit"; overlayDIV = "#CompanyViewOverlay"; }

    $.post("/editor/inc/actions.php", {
        target : target,
        action : "addphone",
        targetid : targetid,
        newphonetype: type,
        newphone: phone,
        newphoneex: ext,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + targetid }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#phoneError").html("Error adding phone"); }   
    });
}

function removePhone(target, targetid, phoneid) {
    clearErrors();
    loadURL = "";
    overlayDIV = "";

    if (target == "person") { loadURL = "person_edit"; overlayDIV = "#PersonViewOverlay"; }
    if (target == "company") { loadURL = "company_edit"; overlayDIV = "#CompanyViewOverlay"; }

    $.post("/editor/inc/actions.php", {
        target : target,
        action : "removephone",
        targetid : targetid,
        phoneid: phoneid,
    },
    function(data) {
        if (data == "true") { 
            $.ajax({ url: "/editor/inc/" + loadURL + ".php?id=" + targetid }).done(function (html) { $(overlayDIV).html(html); });
        } else { $("#phoneError").html("Error deleting phone"); }   
    });
}

function toggleLocationActive(id, toggleto) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "location",
        action : "setstatus",
        locationid : id,
        status : toggleto,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/location_edit.php?id=" + id }).done(function (html) { $('#LocationViewOverlay').html(html); });
        } else { $("#statusError").html("error toggling location status<br>"); }
    });
}
 
function toggleLocationStockable(id, toggleto) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "location",
        action : "setstockable",
        locationid : id,
        stockable : toggleto,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/location_edit.php?id=" + id }).done(function (html) { $('#LocationViewOverlay').html(html); });
        } else { $("#stockableError").html("error toggling location stockability<br>"); }
    });
}

function addLocationRequirement(id) {
    clearErrors()
    if (document.getElementById("addLocationRequirementSelect").value == -1) { return; }
    $.post("/editor/inc/actions.php", {
        target : "location",
        action : "addreq",
        locationid : id,
        reqid : document.getElementById("addLocationRequirementSelect").value,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/location_edit.php?id=" + id }).done(function (html) { $('#LocationViewOverlay').html(html); });
        } else {  $("#requirementError").html("error adding location requirements<br>"); }
    });
}

function removeLocationRequirement(id, reqid) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "location",
        action : "removereq",
        locationid : id,
        reqid : reqid,
    },
    function(data) {
        if (data == "true") {
            $.ajax({ url: "/editor/inc/location_edit.php?id=" + id }).done(function (html) { $('#LocationViewOverlay').html(html); });
        } else {  $("#requirementError").html("error removing location requirements<br>"); }
    });
}

function addNewMeasurement() {
    clearErrors()
    if (document.getElementById("newMeasurementP").value === "" || document.getElementById("newMeasurementS").value === "") { return }

    $.post("/editor/inc/actions.php", {
        target : "measurement",
        action : "add",
        measurementS : document.getElementById("newMeasurementS").value,
        measurementP : document.getElementById("newMeasurementP").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "measurements");
        } else {  $("#requirementError").html("error adding new measurement<br>"); }
    });
}

function removeMeasurement(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "measurement",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "measurements");
        } else {  $("#measurementError").html("error removing measurement<br>"); }
    });
}

function addNewCompanyProperty() {
    if (document.getElementById("newPropertyName").value === "" ) { return }

    $.post("/editor/inc/actions.php", {
        target : "companyProperty",
        action : "add",
        propertyName : document.getElementById("newPropertyName").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "companyProperties");
        } else {  $("#companyPropertyError").html("error adding new company property<br>"); }
    });
}

function removeCompanyPropertyOption(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "companyProperty",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "companyProperties");
           doEditLocation(id);
        } else {  $("#companyPropertyError").html("error removing company property<br>"); }
    });
}

function removeEquipmentTypeOption(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "equipmentType",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "equipmentTypes");
        } else {  $("#equipmentTypeeError").html("error removing equipment type<br>"); }
    });
}  


function addNewEquipmentType() {
    if (document.getElementById("newEquipmentTypeName").value === "" ) { return }

    $.post("/editor/inc/actions.php", {
        target : "equipmentType",
        action : "add",
        propertyName : document.getElementById("newEquipmentTypeName").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "equipmentTypes");
        } else {  $("#equipmentTypeError").html("error adding new equipment type<br>"); }
    });
}

function removeMaterialTypeOption(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "materialType",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "materialTypes");
        } else {  $("#materialtTypeError").html("error removing material type<br>"); }
    });
}  


function addNewMaterialType() {
    if (document.getElementById("newMaterialTypeName").value === "" ) { return }

    $.post("/editor/inc/actions.php", {
        target : "materialType",
        action : "add",
        propertyName : document.getElementById("newMaterialTypeName").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "materialTypes");
        } else {  $("#materialtTypeError").html("error adding new material type<br>"); }
    });
}

function removeProductTypeOption(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "ProductType",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "productTypes");
        } else {  $("#productTypeError").html("error removing Product type<br>"); }
    });
}  

function addNewProductType() {
    if (document.getElementById("newProductTypeName").value === "" ) { return }

    $.post("/editor/inc/actions.php", {
        target : "ProductType",
        action : "add",
        propertyName : document.getElementById("newProductTypeName").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "productTypes");
        } else {  $("#productTypeError").html("error adding new Product type<br>"); }
    });
}

function removeCompanyTypeOption(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "CompanyType",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "companyTypes");
        } else {  $("#companyTypeError").html("error removing Company type<br>"); }
    });
}  

function addNewCompanyType() {
    if (document.getElementById("newCompanyTypeName").value === "" ) { return }

    $.post("/editor/inc/actions.php", {
        target : "CompanyType",
        action : "add",
        propertyName : document.getElementById("newCompanyTypeName").value,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, "companyTypes");
        } else {  $("#companyTypeError").html("error adding new Company type<br>"); }
    });
}

function getEditorPermissions() {
    $.post("/editor/inc/actions.php", {
        target : "permissions",
        action : "get",
        id : document.getElementById("editorPermissionsUserSelect").value,
    },
    function(data) {
        if (data === "") { data = "00000000000"; }
            perms = data.split('');
            document.getElementById("editorAccess").checked = ~~perms[0]
            document.getElementById("editorAdmin").checked = ~~perms[1]
            document.getElementById("editorDataCompanyPerm").value = perms[2]
            document.getElementById("editorDataLocationPerm").value = perms[3]
            document.getElementById("editorDataPeoplePerm").value = perms[4]
            document.getElementById("editorPropertiesMeasurementsPerm").value = perms[5]
            document.getElementById("editorPropertiesCompanyPerm").value = perms[6]
            document.getElementById("editorTypesEquipmentPerm").value = perms[7]
            document.getElementById("editorTypesMaterialPerm").value = perms[8]
            document.getElementById("editorTypesProductPerm").value = perms[9]
            document.getElementById("editorTypesCompanyPerm").value = perms[10]
    });
}

function setEditorPermissions() {
    perms = Number(document.getElementById("editorAccess").checked).toString() + 
            Number(document.getElementById("editorAdmin").checked).toString() +
            document.getElementById("editorDataCompanyPerm").value.toString() +
            document.getElementById("editorDataLocationPerm").value.toString() +
            document.getElementById("editorDataPeoplePerm").value.toString() +
            document.getElementById("editorPropertiesMeasurementsPerm").value.toString() +
            document.getElementById("editorPropertiesCompanyPerm").value.toString() +
            document.getElementById("editorTypesEquipmentPerm").value.toString() +
            document.getElementById("editorTypesMaterialPerm").value.toString() +
            document.getElementById("editorTypesProductPerm").value.toString() +
            document.getElementById("editorTypesCompanyPerm").value.toString();

            console.log(perms);

    $.post("/editor/inc/actions.php", {
        target : "permissions",
        action : "set",
        id : document.getElementById("editorPermissionsUserSelect").value,
        permission : perms,
    },
    function(data) {
        if (data == "true") {
            openEditor(event, "locations");

         } else { }// $("#companyTypeError").html("error adding new Company type<br>"); }
     });
}

function removeProduct(id) {
    clearErrors()
    $.post("/editor/inc/actions.php", {
        target : "products",
        action : "remove",
        id : id,
    },
    function(data) {
        if (data == "true") {
           openEditor(event, 'products')
        } else {  $("#productError").html("error removing product<br>"); }
    });
}  