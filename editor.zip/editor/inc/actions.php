<?php

require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
require_once(dirname(__FILE__) . "/../../inc/session.php");
require_once("db.php");

$target = "";
$action = "";
$id = "";
$status = "";
$typeid = "";
$propertyid = "";
$locationid = "";
$personid = "";
$companyName = "";
$website = "";

# Address Info
$lineOne = "";
$lineTwo = "";
$lineThree = "";
$city = "";
$state = "";
$zip = "";

# EMail Info
$mailid = "";
$newmail = "";
$fav = 0;

# Phones
$newphone = "";
$newphoneex = "";
$newphonetype = 0;
$phoneid = "";

if (isset($_POST["target"])) { $target = $_POST[ "target"]; } else { die( "false"); }
if (isset($_POST["action"])) { $action = $_POST[ "action"]; } else { die("false"); }
switch ($target) {
    case "company": 
        switch ($action) {
            case "setstatus":
                if (isset($_POST["status"])) { $status = $_POST[ "status"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (setstatus("company", $id, $status)) {die("true"); } else { die("false"); } break;
            case "addtype":  
                if (isset($_POST["typeid"])) { $typeid = $_POST[ "typeid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (addCompanyType($id, $typeid)) { die("true"); } else { die("false"); } break;
            case "removetype":
                if (isset($_POST["typeid"])) { $typeid = $_POST[ "typeid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (removeCompanyType($id, $typeid)) { die("true"); } else { die("false"); } break;
            case "addproperty":
                if (isset($_POST["propertyid"])) { $propertyid = $_POST[ "propertyid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (addCompanyProperty($id, $propertyid)) { die("true"); } else { die("false"); } break;
            case "removeproperty":  
                if (isset($_POST["propertyid"])) { $propertyid = $_POST[ "propertyid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (removeCompanyProperty($id, $propertyid)) { die("true"); } else { die("false"); } break;
            case "addlocation":  
                if (isset($_POST["locationid"])) { $locationid = $_POST[ "locationid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (addCompanyLocation($id, $locationid)) { die("true"); } else { die("false"); } break;
            case "removelocation":  
                if (isset($_POST["locationid"])) { $locationid = $_POST[ "locationid"]; } else { die("false"); }
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (removeCompanyLocation($id, $locationid)) { die("true"); } else { die("false"); } break;
            case "delete":
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (deleteCompany($id)) { die("true"); } else { die("false"); } break; 
            case "updatewebsite":
                if (isset($_POST["companyid"])) { $id = $_POST[ "companyid"]; } else { die("false"); }
                if (isset($_POST["website"])) { $website = $_POST[ "website"]; } else { die("false"); }
                if (updateCompanyWebsite($id, $website)) { die("true"); } else { die("false"); } break; 
        }
    case "person" :
        switch ($action) {
            case "updateaddress" :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["lineOne"])) { $lineone = $_POST[ "lineOne"]; } else { die("false"); }
                if (isset($_POST["lineTwo"])) { $linetwo = $_POST[ "lineTwo"]; } else { die("false"); }
                if (isset($_POST["lineThree"])) { $linethree = $_POST[ "lineThree"]; } else { die("false"); }
                if (isset($_POST["city"])) { $city = $_POST[ "city"]; } else { die("false"); }
                if (isset($_POST["state"])) { $state = $_POST[ "state"]; } else { die("false"); }
                if (isset($_POST["zip"])) { $zip = $_POST[ "zip"]; } else { die("false"); }
                if (updateAddress($target, $id, $lineone, $linetwo, $linethree, $city, $state, $zip)) { die("true"); } else { die("false"); } break; 
            case 'removeaddress' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (removeAddress($id, $target)) { die("true"); } else { die("false"); } break;
            case 'removeemail' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["mailid"])) { $mailid = $_POST[ "mailid"]; } else { die("false"); }
                if (removeEmailAddress($mailid, $id, $target)) { die("true"); } else { die("false"); } break;
            case 'addmail' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["newmail"])) { $newmail = $_POST[ "newmail"]; } else { die("false"); }
                if (addEMailAddress($newmail, $id, $target)) { die("true"); } else { die("false"); } break;
            case 'togglemailfav' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["mailid"])) { $mailid = $_POST[ "mailid"]; } else { die("false"); }
                if (isset($_POST["fav"])) { if($_POST[ "fav"] == "fav_yes") { $fav = 1; } } else { die("false"); }
                if (toggleMailFav($target, $id, $mailid, $fav)) { die("true"); } else { die("false"); } break;
            case 'addphone' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["newphone"])) { $newphone = $_POST[ "newphone"]; } else { die("false"); }
                if (isset($_POST["newphoneex"])) { $newphoneex = $_POST[ "newphoneex"]; } else { die("false"); }
                if (isset($_POST["newphonetype"])) { $newphonetype = $_POST[ "newphonetype"]; } else { die("false"); }
                if (addPhone($target, $id, $newphone, $newphoneex, $newphonetype)) { die("true"); } else { die("false"); } break;
            case 'removephone' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["phoneid"])) { $phoneid = $_POST[ "phoneid"]; } else { die("false"); }
                if (removePhone($target, $id, $phoneid)) { die("true"); } else { die("false"); } break;
        }
    case "location" :
        switch ($action) {
            case "updateaddress" :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (isset($_POST["lineOne"])) { $lineone = $_POST[ "lineOne"]; } else { die("false"); }
                if (isset($_POST["lineTwo"])) { $linetwo = $_POST[ "lineTwo"]; } else { die("false"); }
                if (isset($_POST["lineThree"])) { $linethree = $_POST[ "lineThree"]; } else { die("false"); }
                if (isset($_POST["city"])) { $city = $_POST[ "city"]; } else { die("false"); }
                if (isset($_POST["state"])) { $state = $_POST[ "state"]; } else { die("false"); }
                if (isset($_POST["zip"])) { $zip = $_POST[ "zip"]; } else { die("false"); }
                if (updateAddress($target, $id, $lineone, $linetwo, $linethree, $city, $state, $zip)) { die("true"); } else { die("false"); } break; 
            case 'saveregion' :
                    if (isset($_POST["targetid"])) { $id = $_POST["targetid"]; } else { die("false"); }
                    if (isset($_POST["region"])) { $region = $_POST["region"]; } else { die("false"); }
                    if (saveRegion($id, $region)) { die("true"); } else { die("false"); } break;      
            case 'removeaddress' :
                if (isset($_POST["targetid"])) { $id = $_POST[ "targetid"]; } else { die("false"); }
                if (removeAddress($id, $target)) { die("true"); } else { die("false"); } break;            
            case "setstatus":
                if (isset($_POST["status"])) { $status = $_POST["status"]; } else { die("false"); }
                if (isset($_POST["locationid"])) { $id = $_POST["locationid"]; } else { die("false"); }
                if (setstatus("location", $id, $status)) {die("true"); } else { die("false"); } break;
            case "setstockable":
                if (isset($_POST["stockable"])) { $status = $_POST["stockable"]; } else { die("false"); }
                if (isset($_POST["locationid"])) { $id = $_POST["locationid"]; } else { die("false"); }
                if (setstockable($target, $id, $status)) {die("true"); } else { die("false"); } break;
            case "addreq":
                if (isset($_POST["reqid"])) { $reqid = $_POST["reqid"]; } else { die("false"); }
                if (isset($_POST["locationid"])) { $id = $_POST["locationid"]; } else { die("false"); }  
                if (addreq($id, $reqid)) {die("true"); } else { die("false"); } break;     
            case "removereq":
                if (isset($_POST["reqid"])) { $reqid = $_POST["reqid"]; } else { die("false"); }
                if (isset($_POST["locationid"])) { $id = $_POST["locationid"]; } else { die("false"); }   
                if (removereq($id, $reqid)) {die("true"); } else { die("false"); } break;    
        }
    case "measurement" :
        switch ($action) {
            case "add" :
                if (isset($_POST["measurementP"])) { $mp = $_POST["measurementP"]; } else { die("false"); }
                if (isset($_POST["measurementS"])) { $ms = $_POST["measurementS"]; } else { die("false"); }  
                if (addMeasurement($ms, $mp)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeMeasurement($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "companyProperty" :
        switch ($action) {
            case "add" :
                if (isset($_POST["propertyName"])) { $propName = $_POST["propertyName"]; } else { die("false"); }
                if (addNewCompanyProperty($propName)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeCompanyPropertyOption($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "equipmentType" :
        switch ($action) {
            case "add" :
                if (isset($_POST["propertyName"])) { $propName = $_POST["propertyName"]; } else { die("false"); }
                if (addNewEquipmentType($propName)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeEquipmentTypeOption($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "materialType" :
        switch ($action) {
            case "add" :
                if (isset($_POST["propertyName"])) { $propName = $_POST["propertyName"]; } else { die("false"); }
                if (addNewMaterialType($propName)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeMaterialTypeOption($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "ProductType" :
        switch ($action) {
            case "add" :
                if (isset($_POST["propertyName"])) { $propName = $_POST["propertyName"]; } else { die("false"); }
                if (addNewProductType($propName)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeProductTypeOption($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "CompanyType" :
        switch ($action) {
            case "add" :
                if (isset($_POST["propertyName"])) { $propName = $_POST["propertyName"]; } else { die("false"); }
                if (addNewCompanyType($propName)) {die("true"); } else { die("false"); } break;     
                break;
            case "remove" :    
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeCompanyTypeOption($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
        case "products" :
        switch ($action) {
            case "remove" :
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (removeProduct($id)) {die("true"); } else { die("false"); } break;     
                break;
        }
    case "permissions" :
        switch ($action) {
            case "get" :
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                $perms = getEditorPermissions($id);
                if ($perms != "false") { echo $perms; } else { die("false"); }
                break;
            case "set" :
                error_log($_POST["id"]);
                error_log($_POST["permission"]);
                if (isset($_POST["id"])) { $id = $_POST["id"]; } else { die("false"); }
                if (isset($_POST["permission"])) { $perms = $_POST["permission"]; } else { die("false"); }
                if (setEditorPermissions($id, $perms)) {die("true"); } else { die("false"); } 
                break;  
        }
}
?>