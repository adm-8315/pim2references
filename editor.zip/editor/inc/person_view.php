<?php
    require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
    require_once(dirname(__FILE__) . "/../../inc/session.php");
    require_once("db.php");

    $id = $_GET["id"];

    $tmpl = file_get_contents("../tmpl/person_view.html");
    $data = getPerson($id);

    $html = str_replace("%%name%%", $data["name"], $tmpl);
    $html = str_replace("%%id%%", $id, $html);

    $chtml = "";
    $ctmpl = "<tr><td>%%companyName%%</td><td>%%active%%</td></tr>";

    foreach ($data["companies"] as $c) {
        $tc = str_replace("%%companyName%%", $c["company"], $ctmpl);
        if ($c["active"]) { $tc = str_replace("%%active%%", "yes", $tc); } else { $tc = str_replace("%%active%%", "no", $tc); }
        $chtml .= $tc;
    }
    $html = str_replace("%%companies%%", $chtml, $html);

    $lhtml = "";
    foreach ($data["locations"] as $l) { $lhtml .= "<tr><td>" . $l["name"] . "</td><td>" . $l["active"] . "</td><td>" . $l["stockable"] . "</td><td>" . $l["address"] . "</td><td>" . $l["region"] . "</td></tr>"; }
    $html = str_replace("%%locations%%", $lhtml, $html);

    $html = str_replace("%%address%%", getAddressString($data["address"]), $html);

    $ehtml = "";
    foreach ($data["emails"] as $em) {
        $tem = "";
        if ($em["primary"] == "1")
            { $tem .= "<img src='editor/img/fav_yes.png'>&nbsp;&nbsp;"; }
            else  { $tem .= "<img src='editor/img/email.png'>&nbsp;&nbsp;"; }
        $tem .= $em["email"];
        $ehtml .= $tem;
    }
    
    $html = str_replace("%%emails%%", $ehtml, $html);

    $phtml = "";

    foreach ($data["phones"]["work"] as $wp) { $phtml .= " <img src=editor/img/phone-w.png> " . $wp['number']; if (!empty($wp['ext'])) { $phtml .= "ex. " . $wp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["cell"] as $cp) { $phtml .= " <img src=editor/img/phone-c.png> " . $cp['number']; if (!empty($cp['ext'])) { $phtml .= "ex. " . $cp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["home"] as $hp) { $phtml .= " <img src=editor/img/phone-h.png> " . $hp['number']; if (!empty($hp['ext'])) { $phtml .= "ex. " . $hp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["fax"] as $fp) { $phtml .= " <img src=editor/img/phone-f.png> " . $fp['number']; if (!empty($fp['ext'])) { $phtml .= "ex. " . $fp['ext']; } $phtml .= "<br>"; }

    $html = str_replace("%%phones%%", $phtml, $html);

    echo $html;
?>