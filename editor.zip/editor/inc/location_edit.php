<?php
    require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
    require_once(dirname(__FILE__) . "/../../inc/session.php");
    require_once("db.php");

    $id = $_GET["id"];

    $tmpl = file_get_contents("../tmpl/location_edit.html");
    $data = getLocation($id);

    $html = str_replace("%%name%%", $data["location"], $tmpl);
    $html = str_replace("%%id%%", $id, $html);

    if ( $data["active"]) { $html = str_replace("%%active%%", "yes", $html);}
    else { $html = str_replace("%%active%%", "no", $html); }

    if ( $data["active"]) { 
        $html = str_replace("%%active%%", "yes", $html); 
        $html = str_replace("%%LocationActiveOpposite%%", 0, $html); 
        $html = str_replace( "%%LocationActiveOppositeButton%%", "Deactivate", $html);}
    else { 
        $html = str_replace("%%active%%", "no", $html); 
        $html = str_replace("%%LocationActiveOpposite%%", 1, $html); 
        $html = str_replace("%%LocationActiveOppositeButton%%", "Activate", $html);
    }

    if ( $data["stockable"]) { 
        $html = str_replace("%%stockable%%", "yes", $html); 
        $html = str_replace("%%LocationStockableOpposite%%", 0, $html); 
        $html = str_replace( "%%LocationStockableOppositeButton%%", "Not Stockable", $html);}
    else { 
        $html = str_replace("%%stockable%%", "no", $html); 
        $html = str_replace("%%LocationStockableOpposite%%", 1, $html); 
        $html = str_replace("%%LocationStockableOppositeButton%%", "Stockable", $html);
    }

    $addr = getAddress($data["address"]);
    
    if (!empty($addr)) {
        $html = str_replace("%%addressString%%", getAddressString($addr), $html);

        $html = str_replace("%%addrLine1%%", $addr["lineOne"], $html);
        $html = str_replace("%%addrLine2%%", $addr["lineTwo"], $html);
        $html = str_replace("%%addrLine3%%", $addr["lineThree"], $html);
        $html = str_replace("%%addrCity%%", getCity($addr["city"]), $html);
        $html = str_replace("%%addrState%%", getState($addr["state"]), $html);
        $html = str_replace("%%addrZip%%", $addr["zip"], $html);
        $html = str_replace("%%stateID%%", $addr["state"], $html);
    } else {
        $html = str_replace("%%addressString%%", "", $html);
        $html = str_replace("%%addrLine1%%", "", $html);
        $html = str_replace("%%addrLine2%%", "", $html);
        $html = str_replace("%%addrLine3%%", "", $html);
        $html = str_replace("%%addrCity%%", "", $html);
        $html = str_replace("%%addrState%%", "", $html);
        $html = str_replace("%%addrZip%%", "", $html);
        $html = str_replace("%%stateID%%", "", $html);
    }

    $statesData = getStates();
    $statesHTML = "";
    foreach ($statesData as $st) {
        $selected = "";
        if (!empty($addr["state"])) { if ($st['stateID'] == $addr["state"]) { $selected = " selected "; } }
        $statesHTML .= "<option value=" . $st["stateID"] . $selected . ">" . $st['state'] . "</option>";
    }
    $html = str_replace("%%states%%", $statesHTML, $html);

    if (empty($data['region'])) { $html = str_replace("%%region%%", "", $html); }
        else { $html = str_replace("%%region%%", getRegion($data['region']), $html); }

    $requirements = getLocationRequirements($id);
    $reqHTML = "";
    foreach ($requirements as $r) {
        $reqHTML .= "<tr><td><div class='removeLocationRequirement' onClick='removeLocationRequirement($id, " . $r["id"] . ");'><a href='#'>🗑️</a></div>" . $r['requirement'] . "</td><td>" . $r['reqType'] . "</td</tr>";
    }
    $html = str_replace("%%requirements%%", $reqHTML, $html);

    $unusedRequirements = getLocationUnusedRequirements($id);
    $ureqHTML = "";
    foreach ($unusedRequirements as $r) {
        $ureqHTML .= "<option value=" . $r['id'] . ">" . $r['requirement'] . " - " . $r['reqType'] . "</option>";
    }
    $html = str_replace("%%RequirementsSelection%%", $ureqHTML, $html);

    echo $html;
?>