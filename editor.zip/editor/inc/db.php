<?php
require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");

function getAddress($id) {
    if ($id == null) {return "";}
    $addrString = "";
    $addr = dbquery_row("SELECT * FROM `address` WHERE addressID=$id;");

    return $addr;
}

function getState($id) {
    $stateQuery = "SELECT `state` FROM `state` WHERE stateID=$id;";
    $state = dbquery_row($stateQuery);

    return $state['state'];
}

function getRegion($id) {
    $regionQuery = "SELECT `region` FROM `region` WHERE regionID=$id;";
    $region = dbquery_row($regionQuery);

    return $region['region'];
}

function getStateID($stateName) {
    $stateQuery = "SELECT `stateID` FROM `state` WHERE state='$stateName';";
    $state = dbquery_row($stateQuery);
    return $state['stateID'];
}

function getCity($id) {
    $cityQuery = "SELECT `city` FROM city WHERE cityID=$id;";
    $city = dbquery_row($cityQuery);

    return $city['city'];
}

function getCityID($city) {
    $cityQuery = "SELECT `cityID` FROM city WHERE city='$city';";
    $city = dbquery_row($cityQuery);

    return $city['cityID'];
}

function addCity($cityName) {
    $cityInsert = "INSERT INTO city (city) VALUES ('$cityName');";
    return dbquery($cityInsert);
}

function getAllLocations() {
    $query = "SELECT * FROM location;";
    
    return dbquery($query);
}

function getAllCompanies() {
    $query = "SELECT companyID, company, active FROM company;";
    
    return dbquery($query);
}
function getCompany($id) {
    $companyQuery = "SELECT * FROM `company` WHERE companyId=$id;"; 
    $popertyQuery = "SELECT * FROM `companyProperty` WHERE companyPropertyID IN (SELECT companyProperty FROM companyCompanyPropertyLink WHERE company=$id) ORDER BY companyProperty;";
    $typeQuery = "SELECT * FROM `companyType` WHERE companyTypeID IN (SELECT companyType FROM companyCompanyTypeLink WHERE company=$id) ORDER BY companyType;";
    $websiteQuery = "SELECT website FROM website WHERE company=$id LIMIT 1;";
    $locationQuery = "SELECT * FROM `location` WHERE locationID IN (SELECT location FROM companyLocationLink WHERE company=$id) ORDER BY location;";
    $personQuery = "SELECT DISTINCT * FROM `person` WHERE personID IN (SELECT person FROM companyLocationLinkPersonLink WHERE companyLocationLink IN (SELECT companyLocationLinkID FROM companyLocationLink WHERE company=2));";

    $cData = dbquery($companyQuery);
    $pData = dbquery($popertyQuery);
    $tData = dbquery($typeQuery);
    $wData = dbquery($websiteQuery);
    if (isset($wData[0]['website'])) {$wData = $wData[0]['website'];} else { $wData = ""; }
    $lData = dbquery($locationQuery);
    $pplData = dbquery($personQuery);

    $result = array (
        "company" => array(),
        "properties" => array(),
        "types" => array(),
        "locations" => array(),
        "people" => array()
    );

    foreach ($cData as $row) {
        $tc = array (
            "id" => $row["companyID"],
            "name" => $row["company"],
            "active" => $row["active"],
            "defaultperson" => $row["defaultPerson"],
            "website" => $wData,
        );
        array_push($result["company"], $tc);
    }

    foreach ( $tData as $row) { 
        $td = array(
            "id" => $row["companyTypeID"],
            "companytype" => $row["companyType"]
        );
        
        array_push($result["types"], $td);
    }

    foreach ($pData as $row) {
        $pd = array(
            "id" => $row["companyPropertyID"],
            "companyproperty" => $row["companyProperty"]
        );
        array_push($result["properties"], $pd);
    }
    
    foreach ( $lData as $row) {        
        $region = "";
        if($row["region"] !== null) {
            $regionQuery = "SELECT 'region' FROM `region` WHERE regionID=". $row["region"].";";
            $region = dbquery_row( $regionQuery);
        }

        $tl = array (
            "id" => $row["locationID"],
            "name" => $row["location"],
            "active" => $row["active"],
            "stockable" => $row["stockable"],
            "region" => $region,
            "address" => getAddress($row["address"])
        );
        array_push($result["locations"], $tl);
    }

    foreach ($pplData as $row) {
        $thisPerson = getPerson($row["personID"]);
        array_push($result["people"],$thisPerson);          
    }
    return $result;
}

function updateCompanyWebsite($id, $website) {
    try { 
        $websiteUpdateQuery = "";
        if ($website == "") { $websiteUpdateQuery = "DELETE FROM website WHERE company=$id;"; }
        else { 
            $websiteCountQuery = "SELECT COUNT(*) AS count FROM website WHERE company = $id;";
            if (dbquery_row($websiteCountQuery)["count"] == 0 ) { $websiteUpdateQuery = "INSERT INTO website (company, website) VALUES ($id, '" . $website . "');"; }
            else { $websiteUpdateQuery = "UPDATE website SET website = '" . $website . "' WHERE company = $id;"; }
        }
        dbquery($websiteUpdateQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;

}

function getLocation($id) {
    $locationQuery = "SELECT * FROM `location` WHERE locationID =$id;";
    return dbquery_row($locationQuery);
}

function getRemainingTypes($id) {
    $query = "Select * from companyType where companyTypeID NOT IN (SELECT companyType FROM `companyCompanyTypeLink` WHERE company=$id) ORDER BY companyType;";
    return dbquery($query);
}

function getRemainingProperties($id) {
    $query = "Select * from companyProperty where companyPropertyID NOT IN(SELECT companyProperty FROM `companyCompanyPropertyLink` WHERE company=$id) ORDER BY companyProperty;";
    return dbquery($query);
}

function getRemainingLocations($id) {
    $query = "Select * from location where locationID NOT IN(SELECT location FROM `companyLocationLink` WHERE company=$id) ORDER BY location;";
    return dbquery($query);
}

function getRemainingPeople($id) {
    $query = "Select * from person where personID NOT IN(SELECT person FROM `personCompanyLink` WHERE company=$id) ORDER BY firstName;";
    return dbquery($query);
}

function setstatus($target, $id, $status) {
    $query = "UPDATE $target set active=$status where $target" . "ID=$id;";
    try { dbquery( $query); } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function setstockable($target, $id, $status) {
    $query = "UPDATE $target set stockable=$status where $target" . "ID=$id;";
    error_log($query);
    try { dbquery( $query); } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function addCompanyType($id, $typeid) {
    $query = "SELECT * FROM companyCompanyTypeLink WHERE company=$id and companyType=$typeid;";
    $result = dbquery($query);

    if(count($result) != 0) {return true;}
    try {
        $insert = "INSERT INTO companyCompanyTypeLink (company, companyType) VALUES ($id, $typeid);";
        dbquery($insert);

        $result = dbquery($query);
        if (count($result) == 0) { return false; }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function removeCompanyType($id, $typeid) {
    try {
        $query = "DELETE FROM companyCompanyTypeLink WHERE company=$id and companyType=$typeid;";
        dbquery( $query);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    
    try {
        $query = "SELECT * FROM companyCompanyTypeLink WHERE company=$id and companyType=$typeid;";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    return true;
}

function addCompanyProperty($id, $propertyid) {
    $query = "SELECT * FROM companyCompanyPropertyLink WHERE company=$id and companyProperty= $propertyid;";
    $result = dbquery($query);
    if(count($result) != 0) {return true;}
    try {
        $insert = "INSERT INTO companyCompanyPropertyLink (company, companyProperty) VALUES ($id,  $propertyid);";
        dbquery($insert);

        $result = dbquery($query);
        if (count($result) == 0) { return false; }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true; 
}

function removeCompanyProperty($id, $propertyid) {
    try {
        $query = "DELETE FROM companyCompanyPropertyLink WHERE (company=$id and companyProperty=$propertyid);";
        dbquery($query);
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }
    
    try {
        $query = "SELECT * FROM companyCompanyPropertyLink WHERE (company=$id and companyProperty=$propertyid);";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    return true;
}

function removeCompanyLocation($id, $locationid) {
    try {
        $query = "SELECT * FROM productTransaction WHERE companyLocationLink IN (SELECT companyLocationLinkID FROM companyLocationLink WHERE company=$id and location=$locationid);";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }

        $query = "DELETE FROM companyLocationLink WHERE (company=$id and location=$locationid);";
        dbquery($query);
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    try {
        $query = "SELECT * FROM companyLocationLink WHERE (company=$id and location=$locationid);";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    return true;
}

function addCompanyLocation($id, $locationid) {
    $query = "SELECT companyLocationLinkID FROM companyLocationLink WHERE company=$id and location=$locationid;";
    $result = dbquery($query);
    if(count($result) != 0) {return true;}
    try {
        $insert = "INSERT INTO companyLocationLink (company, location) VALUES ($id,  $locationid);";
        dbquery($insert);

        $result = dbquery($query);
        if (count($result) == 0) { return false; }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true; 
}

function deleteCompany($id) {
    try {
        $query = "SELECT * FROM companyLocationLink WHERE company=$id;";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }

        $query = "SELECT * FROM companyEmailLink WHERE company=$id;";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }

        $query = "DELETE FROM companyCompanyPropertyLink WHERE company=$id; DELETE FROM companyCompanyTypeLink WHERE company=$id;";
        dbquery($query);

        $query = "DELETE FROM company WHERE companyID=$id; ";
        dbquery($query);
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    try {
        $query = "SELECT * FROM company WHERE companyID=$id;";
        $result = dbquery($query);
        if (count($result) > 0) { return false; }
    } catch(Exception $e) {error_log("exception: "); error_log($e->getMessage()); return false; }

    return true;
}

function getAllPeople() {
    $query = "SELECT personID FROM person ORDER BY personID;";
    return dbquery($query);
}

function getPerson($id) {
    
    $pquery = "SELECT * FROM person where personID=$id;";
    $prow = dbquery_row($pquery);

    # Base number types --> 1 Work -- 2 Cell -- 3 Home -- 4 Fax
    $mailQuery = "SELECT * FROM personEmailLink where person=" . $id . ";";
    $mData = dbquery($mailQuery);
    $mails = array();
    $locations = array();
    $phones = array(
        "work" => array(),
        "cell" => array(),
        "home" => array(),
        "fax" => array()
    );

    $phoneQuery = "SELECT * FROM number WHERE numberID IN (SELECT number FROM personNumberLink where person=$id);";
    $numbers = dbquery($phoneQuery);
    foreach ($numbers as $nrow) {
        switch ($nrow["numberType"]) {
            case 1: array_push($phones["work"], $nrow); break;
            case 2: array_push($phones["cell"], $nrow); break;
            case 3: array_push($phones["home"], $nrow); break;
            case 4: array_push($phones["fax"], $nrow); break;
        };
    };

    foreach ($mData as $mrow) {
        $emailQuery = "SELECT * FROM `email` WHERE emailID=" . $mrow["email"] . ";";
        $tem = dbquery_row($emailQuery);
        array_push($mails, array("id"=>$tem["emailID"], "email"=> $tem["user"] . "@" . $tem["domain"] . $tem["tld"], "primary" => $mrow["primary"]));
    }

    $locationsQuery = "SELECT * from location WHERE locationID IN (SELECT location FROM companyLocationLink where companyLocationLinkID IN (SELECT companyLocationLink FROM companyLocationLinkPersonLink WHERE person=$id));";
    $lData = dbquery($locationsQuery);
    foreach ($lData as $row) {        
        $region = "";
        if($row["region"] !== null) {
            $regionQuery = "SELECT 'region' FROM `region` WHERE regionID=". $row["region"].";";
            $region = dbquery_row( $regionQuery);
        }

        $tl = array (
            "id" => $row["locationID"],
            "name" => $row["location"],
            "active" => $row["active"],
            "stockable" => $row["stockable"],
            "region" => $region,
            "address" => getAddress($row["address"])
        );
        array_push($locations, $tl);
    }

    $companiesQuery = "SELECT * from company WHERE companyID IN (SELECT company FROM companyLocationLink where companyLocationLinkID IN (SELECT companyLocationLink FROM companyLocationLinkPersonLink WHERE person=$id));";
    $cData = dbquery($companiesQuery);
    $companies = array();

    foreach ($cData as $row) { array_push($companies, $row); }

    $person = array(
        "id"=>$id,
        "name"=>$prow["firstName"] . " " . $prow["lastName"],
        "locations"=>$locations,
        "companies"=>$companies,
        "address"=>getAddress($prow["address"]),
        "emails"=>$mails,
        "phones"=> $phones
    );

    return $person;
}

function getAllMeasurements() {
    $query = "SELECT * FROM measure;";
    $data = dbquery($query);

    return $data;
}

function getAllequipmentTypes() {
    $query = "SELECT * FROM equipmentType;";
    $data = dbquery($query);

    return $data;
}

function getAllCompanyProps() {
    $query = "SELECT * FROM companyProperty;";
    $data = dbquery($query);

    return $data;
}

function getAllMaterialTypes() {
    $query = "SELECT * FROM materialType;";
    $data = dbquery($query);

    return $data;
}

function getAllProductTypes() {
    $query = "SELECT * FROM productType;";
    $data = dbquery($query);

    return $data;
}

function getAllCompanyTypes() {
    $query = "SELECT * FROM companyType;";
    $data = dbquery($query);

    return $data;
}

function getInUseMeasurements($id) {
    $mquery = "SELECT count(*) AS used FROM material WHERE measure=$id;";
    $mresult = dbquery_row($mquery);

    $pquery = "SELECT count(*) AS used FROM product WHERE measure=$id;";
    $presult = dbquery_row($pquery);

    if (($mresult["used"] + $presult["used"]) > 0) { return "Yes"; }
    return "No";
}

function getInUseCompanyProps($id) {
    $query = "SELECT count(*) AS used FROM companyCompanyPropertyLink WHERE companyProperty=$id;";
    $result = dbquery_row($query);

    if ($result["used"] > 0) { return "Yes"; }
    return "No";
}

function getInUseEquipmentType($id) {
    $query = "SELECT count(*) AS used FROM equipment WHERE equipmentType=$id;";
    $result = dbquery_row($query);

    if ($result["used"] > 0) { return "Yes"; }
    return "No";
}

function getInUseMaterialType($id) {
    $query = "SELECT count(*) AS used FROM material WHERE materialType=$id;";
    $result = dbquery_row($query);

    if ($result["used"] > 0) { return "Yes"; }
    return "No";
}

function getInUseProductType($id) {
    $query = "SELECT count(*) AS used FROM product WHERE productType=$id;";
    $result = dbquery_row($query);

    if ($result["used"] > 0) { return "Yes"; }
    return "No";
}

function getInUseCompanyType($id) {
    $query = "SELECT count(*) AS used FROM companyCompanyTypeLink WHERE companyType=$id;";
    $result = dbquery_row($query);

    if ($result["used"] > 0) { return "Yes"; }
    return "No";
}

function updateAddress($target, $id, $lineone, $linetwo, $linethree, $city, $state, $zip) {
    $query = "select * from address where addressID=(select address from $target where $target" . "ID=$id);";
    $addr = dbquery_row($query);
    $cityID = getCityID($city);
    $addressID = $addr['addressID'];
    
    $noCity = false;
    $noAddr = false;
    if (empty($addr)) {$noAddr = true;}
    if (empty($cityID)) {$noCity = true;}

    if ($noCity) { $cityID = addCity($city); }

    $addrUpdateQuery = "";
    if ($noAddr) { 
        $addrUpdateQuery = "INSERT INTO address (lineOne, lineTwo, lineThree, city, state, zip) VALUES ('$lineone', '$linetwo', '$linethree', $cityID, $state, '$zip');"; 
        $result = dbquery($addrUpdateQuery);
        if (empty($result)) { return false;} else {
            try {
                $LinkAddrQuery = "UPDATE $target SET address = $result WHERE $target" . "ID=$id;";
                dbquery($LinkAddrQuery);
            } catch(Exception $e) { error_log($e->getMessage()); return false; }
            return true;
        }
    } else { 
        try {
            $addrUpdateQuery = "UPDATE address SET lineOne = '$lineone', lineTwo = '$linetwo', lineThree = '$linethree', city = $cityID, state = $state, zip = '$zip' WHERE addressID = $addressID"; 
            dbquery($addrUpdateQuery);
        } catch(Exception $e) { error_log($e->getMessage()); return false; }
        return true;
    }
}

function getAddressString($addrData) {
    if(empty($addrData)) {return "";}
    $addrString = "";

    if (strlen($addrData["lineOne"]) != 0) { $addrString .= $addrData["lineOne"] . "<br>"; }
    if (strlen($addrData["lineTwo"]) != 0) { $addrString .= $addrData["lineTwo"] . "<br>"; }
    if (strlen($addrData["lineThree"]) != 0) { $addrString .= $addrData["lineThree"] . "<br>"; }
    $addrString .= getCity($addrData['city']) . ", ";
    $addrString .=  getState($addrData["state"]) . " ";
    if (strlen($addrData["zip"]) != 0) { $addrString .= $addrData["zip"]; }

    return $addrString;
}

function getStates() {
    $query = "SELECT * from `state`;";
    return dbquery($query);

}

function saveRegion($id, $region) {
    $existsQuery = "select LOWER(region) AS reg, regionID from region WHERE LOWER(region)='" . strtolower($region) . "';";
    error_log($existsQuery);
    $regionResult = dbquery_row($existsQuery);
    if ($region !== "") {
        if (count($regionResult) > 0) {
            try {
                $setLocationRegion = "UPDATE location SET region = " . $regionResult['regionID'] . " WHERE locationID=$id;";
                $result = dbquery($setLocationRegion);
            } catch(Exception $e) { error_log($e->getMessage()); return false; }
        } else { 
            try {
                $addRegion = "INSERT INTO region (region) VALUES ('$region');";
                $result = dbquery($addRegion);
                $setLocationRegion = "UPDATE location SET region = " . $result . " WHERE locationID=$id;";
                $result = dbquery($setLocationRegion);    
            } catch(Exception $e) { error_log($e->getMessage()); return false; }
        }
    } else {
        try {
            $setLocationRegion = "UPDATE location SET region = NULL WHERE locationID=$id;";
            dbquery($setLocationRegion);
        } catch(Exception $e) { error_log($e->getMessage()); return false; }
    }
    return true;
}

function removeAddress($id, $target) {
    try {
        $targetQuery = "SELECT address FROM $target WHERE $target" . "ID = $id;";
        $addrID = dbquery_row($targetQuery)['address'];

        $removeAddressQuery = "UPDATE $target SET address = NULL WHERE $target" . "ID = $id;";
        dbquery($removeAddressQuery);

        $personAddrCountQuery = "SELECT COUNT(address) as addrCount FROM person WHERE address=$addrID;";
        $locationAddrCountQuery = "SELECT COUNT(address) as addrCount FROM location WHERE address=$addrID;";

        $personAddrCount = dbquery_row($personAddrCountQuery);
        $locationAddrCount = dbquery_row($locationAddrCountQuery);

        if ($personAddrCount['addrCount'] == 0 && $locationAddrCount['addrCount'] == 0) {
            $deleteAddrQuery = "DELETE FROM address WHERE addressID=$addrID";
            dbquery($deleteAddrQuery);
        }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function removeEMailAddress($mailid, $targetid, $target) {
    try {
        $removeQuery = "DELETE FROM $target". "EmailLink WHERE $target = $targetid AND email = $mailid;";
        dbquery($removeQuery);

        $personMailCountQuery = "SELECT COUNT(email) as addrCount FROM personEmailLink where email=$mailid;";
        $companyMailCountQuery = "SELECT COUNT(email) as addrCount FROM companyEmailLink where email=$mailid;";

        $personMailCount = dbquery_row($personMailCountQuery);
        $companyMailCount = dbquery_row($companyMailCountQuery);

        if ($personMailCount['addrCount'] == 0 && $companyMailCount['addrCount'] == 0) {
            $deleteAddrQuery = "DELETE FROM email WHERE emailID=$mailid";
            dbquery($deleteAddrQuery);
        }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function addEMailAddress($newMail, $targetid, $target) {
    try {
        $user = explode("@",$newMail)[0];
        $domain = explode(".", explode("@",$newMail)[1], 2)[0];
        $tld = explode(".", explode("@",$newMail)[1], 2)[1];

        $addMailQuery = "INSERT INTO email (user,domain,tld) VALUES ('$user', '$domain', '$tld');";
        $result = dbquery($addMailQuery);

        $linkQuery = "INSERT INTO $target". "EmailLink ($target, email) VALUES ($targetid, $result);";
        dbquery($linkQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return TRUE;
}

function togglemailfav($target, $targetid, $mailid, $fav) {
    
    try {
        $unsetFavQuery = "UPDATE $target" . "EmailLink SET `primary` = 0 WHERE $target = $targetid;";
        dbquery($unsetFavQuery);

        if ($fav == 0) {
            $setFavQuery = "UPDATE $target" . "EmailLink SET `primary` = 1 WHERE $target = $targetid AND email = $mailid;";
            dbquery($setFavQuery);
        }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function addPhone($target, $targetid, $phone, $ext, $phonetype) {
    try {
        if (empty($ext)) { $ext = "null"; }
        $addPhoneQuery = "INSERT INTO number (numberType, number, ext) VALUES ($phonetype, $phone, $ext);";
        $result = dbquery($addPhoneQuery);

        $linkPhoneQuery = "INSERT INTO $target" . "NumberLink ($target, number) VALUES ($targetid, $result);";
        dbquery($linkPhoneQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function getPhoneTypes() {
    $phoneTypeQuery = "SELECT * from numberType;";
    $result = dbquery($phoneTypeQuery);
    return $result;
}

function removePhone($target, $targetid, $phoneid) {
    try {
        $removeQuery = "DELETE FROM $target". "NumberLink WHERE $target = $targetid AND number = $phoneid;";
        dbquery($removeQuery);
        error_log( $removeQuery );
        $personPhoneCountQuery = "SELECT COUNT(number) as phoneCount FROM personNumberLink where number=$phoneid;";
        $companyPhoneCountQuery = "SELECT COUNT(defaultNumber_phone) as phoneCount FROM company where defaultNumberPhone=$phoneid;";
        $companyFaxCountQuery = "SELECT COUNT(defaultNumber_fax) as phoneCount FROM company where defaultNumberFax=$phoneid;";

        $personPhoneCount = dbquery_row($personPhoneCountQuery);
        $companyPhoneCount = dbquery_row($companyPhoneCountQuery);
        $companyFaxCount = dbquery_row($companyFaxCountQuery);

        if ($personPhoneCount['phoneCount'] == 0 && $companyPhoneCount['phoneCount'] == 0 && $companyFaxCount['phoneCount'] == 0) {
            $deletePhoneQuery = "DELETE FROM number WHERE numberID=$phoneid";
            dbquery($deletePhoneQuery);
        }
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}

function getRequirements($id) {
    $reqQuery = "SELECT * FROM ";

    $reqArray = array();



    return $reqArray;
}

function getRequirementType($id) {
    $reqTypeQuery = "SELECT requirementType from requirementType WHERE requirementTypeID=$id;";
    $reqType = dbquery_row($reqTypeQuery);
    return $reqType['requirementType'];
}

function getLocationRequirements($id) {
    $reqQuery = "SELECT * FROM requirement WHERE requirementID IN (SELECT requirement FROM locationRequirementLink where location = $id)";
    $result = dbquery($reqQuery);

    $reqArray = array();
    foreach ($result as $req) {
        array_push($reqArray, array(
            "id" => $req['requirementID'],
            "requirement" => $req['requirement'],
            "reqType" => getRequirementType($req['requirementType'])
        ));
    }

    return $reqArray;
}

function getLocationUnusedRequirements($id) {
    $reqQuery = "SELECT * FROM requirement WHERE requirementID NOT IN (SELECT requirement FROM locationRequirementLink where location = $id)";
    $result = dbquery($reqQuery);

    $reqArray = array();
    foreach ($result as $req) {
        array_push($reqArray, array(
            "id" => $req['requirementID'],
            "requirement" => $req['requirement'],
            "reqType" => getRequirementType($req['requirementType'])
        ));
    }
    return $reqArray;
}

function getRemainingRequirements($id) {
    $reqQuery = "SELECT * FROM requirement WHERE requirementID NOT IN (SELECT requirement FROM locationRequirementLink where location = $id)";
    $result = dbquery($reqQuery);

    $reqArray = array();
    foreach ($result as $req) {
        array_push($reqArray, array(
            "id" => $req['requirementID'],
            "requirement" => $req['requirement'],
            "reqType" => getRequirementType($req['requirementType'])
        ));
    }

    return $reqArray;
}

function addreq($locationid, $reqid) {
    try {
        $reqCheckQuery = "SELECT * FROM locationRequirementLink WHERE location=$locationid AND requirement=$reqid;";
        if (count(dbquery($reqCheckQuery)) > 0) { return true; }

        $reqAddQuery = "INSERT INTO locationRequirementLink (location, requirement) VALUES ($locationid, $reqid);";
        $result = dbquery($reqAddQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removereq($locationid, $reqid) {
    try {
        $removeReqQuery = "DELETE FROM locationRequirementLink WHERE location=$locationid AND requirement=$reqid;";
        $result = dbquery($removeReqQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function addMeasurement($singular, $plaural) {
    $existsQuery = "select LOWER(measurePlural), LOWER(measureSingular) from measure WHERE LOWER(measurePlural)='" . strtolower($plaural) . "' and LOWER(measureSingular)='" . strtolower($singular) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO measure (measurePlural, measureSingular) VALUES ('$plaural', '$singular');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeMeasurement($id) {
    if (getInUseMeasurements($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM measure WHERE measureID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function addNewCompanyProperty($name) {
    $existsQuery = "select LOWER(companyProperty) from companyProperty WHERE LOWER(companyProperty)='" . strtolower($name) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO companyProperty (companyProperty) VALUES ('$name');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeCompanyPropertyOption($id) {
    if (getInUseCompanyProps($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM companyProperty WHERE companyPropertyID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function addNewEquipmentType($name) {
    $existsQuery = "select LOWER(equipmentType) from equipmentType WHERE LOWER(equipmentType)='" . strtolower($name) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO equipmentType (equipmentType) VALUES ('$name');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeEquipmentTypeOption($id) {
    if (getInUseEquipmentType($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM equipmentType WHERE equipmentTypeID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function addNewMaterialType($name) {
    $existsQuery = "select LOWER(materialType) from materialType WHERE LOWER(materialType)='" . strtolower($name) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO materialType (materialType) VALUES ('$name');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeMaterialTypeOption($id) {
    if (getInUseMaterialType($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM materialType WHERE materialTypeID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function addNewProductType($name) {
    $existsQuery = "select LOWER(productType) from productType WHERE LOWER(productType)='" . strtolower($name) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO productType (productType) VALUES ('$name');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeProductTypeOption($id) {
    if (getInUseProductType($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM productType WHERE productTypeID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function addNewCompanyType($name) {
    $existsQuery = "select LOWER(companyType) from companyType WHERE LOWER(companyType)='" . strtolower($name) . "';";
    if (count(dbquery($existsQuery)) > 0) { return true; }
    try {
        $addQuery = "INSERT INTO companyType (companyType) VALUES ('$name');";
        $result = dbquery($addQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    
    return true;
}

function removeCompanyTypeOption($id) {
    if (getInUseCompanyType($id) == "Yes") { return "false"; }
    try {
        $removeQuery = "DELETE FROM companyType WHERE companyTypeID=$id;";
        $result = dbquery($removeQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function getUsers() {
    $findQuery = "select userID, username from user";
    return dbquery($findQuery);
}

function getEditorPermissions($id) {
    $getPermsQuery = "SELECT perm FROM editorUserPermissions WHERE user = $id;";
    $result = dbquery_row($getPermsQuery);
    if (count($result) !== null) {error_log( $result['perm']); return $result['perm']; } else { return $false; }
}

function setEditorPermissions($id, $perms) {
    $removeQuery = "DELETE FROM editorUserPermissions WHERE user=$id;";
    $insertQuery = "INSERT INTO editorUserPermissions (user, perm) VALUES ($id, '$perms');";

    try {
        dbquery($removeQuery);
        dbquery($insertQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }

    return true;
}

function getAllProducts() {
    $productQuery = "SELECT p.productID, p.product, p.cost, pt.productType, m.measurePlural, m.measureSingular,  p.active
                    FROM product p
                    LEFT JOIN productType pt ON p.productType = pt.productTypeID
                    LEFT JOIN measure m ON p.measure = m.measureID
                    ORDER BY p.product;";

    return dbquery($productQuery);
}

function getInUseProducts($id) {
    $usedQuery = "SELECT SUM(a + b + c + d + e + f) as total, s as stock
        FROM (SELECT count(*) AS a FROM formProductLink WHERE product=$id) a
        CROSS JOIN (SELECT count(*) AS b FROM productConsumerLink WHERE product=$id) b
        CROSS JOIN (SELECT count(*) AS c FROM productInventory WHERE product=$id) c
        CROSS JOIN (SELECT count(*) AS d FROM productionOrder WHERE product=$id) d
        CROSS JOIN (SELECT count(*) AS e FROM productionOrderTemplate WHERE product=$id) e
        CROSS JOIN (SELECT count(*) AS f FROM productTransaction WHERE productInventory IN (SELECT productInventoryID FROM productInventory where product=$id)) f
        CROSS JOIN (SELECT SUM(stock) as s FROM productInventory WHERE product=$id) s";
    $usedResult = dbquery_row($usedQuery);

    if ($usedResult["total"] == 0) { return "No"; }
    elseif ($usedResult["total"] == 1 ) { if ($usedResult["stock"] == 0) { return "No"; } }
    else { return "Yes"; }
}

function removeProduct($id) {
    if (getInUseProducts($id) == "Yes") { return "false"; }

    $deleteProductInventoryQuery="DELETE FROM productInventory WHERE product=$id;";
    $deleteProductQuery="DELETE FROM product WHERE productID=$id;";

    try {
        dbquery($deleteProductInventoryQuery);
        dbquery($deleteProductQuery);
    } catch(Exception $e) { error_log($e->getMessage()); return false; }
    return true;
}
?>