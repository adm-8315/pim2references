<?php
    require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
    require_once(dirname(__FILE__) . "/../../inc/session.php");
    require_once("db.php");

    $id = $_GET["id"];

    $tmpl = file_get_contents("../tmpl/company_edit.html");
    $data = getCompany($id);

    $html = str_replace("%%name%%", $data["company"][0]["name"], $tmpl);
    $html = str_replace("%%id%%", $id, $html);

    if ( $data["company"][0]["active"]) { $html = str_replace("%%active%%", "yes", $html); $html = str_replace("%%CompanyActiveOpposite%%", 0, $html); $html = str_replace( "%%CompanyActiveOppositeButton%%", "Deactivate", $html);}
    else { $html = str_replace("%%active%%", "no", $html); $html = str_replace("%%CompanyActiveOpposite%%", 1, $html); $html = str_replace( "%%CompanyActiveOppositeButton%%", "Activate", $html);}
    $html = str_replace("%%CompanyActiveOpposite%%", 0, $html);

    $thtml = "";
    if (count($data["types"]) == 0) {$thtml .= "<li>none</li>"; }
        else { foreach ($data["types"] as $t) { $thtml .= "<li>" . $t["companytype"] . " | <a href='#' class='typePropertyDelete' onClick='removeCompanyType($id, " .  $t['id'] . ");'>🗑️</a></li>"; } }
        $html = str_replace("%%types%%", $thtml, $html);

    $phtml = "";
    if (count($data["properties"]) == 0) {$phtml .= "<li>none</li>"; }
        else { foreach ($data["properties"] as $p) { $phtml .= "<li>" . $p["companyproperty"] . " | <a href='#' class='typePropertyDelete' onClick='removeCompanyProperty($id, " .  $p['id'] . ");'>🗑️</a></li>";} }
    $html = str_replace("%%properties%%", $phtml, $html);

    $html = str_replace("%%website%%", $data["company"][0]["website"], $html);
    
    $lhtml = "";
    foreach ($data["locations"] as $l) { 
        $lhtml .= "<tr><td><div class='removeLocation' onClick='removeCompanyLocation($id, " . $l["id"] . ");'><a href='#'>🗑️</a></div>" . $l["name"] . "</td><td>" . $l["active"] . "</td><td>" . $l["stockable"] . "</td><td>" . $l["address"] . "</td><td>" . $l["region"] . "</td></tr>"; }
    $html = str_replace("%%locations%%", $lhtml, $html);

    $phtml = "";
    foreach ($data["people"] as $p) { 
        $phtml .= "<tr><td><div class='removePerson' onClick='removeCompanyPerson($id, " . $p["id"] . ");'><a href='#'>🗑️</a></div>" . $p["name"] . "</td><td>" . getAddressString($p["address"]) . "</td><td>";
        if (isset($p["email"])) { foreach ($p["email"] as $em) { $phtml .= $em . "<br>"; }; $phtml .= "</td><td>"; }
        foreach ($p["phones"]["work"] as $wp) { $phtml .= " <img src=editor/img/phone-w.png> " . $wp['number']; if (!empty($wp['ext'])) { $phtml .= "ex. " . $wp['ext']; } $phtml .= "<br>"; }
        foreach ($p["phones"]["cell"] as $cp) { $phtml .= " <img src=editor/img/phone-c.png> " . $cp['number']; if (!empty($cp['ext'])) { $phtml .= "ex. " . $cp['ext']; } $phtml .= "<br>"; }
        foreach ($p["phones"]["home"] as $hp) { $phtml .= " <img src=editor/img/phone-h.png> " . $hp['number']; if (!empty($hp['ext'])) { $phtml .= "ex. " . $hp['ext']; } $phtml .= "<br>"; }
        foreach ($p["phones"]["fax"] as $fp) { $phtml .= " <img src=editor/img/phone-f.png> " . $fp['number']; if (!empty($fp['ext'])) { $phtml .= "ex. " . $fp['ext']; } $phtml .= "<br>"; }

        $phtml .= "</td></tr>"; 
    }
    $html = str_replace("%%people%%", $phtml, $html);    

    $remainingTypes = getRemainingTypes($id);
    $remainingProperties = getRemainingProperties($id);
    $remainingLocations = getRemainingLocations($id);
    //$remainingPeople = getRemainingPeople($id);

    $rthtml = "";
    foreach ($remainingTypes as $rt) {$rthtml .= "<option value='" . $rt["companyTypeID"] . "'>".$rt["companyType"] . "</option>"; }
    
    $rphtml = "";
    foreach ($remainingProperties as $rp) { $rphtml .= "<option value='" . $rp["companyPropertyID"] . "'>" . $rp["companyProperty"] . "</option>"; }
    
    $rlhtml = "";
    foreach ( $remainingLocations as $rl) { $rlhtml .= "<option value='" . $rl["locationID"] . "'>" . $rl["location"] . "</option>"; }
    
    //$rpplhtml = "";
    //foreach ( $remainingPeople as $rp) { $rpplhtml .= "<option value='" . $rp["personID"] . "'>" . $rp["firstName"] . " " . $rp["lastName"] ."</option>"; }

    $html = str_replace("%%TypesSelections%%", $rthtml, $html);    
    $html = str_replace("%%PropertySelections%%", $rphtml, $html);    
    $html = str_replace("%%LocationSelections%%", $rlhtml, $html);    
    //$html = str_replace("%%PersonSelections%%", $rpplhtml, $html);    

    echo $html;
?>