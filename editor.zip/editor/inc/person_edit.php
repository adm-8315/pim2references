<?php
    require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
    require_once(dirname(__FILE__) . "/../../inc/session.php");
    require_once("db.php");

    $id = $_GET["id"];

    $tmpl = file_get_contents("../tmpl/person_edit.html");
    $data = getPerson($id);

    $html = str_replace("%%name%%", $data["name"], $tmpl);
    $html = str_replace("%%id%%", $id, $html);
    
    if (!empty($data["address"])) {
        $html = str_replace("%%addressString%%", getAddressString($data["address"]), $html);

        $html = str_replace("%%addrLine1%%", $data["address"]["lineOne"], $html);
        $html = str_replace("%%addrLine2%%", $data["address"]["lineTwo"], $html);
        $html = str_replace("%%addrLine3%%", $data["address"]["lineThree"], $html);
        $html = str_replace("%%addrCity%%", getCity($data["address"]["city"]), $html);
        $html = str_replace("%%addrState%%", getState($data["address"]["state"]), $html);
        $html = str_replace("%%addrZip%%", $data["address"]["zip"], $html);
        $html = str_replace("%%stateID%%", $data["address"]["state"], $html);
    } else {
        $html = str_replace("%%addressString%%", "", $html);

        $html = str_replace("%%addrLine1%%", "", $html);
        $html = str_replace("%%addrLine2%%", "", $html);
        $html = str_replace("%%addrLine3%%", "", $html);
        $html = str_replace("%%addrCity%%", "", $html);
        $html = str_replace("%%addrState%%", "", $html);
        $html = str_replace("%%addrZip%%", "", $html);
        $html = str_replace("%%stateID%%", "", $html);
    }
    $statesData = getStates();
    $statesHTML = "";
    foreach ($statesData as $st) {
        $selected = "";
        if (!empty($data["address"]["state"])) { if ($st['stateID'] == $data["address"]["state"]) { $selected = " selected "; } }
        $statesHTML .= "<option value=" . $st["stateID"] . $selected . ">" . $st['state'] . "</option>";
    }

    $ehtml = "";
    foreach ($data["emails"] as $em) {
        $mailid = $em['id'];
        $fav = "fav_no";
        $tem = "<div><span class='removeEmail' onClick='removeEMail(" . '"person"' . ", $id, $mailid);'><a href='#'>🗑️</a></span>";
        if ($em["primary"] == 1) { $fav = "fav_yes"; }
        $tem .= "<img src='editor/img/" . $fav . ".png' onClick='toggleMailFav(" . '"person", ' . "$id, $mailid," . '"' . $fav . '"' . ");'>&nbsp;&nbsp;";
        $tem .= $em["email"] . "</div>";
        $ehtml .= $tem;
    }

    $html = str_replace("%%states%%", $statesHTML, $html);

    $html = str_replace("%%emails%%", $ehtml, $html);

    $delPhoneTmpl = "<span class='removePhone' onClick='removePhone(" . '"person"' . ", $id, %%phoneid%%);'><a href='#'>🗑️</a></span>";
    $phtml = "";
    foreach ($data["phones"]["work"] as $wp) { $phtml .= str_replace("%%phoneid%%", $wp['numberID'], $delPhoneTmpl) . " <img src=editor/img/phone-w.png> " . $wp['number']; if (!empty($wp['ext'])) { $phtml .= "ex. " . $wp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["cell"] as $cp) { $phtml .= str_replace("%%phoneid%%", $cp['numberID'], $delPhoneTmpl) . " <img src=editor/img/phone-c.png> " . $cp['number']; if (!empty($cp['ext'])) { $phtml .= "ex. " . $cp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["home"] as $hp) { $phtml .= str_replace("%%phoneid%%", $hp['numberID'], $delPhoneTmpl) . " <img src=editor/img/phone-h.png> " . $hp['number']; if (!empty($hp['ext'])) { $phtml .= "ex. " . $hp['ext']; } $phtml .= "<br>"; }
    foreach ($data["phones"]["fax"] as $fp) { $phtml .= str_replace("%%phoneid%%", $fp['numberID'], $delPhoneTmpl) . " <img src=editor/img/phone-f.png> " . $fp['number']; if (!empty($fp['ext'])) { $phtml .= "ex. " . $fp['ext']; } $phtml .= "<br>"; }

    $html = str_replace("%%phones%%", $phtml, $html);

    $phoneTypes = getPhoneTypes();
    $pthtml = "";
    foreach ($phoneTypes as $pt) { $pthtml .= "<option value=" . $pt['numberTypeID'] . ">" . $pt['numberType'] . "</option>"; }
    $html = str_replace("%%phoneTypes%%", $pthtml, $html);

    echo $html;
?>