<?php

require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
require_once(dirname(__FILE__) . "/../../inc/session.php");
require_once("db.php");

$module = "";
if (isset($_GET["module"])) { $module = $_GET["module"]; } else { $module = "companies"; }

switch ($module) {
    case "companies":  loadComapniesPage(); break;
    case "contacts":  loadContactPage(); break;
    case "products":  loadProductsPage(); break;
    case "locations":  loadLocationsPage(); break;
    case "measurements":  loadMeasurementsPage(); break;
    case "companyProperties":  loadCompanyPropsPage(); break;
    case "equipmentTypes":  loadEquipmentTypesPage(); break;
    case "materialTypes":  loadMaterialTypsPage(); break;
    case "productTypes":  loadProductTypesPage(); break;
    case "companyTypes":  loadCompanyTypesPage(); break;
    case "settings":  loadSettingsPage(); break;
    case "session":  loadSessionData(); break;
}

function loadContactPage() {
    $html = file_get_contents("../tmpl/people.html");
    
    $rtmpl = "<tr onClick='openPerson(%%id%%)'><td>%%id%%</td><td>%%name%%</td><td>%%address%%</td><td>%%phones%%</td><td>%%emails%%</td></tr>";

    $data = getAllPeople();
    $tblData = "";

    foreach ($data as $row) {
        $person = getPerson($row["personID"]);
        $tr = str_replace("%%id%%", $person['id'], $rtmpl);
        $tr = str_replace("%%name%%", $person['name'], $tr);
        $phtml = "";
        if(count($person["phones"]["work"]) > 0) { foreach ($person["phones"]["work"] as $wp) { $phtml .= "<img src=editor/img/phone-w.png> " . $wp['number'] . "<br>"; } }
        if(count($person["phones"]["cell"]) > 0) { foreach ($person["phones"]["cell"] as $cp) { $phtml .= "<img src=editor/img/phone-c.png> " . $cp['number'] . "<br>"; } }
        if(count($person["phones"]["home"]) > 0) { foreach ($person["phones"]["home"] as $hp) { $phtml .= "<img src=editor/img/phone-h.png> " . $hp['number'] . "<br>"; } }
        if(count($person["phones"]["fax"]) > 0) { foreach ($person["phones"]["fax"] as $fp) { $phtml .= "<img src=editor/img/phone-f.png> " . $fp['number'] . "<br>"; } }

        $tr = str_replace("%%phones%%", $phtml, $tr);
        
        $ehtml = "";
        foreach ($person["emails"] as $email) { 
            if ($email["primary"]) { $ehtml .= "<img src=editor/img/fav_yes.png> " . $email["email"] . "<br>"; }
               else { $ehtml .= "<img src=editor/img/email.png> " . $email["email"] . "<br>";}
        }
        $tr = str_replace("%%emails%%", $ehtml, $tr);
        
        $tr = str_replace("%%address%%", getAddressString($person["address"]), $tr);

        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;

}

function loadComapniesPage() {
    $html = file_get_contents("../tmpl/companies.html");
    
    $rtmpl = "<tr onClick='openCompany(%%id%%)'><td>%%id%%</td><td>%%companyactive%%</td><td>%%companyname%%</td></tr>";

    $data = getAllCompanies();
    $tblData = "";

    foreach ($data as $row) {
        $tr = str_replace("%%id%%", $row['companyID'], $rtmpl);
        if($row['active']) { $tr = str_replace("%%companyactive%%", "yes", $tr); } else { $tr = str_replace("%%companyactive%%", "no", $tr); }
        $tr = str_replace("%%companyname%%", $row['company'], $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;


}

function loadMeasurementsPage() {
    $html = file_get_contents("../tmpl/measurements.html");
    
    $rtmpl = "<tr><td>%%RemoveMeasure%%%%id%%</td><td>%%measurementP%%</td><td>%%measurementS%%</td><td>%%measurementUse%%</td></tr>";

    $data = getAllMeasurements();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseMeasurements($row['measureID']);
        if ($used == "No") { $tr = str_replace("%%RemoveMeasure%%", "<div class='removeMeasurement' onClick='removeMeasurement(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%RemoveMeasure%%", "<div class='removeMeasurement'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['measureID'], $tr);
        $tr = str_replace("%%measurementP%%", $row['measurePlural'], $tr); 
        $tr = str_replace("%%measurementS%%", $row['measureSingular'], $tr);
        $tr = str_replace("%%measurementUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadEquipmentTypesPage() {
    $html = file_get_contents("../tmpl/equipmenttypes.html");
    $rtmpl = "<tr><td>%%removeEquipmentType%%%%id%%</td><td>%%EquipmentTypeName%%</td><td>%%equipTypeInUse%%</td></tr>";

    $data = getAllequipmentTypes();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseEquipmentType($row['equipmentTypeID']);
        if ($used == "No") { $tr = str_replace("%%removeEquipmentType%%", "<div class='removeEquipmentType' onClick='removeEquipmentTypeOption(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%removeEquipmentType%%", "<div class='removeEquipmentType'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['equipmentTypeID'], $tr);
        $tr = str_replace("%%EquipmentTypeName%%", $row['equipmentType'], $tr);
        $tr = str_replace("%%equipTypeInUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadMaterialTypsPage() {
    $html = file_get_contents("../tmpl/materialtypes.html");
    $rtmpl = "<tr><td>%%removeMaterialType%%%%id%%</td><td>%%MaterialTypeName%%</td><td>%%MaterialTypeInUse%%</td></tr>";

    $data = getAllMaterialTypes();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseMaterialType($row['materialTypeID']);
        if ($used == "No") { $tr = str_replace("%%removeMaterialType%%", "<div class='removeMaterialType' onClick='removeMaterialTypeOption(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%removeMaterialType%%", "<div class='removeMaterialType'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['materialTypeID'], $tr);
        $tr = str_replace("%%MaterialTypeName%%", $row['materialType'], $tr);
        $tr = str_replace("%%MaterialTypeInUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadProductTypesPage() {
    $html = file_get_contents("../tmpl/producttypes.html");
    $rtmpl = "<tr><td>%%removeProductType%%%%id%%</td><td>%%ProductTypeName%%</td><td>%%ProductTypeInUse%%</td></tr>";

    $data = getAllProductTypes();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseProductType($row['productTypeID']);
        if ($used == "No") { $tr = str_replace("%%removeProductType%%", "<div class='removeProductType' onClick='removeProductTypeOption(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%removeProductType%%", "<div class='removeProductType'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['productTypeID'], $tr);
        $tr = str_replace("%%ProductTypeName%%", $row['productType'], $tr);
        $tr = str_replace("%%ProductTypeInUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadCompanyTypesPage() {
    $html = file_get_contents("../tmpl/companytypes.html");
    $rtmpl = "<tr><td>%%removeCompanyType%%%%id%%</td><td>%%CompanyTypeName%%</td><td>%%CompanyTypeInUse%%</td></tr>";

    $data = getAllCompanyTypes();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseCompanyType($row['companyTypeID']);
        if ($used == "No") { $tr = str_replace("%%removeCompanyType%%", "<div class='removeCompanyType' onClick='removeCompanyTypeOption(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%removeCompanyType%%", "<div class='removeCompanyType'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['companyTypeID'], $tr);
        $tr = str_replace("%%CompanyTypeName%%", $row['companyType'], $tr);
        $tr = str_replace("%%CompanyTypeInUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadCompanyPropsPage() {
    $html = file_get_contents("../tmpl/companyprops.html");
    $rtmpl = "<tr><td>%%removeCompanyProp%%%%id%%</td><td>%%CompanyPropName%%</td><td>%%PropertyInUse%%</td></tr>";

    $data = getAllCompanyProps();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseCompanyProps($row['companyPropertyID']);
        if ($used == "No") { $tr = str_replace("%%removeCompanyProp%%", "<div class='removeCompanyProperty' onClick='removeCompanyPropertyOption(%%id%%);'><a href='#'>🗑️</a></div>", $rtmpl); }
        else { $tr = str_replace("%%removeCompanyProp%%", "<div class='removeCompanyProp'></div>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['companyPropertyID'], $tr);
        $tr = str_replace("%%CompanyPropName%%", $row['companyProperty'], $tr);
        $tr = str_replace("%%PropertyInUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
}

function loadSettingsPage() {
    $html = file_get_contents("../tmpl/settings.html");
    $users = getUsers();

    $userHTML = "";
    foreach ($users as $user) {
        $userHTML .= "<option value=" . $user['userID'] . ">" . $user['username'] . "</option>";

    }

    $html = str_replace("%%EditorPermissionSelectionUsers%%", $userHTML, $html);


    echo $html;

}

function loadSessionData() {
    
    echo '<div class="app_report_table app_report_head"><table><thead><tr><th class="editorTitle head_row"><div><span class="head">Session Data</span></div></th></tr></thead></table></div>';
    echo "Session Info<br>";
    echo session_id();
    echo "<br>";
    session_id();
    echo print_r($_SESSION);
    echo "<br>Passed Variables<br>";
    echo var_dump($_GET);
}

function loadLocationsPage() {
    $html = file_get_contents("../tmpl/locations.html");
    
    $rtmpl = "<tr onClick='openLocation(%%id%%)'><td>%%id%%</td><td>%%locationName%%</td><td>%%locationActive%%</td><td>%%locationStockable%%</td><td>%%addressString%%</td><td>%%region%%</td></tr>";

    $data = getAllLocations();
    $tblData = "";

    foreach ($data as $row) {
        $tr = str_replace("%%id%%", $row['locationID'], $rtmpl);
        $tr = str_replace("%%locationName%%", $row['location'], $tr);
        if (!empty($row['address'])) { $tr = str_replace("%%addressString%%", getAddressString(getAddress($row['address'])), $tr); } else { $tr = str_replace("%%addressString%%", "", $tr); }
        if (!empty($row['region'])) { $tr = str_replace("%%region%%", getRegion($row['region']), $tr); } else { $tr = str_replace("%%region%%", "", $tr); }
        if($row['active']) { $tr = str_replace("%%locationActive%%", "yes", $tr); } else { $tr = str_replace("%%locationActive%%", "no", $tr); }
        if($row['stockable']) { $tr = str_replace("%%locationStockable%%", "yes", $tr); } else { $tr = str_replace("%%locationStockable%%", "no", $tr); }
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;

    
}

function loadProductsPage() {
    $html = file_get_contents("../tmpl/products.html");
    
    $rtmpl = "<tr><td width=100>%%removeProduct%%%%id%%</td><td>%%productName%%</td><td>%%productType%%</td><td>%%Cost%%</td><td>%%Measurement%%</td><td>%%Active%%</td><td>%%InUse%%</td></tr>";

    $data = getAllProducts();
    $tblData = "";

    foreach ($data as $row) {
        $used = getInUseProducts($row['productID']);
        if ($used == "No") { $tr = str_replace("%%removeProduct%%", "<span class='removeProduct' onClick='removeProduct(%%id%%);'><a href='#'>🗑️</a></span>", $rtmpl); }
        else { $tr = str_replace("%%removeProduct%%", "<span class='removeProduct'></span>", $rtmpl); }
        $tr = str_replace("%%id%%", $row['productID'], $tr);
        $tr = str_replace("%%productName%%", $row['product'], $tr); 
        $tr = str_replace("%%productType%%", $row['productType'], $tr);
        $tr = str_replace("%%Cost%%", $row['cost'], $tr);
        $tr = str_replace("%%Measurement%%", $row['measureSingular'] . "/" . $row['measurePlural'], $tr);
        $tr = str_replace("%%Active%%", $row['active'], $tr);
        $tr = str_replace("%%InUse%%", $used, $tr);
        $tblData .= $tr;
    }
    $html = str_replace("%%Data%%",$tblData, $html);
    echo $html;
    
}