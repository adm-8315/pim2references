<?php
    require_once(dirname(__FILE__) . "/../../inc/dbfunc.php");
    require_once(dirname(__FILE__) . "/../../inc/session.php");
    require_once("db.php");

    $id = $_GET["id"];

    $tmpl = file_get_contents("../tmpl/location_view.html");
    $data = getLocation($id);

    $html = str_replace("%%name%%", $data["location"], $tmpl);
    $html = str_replace("%%id%%", $id, $html);

    if ( $data["active"]) { $html = str_replace("%%active%%", "yes", $html);}
    else { $html = str_replace("%%active%%", "no", $html); }
    
    if ( $data["stockable"]) { $html = str_replace("%%stockable%%", "yes", $html);}
    else { $html = str_replace("%%stockable%%", "no", $html); }

    if (empty($data['address'])) { $html = str_replace("%%addressString%%", "", $html); }
        else { $html = str_replace("%%addressString%%", getAddressString(getAddress($data['address'])), $html); }
    if (empty($data['region'])) { $html = str_replace("%%region%%", "", $html); }
        else { $html = str_replace("%%region%%", getRegion($data['region']), $html); }

    $requirements = getLocationRequirements($id);
    $reqHTML = "";

    foreach ($requirements as $r) {
        $reqHTML .= "<tr><td>" . $r['requirement'] . "</td><td>" . $r['reqType'] . "</td</tr>";
    }
    $html = str_replace("%%requirements%%", $reqHTML, $html);


    echo $html;
?>